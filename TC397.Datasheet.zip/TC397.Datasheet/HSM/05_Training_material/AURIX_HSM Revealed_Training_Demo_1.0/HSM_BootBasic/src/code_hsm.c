#include "IFX_HSM.h"
#include "core_cc.h"

#define APPLICATION_BASE    0x80060000ul
#define WEAK                __attribute__ ((weak))
#define MEM(memAddr)        (*((volatile unsigned int *)(memAddr)))

void Reset_Handler(void)    INTERRUPT_ATTRIBUTE;

/*  Forward declaration of the default fault handlers. */
void HND_Reserved(void);
void HND_NonMaskableIRQ(void);
void HND_HardFault(void);
void HND_BusFault(void);
void HND_UsageFault(void);
void HND_MemoryManagement(void);
void HND_SVCall(void);
void HND_DebugMonitor(void);
void HND_PendSV(void);
void HND_SysTick(void);

/* External Interrupts */
void ISR_Timer0(void);
void ISR_Timer1(void);
void ISR_Trng(void);
void ISR_BridgeService(void);
void ISR_BridgeError(void);
void ISR_SensorInterrupt(void);
void ISR_ExternalInterrupt(void);
void ISR_PKCReadyInterrupt(void);
void ISR_PKCErrorInterrupt(void);
void ISR_Reserved(void);

/*************************************************************************************//**
 * interrupt vector table
 ****************************************************************************************/
typedef void (*FnVector)(void);

/*lint -esym(961, 12.1) -esym(960, 12.10) -esym(939, 8.2) -e957(8.1) -e546 -e505 */
ISR_VECTOR_ATTRIBUTE
const FnVector g_pfnVectors[26] =
{
    (void*)IFX_HSM_INITIAL_STACK_POINTER, /* The initial stack pointer */
    &Reset_Handler           ,
    &HND_NonMaskableIRQ      ,
    &HND_HardFault           ,
    &HND_MemoryManagement    ,
    &HND_BusFault            ,
    &HND_UsageFault          ,
    &HND_Reserved            ,  /* Reserved */
    &HND_Reserved            ,  /* Reserved */
    &HND_Reserved            ,  /* Reserved */
    &HND_Reserved            ,  /* Reserved */
    &HND_SVCall              ,
    &HND_DebugMonitor        ,
    &HND_Reserved            ,  /* Reserved */
    &HND_PendSV              ,
    &HND_SysTick             ,

    /* External Interrupts*/
    &ISR_Timer0              ,
    &ISR_Timer1              ,
    &ISR_Trng                ,
    &ISR_BridgeService       ,
    &ISR_BridgeError         ,
    &ISR_SensorInterrupt     ,
    &ISR_ExternalInterrupt   ,
    &ISR_Reserved            ,  /* Reserved */
    &ISR_PKCReadyInterrupt   ,
    &ISR_PKCErrorInterrupt
};
/*lint -restore */

/*************************************************************************************//**
 * This code is called after each reset
 ****************************************************************************************/
void Reset_Handler(void)
{
    HSM_BRIDGE->HSM2HTS = 0x12345678ul;

    /* Set application vector table (VTOR) */
    MEM(0xe000ed08ul) = APPLICATION_BASE;

    /* Set application stack */
    __asm volatile ("MSR msp, %0\n\t"::"r" (MEM(APPLICATION_BASE)));

    /* Jump into the application's entry point. */
    {
        void (*userCode)(void) = (void *)MEM(APPLICATION_BASE + 4ul);
        userCode();
    }

    /* we should never reach this point */
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_Reserved(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead00FF;
    while (1);
}

void ISR_Reserved(void)
{
	HSM_BRIDGE->HSM2HTS = 0xdead0000;
	while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_NonMaskableIRQ(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0001;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_HardFault(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0002;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_MemoryManagement(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0003;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_BusFault(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0004;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_UsageFault(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0005;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_SVCall(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0006;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_DebugMonitor(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0007;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_PendSV(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0008;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void HND_SysTick(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0009;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void ISR_Timer0(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0010;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void ISR_Timer1(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0011;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void ISR_Trng(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0012;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void ISR_BridgeError(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0013;
    while (1);
}

void ISR_BridgeService(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0014;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void ISR_SensorInterrupt(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0015;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void ISR_ExternalInterrupt(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0016;
    while (1);
}


/*************************************************************************************//**
 *
 ****************************************************************************************/
void ISR_PKCReadyInterrupt(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0017;
    while (1);
}

/*************************************************************************************//**
 *
 ****************************************************************************************/
void ISR_PKCErrorInterrupt(void)
{
    HSM_BRIDGE->HSM2HTS = 0xdead0018;
    while (1);
}


