#include <core_cc.h>

#if defined(__GNUC__)

/* init value for the stack pointer. defined in linker script */
extern void _estack;
#define IFX_HSM_INITIAL_STACK_POINTER &_estack
#define INTERRUPT_ATTRIBUTE __attribute__ ((__interrupt__))

extern uint32_t _etext;
/** start address for the initialization values of the .data section. defined in linker script */
extern uint32_t _sidata;
/** start address for the .data section. defined in linker script */
extern uint32_t _sdata;
/** end address for the .data section. defined in linker script */
extern uint32_t _edata;
/* start address for the .bss section. defined in linker script */
extern uint32_t _sbss;
/* end address for the .bss section. defined in linker script */
extern uint32_t _ebss;

/* replacement of the c initialization */
void __init(void)
{
    /* Initialize data and bss */
    uint32_t *pulSrc, *pulDest;
    /* Copy the data segment initializers from flash to SRAM */

    pulSrc = &_sidata;

    for (pulDest = &_sdata; pulDest < &_edata;)
    {
        *(pulDest++) = *(pulSrc++);
    }
    /* Zero fill the bss segment. */
    for (pulDest = &_sbss; pulDest < &_ebss;)
    {
        *(pulDest++) = 0;
    }
}

#endif
