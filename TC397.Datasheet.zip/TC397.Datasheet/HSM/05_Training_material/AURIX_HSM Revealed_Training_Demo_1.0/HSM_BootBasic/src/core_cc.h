#ifndef CORE_CC_H
#define CORE_CC_H 1

#include "IFX_HSM.h"

#ifdef __WIN32__

#include <stdio.h>

#define IFX_HSM_INITIAL_STACK_POINTER 0
#define ISR_VECTOR_ATTRIBUTE
#define INTERRUPT_ATTRIBUTE
#define __initStackPointer()
#define __init()

#define NVIC_GetPriority(...) (0)
#define NVIC_EnableIRQ(...)
#define NVIC_ClearPendingIRQ(...)

#define __REV(x)    ((((x) & 0xff) << 24) | \
                     (((x) & 0xff00) << 8) | \
                     (((x) & 0xff0000UL) >> 8) | \
                     (((x) & 0xff000000UL) >> 24))

#ifdef __GNUC__
#define _INLINE_ static inline
#else
#define _INLINE_ __inline
#endif

#define __debug() { print_f("__debug() at %s:%d\n",__FILE__,__LINE__); while(1) { Sleep(1);} }

#elif defined(__GNUC__)

#ifndef _INLINE_
#define _INLINE_ static inline
#endif

extern void _estack;

#define IFX_HSM_INITIAL_STACK_POINTER &_estack
#define INTERRUPT_ATTRIBUTE __attribute__ ((__interrupt__))

extern uint32_t _etext;
/*  start address for the initialization values of the .data section. defined in linker script */
extern uint32_t _sidata;
/*  start address for the .data section. defined in linker script */
extern uint32_t _sdata;
/*  end address for the .data section. defined in linker script */
extern uint32_t _edata;
/*  start address for the .bss section. defined in linker script */
extern uint32_t _sbss;
/*  end address for the .bss section. defined in linker script */
extern uint32_t _ebss;
/*  init value for the stack pointer. defined in linker script */


#define __initStackPointer() __asm volatile ("MSR msp, %0\n\t"::"r" (IFX_HSM_INITIAL_STACK_POINTER));
#define ISR_VECTOR_ATTRIBUTE __attribute__ ((section (".isr_vector")))

void __init(void);

#elif defined(__TASKING__)

#ifndef _INLINE_
#define _INLINE_ static inline
#endif

extern uint32_t _lc_ub_stack;

#define IFX_HSM_INITIAL_STACK_POINTER &_lc_ub_stack
#define INTERRUPT_ATTRIBUTE

#define __initStackPointer() __asm volatile ("MSR msp, %0\n\t"::"r" (IFX_HSM_INITIAL_STACK_POINTER));
#define ISR_VECTOR_ATTRIBUTE __attribute__ ((section (".isr_vector")))

void __init(void);

#define __debug() while (1U == 1U) {}

#else

#error "Unknown compiler"

#endif

#ifndef _EXTERN_
#define _EXTERN_ extern
#endif

#endif
