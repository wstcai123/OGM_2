/*
 * MAIN_HSM.h
 */


typedef void (*demo_fct_type) (void);
/* Definition of menu type */
typedef  struct DemoApp_FctListType
{
  const char    *fct_name;
  demo_fct_type fct_p;
  const char    *fct_desc;
} DemoApp_FctListType;

typedef  struct DemoApp_MenuType
{
  uint32    size;
  DemoApp_FctListType const *list;
} DemoApp_MenuType;


/*An example to enable/disable the CPU1 run */
#define IFX_CFG_CPU_CSTART_ENABLE_TRICORE1    (1)
#define IFX_CFG_CPU_CSTART_ENABLE_TRICORE2    (1)

/*An example to enable/disable the CPU0 data cache */
#define IFX_CFG_CPU_CSTART_ENABLE_TRICORE0_DCACHE (1)

extern void myExample_InterruptsInit (void);
extern void hsm_TestInit(void);
extern void main_hsm(void);

