#include <common.h>
#include "registers_hsm.h"
#include "HSM_Test_def.h"
#include "Test_Print.h"

static uint32 buf_out_Rev[16];
void hsm_aes_ecb_Test(void);

void hsm_aes_ecb_Test(void)
{
	uint32 i;

	print_f("\nAES_ECB_DEMO: Started ");
	// AES ENCRYPT according to example in spec.
	hsmEncryptionEnd = FALSE;

	for (i = 0; i < 0x100; i += 1)
	{
		buf_temp[i] = 0;
		HOST2HSMbuf[i] = 0;
		HSM2HOSTbuf[i] = 0;
	}

	for (i = 0; i < 16; i += 1)
	{
		buf_out_Rev[i]=0;
	}

	HOST2HSMbuf[0] = 0xe2bec16b;
	HOST2HSMbuf[1] = 0x969f402e;
	HOST2HSMbuf[2] = 0x117e3de9;
	HOST2HSMbuf[3] = 0x2a179373;
	HOST2HSMbuf[4] = 0x578a2dae;
	HOST2HSMbuf[5] = 0x9cac031e;
	HOST2HSMbuf[6] = 0xac6fb79e;
	HOST2HSMbuf[7] = 0x518eaf45;
	HOST2HSMbuf[8] = 0x461cc830;
	HOST2HSMbuf[9] = 0x11e45ca3;
	HOST2HSMbuf[10] = 0x19c1fbe5;
	HOST2HSMbuf[11] = 0xef520a1a;
	HOST2HSMbuf[12] = 0x45249ff6;
	HOST2HSMbuf[13] = 0x179b4fdf;
	HOST2HSMbuf[14] = 0x7b412bad;
	HOST2HSMbuf[15] = 0x10376ce6;

	print_f("\nAES_ECB_DEMO: Data to be encrypted\n\n");
	for (i = 0; i < 16; i++)
	{
		print_f("%08x",ChangeEndianness(HOST2HSMbuf[i]));
		if ( ((i+1)%4) == 0)
		{
			print_f("\n");
		}
	}
	print_f("\nAES_ECB_DEMO: DATA to be encrypted is copied to the HOST2HSMbuf buffer");
	print_f("\nAES_ECB_DEMO: Issue interrupt to HSM to Run AES ENCRYPTION ");
	HSM_HT2HSMF.U = (1 << CMD_AES_ECB_ENCRYPT);	//issue interrupt to HSM
	print_f("\nAES_ECB_DEMO: Wait for HSM to finish Encryption");
	while (!hsmEncryptionEnd)
		;

	if (HSM_HSM2HTS.U != (0xCCCC0000 | CMD_AES_ECB_ENCRYPT))
	{
		print_f("\nAES_ECB_DEMO: Finished - Failed\n");
		__debug(); // not the correct response or timeout
	}

	for (i = 0; i < 0x100; i ++)
	{
		buf_temp[i] = HOST2HSMbuf[i];
	}

	for (i = 0; i < 16; i ++)
	{
		buf_out_Rev[i]= ChangeEndianness(HSM2HOSTbuf[i]);
	}

	/***********************************************************************************************/

	// AES DECRYPT according to example in spec.
	hsmEncryptionEnd = FALSE;

	for (i = 0; i < 0x100; i += 1)
		HOST2HSMbuf[i] = HSM2HOSTbuf[i];

	HSM_HT2HSMF.U = (1 << CMD_AES_ECB_DECRYPT);	//issue interrupt to HSM

	while (!hsmEncryptionEnd)
		;

	if (HSM_HSM2HTS.U != (0xCCCC0000 | CMD_AES_ECB_DECRYPT))
		__debug(); // not the correct response or timeout

	for (i = 0; i < 0x100; i += 1)
	{
		if (HSM2HOSTbuf[i] != buf_temp[i])		// just check that the buffer is identical
		{
			print_f("\nAES_ECB_DEMO: Finished - Failed\n");
			__debug();
		}
	}

	print_f("\nAES_ECB_DEMO: Finished and Results validated\n");
	print_f("\nAES_ECB_DEMO: ECB Encrypted Data is\n");
	for (i = 0; i < 16; i++)
	{
		print_f("%08x",buf_out_Rev[i]);
		if ( ((i+1)%4) == 0)
		{
			print_f("\n");
		}
	}
	print_f("\n");
}

