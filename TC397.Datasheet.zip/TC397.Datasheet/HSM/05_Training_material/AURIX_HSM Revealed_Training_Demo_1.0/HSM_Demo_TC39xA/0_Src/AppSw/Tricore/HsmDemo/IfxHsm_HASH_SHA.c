#include <common.h>
#include "registers_hsm.h"
#include "HSM_Test_def.h"
#include "Test_Print.h"

void HashSha256_Test(void);

const uint32 buf_Out[8] = {0x020C96D1, 0x4BB524A7, 0xE4F33DA5, 0xB897AEE6,
		                   0x4E872BD7, 0x9A830740, 0x81BF37AF, 0x9A7B0612
		                   };

void HashSha256_Test(void)
{
	hsmHashEnd = FALSE;
	uint32 i;

	print_f("\nHASH_SHA256_DEMO: Started ");
	for (i = 0; i < 0x100; i += 1)
	{
		HOST2HSMbuf[i] = 0;
		HSM2HOSTbuf[i] = 0;
	}

	/* Data to be hashed*/
	/*
	 * 6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710
	 */

	HOST2HSMbuf[0] = 0xe2bec16b;
	HOST2HSMbuf[1] = 0x969f402e;
	HOST2HSMbuf[2] = 0x117e3de9;
	HOST2HSMbuf[3] = 0x2a179373;
	HOST2HSMbuf[4] = 0x578a2dae;
	HOST2HSMbuf[5] = 0x9cac031e;
	HOST2HSMbuf[6] = 0xac6fb79e;
	HOST2HSMbuf[7] = 0x518eaf45;
	HOST2HSMbuf[8] = 0x461cc830;
	HOST2HSMbuf[9] = 0x11e45ca3;
	HOST2HSMbuf[10] = 0x19c1fbe5;
	HOST2HSMbuf[11] = 0xef520a1a;
	HOST2HSMbuf[12] = 0x45249ff6;
	HOST2HSMbuf[13] = 0x179b4fdf;
	HOST2HSMbuf[14] = 0x7b412bad;
	HOST2HSMbuf[15] = 0x10376ce6;

	print_f("\nHASH_SHA256_DEMO: Data to be hashed is\n\n");
	for (i = 0; i < 16; i++)
	{
		print_f("%08x",ChangeEndianness(HOST2HSMbuf[i]));
		if ( ((i+1)%4) == 0)
		{
			print_f("\n");
		}
	}
	print_f("\nHASH_SHA256_DEMO: Data to be hashed is copied to the HOST2HSMbuf buffer");
	print_f("\nHASH_SHA256_DEMO: Issue interrupt to HSM to Hash the data ");
	HSM_HT2HSMF.U = (1 << CMD_HASH_SHA_256);	//issue interrupt to HSM
	print_f("\nHASH_SHA256_DEMO: Wait for HSM to finish Hashing");
	while (!hsmHashEnd)
		;

	if (HSM_HSM2HTS.U != (0xCCCC0000 | CMD_HASH_SHA_256))
	{
		print_f("\nHASH_SHA256_DEMO: Finished - Failed\n");
		__debug(); // not the correct response or timeout
	}

    /*
     * Check if data is correct:
     * d1960c02a724b54ba53df3e4e6ae97b8d72b874e4007839aaf37bf8112067b9a
     */

	for (i = 0; i < 8; i += 1)
	{
		if (HSM2HOSTbuf[i] != buf_Out[i])
		{
			print_f("\nHASH_SHA256_DEMO: Finished - Failed\n");
			__debug();
		}
	}
	if (HSM2HOSTbuf[8] != 0xAA)
	{
		print_f("\nHASH_SHA256_DEMO: Finished - Failed\n");
		__debug();
	}

	print_f("\nHASH_SHA256_DEMO: Finished and Results validated\n");
	print_f("\nHASH_SHA256_DEMO: Hashed Data is\n");
	for (i = 0; i < 8; i++)
	{
		print_f("%08x",ChangeEndianness(HSM2HOSTbuf[i]));
	}
    print_f("\n");
}

