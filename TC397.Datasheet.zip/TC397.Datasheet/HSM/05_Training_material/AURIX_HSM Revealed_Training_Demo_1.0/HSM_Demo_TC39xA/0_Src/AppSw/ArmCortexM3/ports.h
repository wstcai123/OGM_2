/**
 * \file ports.h
 * \brief Include file
 * \author Chris Wunderlich
 * \version 0.1.0.0
 * \date 25-May-2016
 *
 * \copyright Copyright (c) 2013 Infineon Technologies AG. All rights reserved.
 *
 *
 *                          IMPORTANT NOTICE
 *
 *
 * Infineon Technologies AG (Infineon) is supplying this file for use
 * exclusively with Infineon's microcontroller products. This file can be freely
 * distributed within development tools that are supporting such microcontroller
 * products.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *-----------------------------------------------------------------------------
 */

#ifndef PORTS_H
#define PORTS_H 1

#define PORT_TOGGLE_PC0  (0x00010001u)
#define PORT_TOGGLE_PC1  (0x00020002u)
#define PORT_TOGGLE_PC2  (0x00040004u)
#define PORT_TOGGLE_PC3  (0x00080008u)
#define PORT_TOGGLE_PC4  (0x00100010u)
#define PORT_TOGGLE_PC5  (0x00200020u)
#define PORT_TOGGLE_PC6  (0x00400040u)
#define PORT_TOGGLE_PC7  (0x00800080u)
#define PORT_TOGGLE_PC8  (0x01000100u)
#define PORT_TOGGLE_PC9  (0x02000200u)
#define PORT_TOGGLE_PC10 (0x04000400u)
#define PORT_TOGGLE_PC11 (0x08000800u)
#define PORT_TOGGLE_PC12 (0x10001000u)
#define PORT_TOGGLE_PC13 (0x20002000u)
#define PORT_TOGGLE_PC14 (0x40004000u)
#define PORT_TOGGLE_PC15 (0x80008000u)

#define PORT_SET_PC0  (0x00000001u)
#define PORT_SET_PC1  (0x00000002u)
#define PORT_SET_PC2  (0x00000004u)
#define PORT_SET_PC3  (0x00000008u)
#define PORT_SET_PC4  (0x00000010u)
#define PORT_SET_PC5  (0x00000020u)
#define PORT_SET_PC6  (0x00000040u)
#define PORT_SET_PC7  (0x00000080u)
#define PORT_SET_PC8  (0x00000100u)
#define PORT_SET_PC9  (0x00000200u)
#define PORT_SET_PC10 (0x00000400u)
#define PORT_SET_PC11 (0x00000800u)
#define PORT_SET_PC12 (0x00001000u)
#define PORT_SET_PC13 (0x00002000u)
#define PORT_SET_PC14 (0x00004000u)
#define PORT_SET_PC15 (0x00008000u)

#define PORT_CLR_PC0  (0x00010000u)
#define PORT_CLR_PC1  (0x00020000u)
#define PORT_CLR_PC2  (0x00040000u)
#define PORT_CLR_PC3  (0x00080000u)
#define PORT_CLR_PC4  (0x00100000u)
#define PORT_CLR_PC5  (0x00200000u)
#define PORT_CLR_PC6  (0x00400000u)
#define PORT_CLR_PC7  (0x00800000u)
#define PORT_CLR_PC8  (0x01000000u)
#define PORT_CLR_PC9  (0x02000000u)
#define PORT_CLR_PC10 (0x04000000u)
#define PORT_CLR_PC11 (0x08000000u)
#define PORT_CLR_PC12 (0x10000000u)
#define PORT_CLR_PC13 (0x20000000u)
#define PORT_CLR_PC14 (0x40000000u)
#define PORT_CLR_PC15 (0x80000000u)

typedef enum
{
  IfxPort_PCx_Input_Tristate,  /**< \brief No input pull device connected, tri-state mode  */
  IfxPort_PCx_Input_PullDown,  /**< \brief Input pull-down device connected  */
  IfxPort_PCx_Input_PullUp,    /**< \brief Input pull-up device connected  */
} IfxPort_PcInputCoding;

typedef enum
{
  IfxPort_PCx_Output_PushPull_gpio = 0x10,   /**< \brief  */
  IfxPort_PCx_Output_PushPull_Alt_1,   /**< \brief  */
  IfxPort_PCx_Output_PushPull_Alt_2,   /**< \brief  */
  IfxPort_PCx_Output_PushPull_Alt_3,   /**< \brief  */
  IfxPort_PCx_Output_PushPull_Alt_4,   /**< \brief  */
  IfxPort_PCx_Output_PushPull_Alt_5,   /**< \brief  */
  IfxPort_PCx_Output_PushPull_Alt_6,   /**< \brief  */
  IfxPort_PCx_Output_PushPull_Alt_7,   /**< \brief  */
  IfxPort_PCx_Output_OpenDrain_gpio,   /**< \brief  */
  IfxPort_PCx_Output_OpenDrain_Alt_1,   /**< \brief  */
  IfxPort_PCx_Output_OpenDrain_Alt_2,   /**< \brief  */
  IfxPort_PCx_Output_OpenDrain_Alt_3,   /**< \brief  */
  IfxPort_PCx_Output_OpenDrain_Alt_4,   /**< \brief  */
  IfxPort_PCx_Output_OpenDrain_Alt_5,   /**< \brief  */
  IfxPort_PCx_Output_OpenDrain_Alt_6,   /**< \brief  */
  IfxPort_PCx_Output_OpenDrain_Alt_7,   /**< \brief  */
} IfxPort_PcOutputCoding;

typedef enum
{
  IfxPort_PDx_Speed_Grade_1,  /**< \brief   */
  IfxPort_PDx_Speed_Grade_2,  /**< \brief   */
  IfxPort_PDx_Speed_Grade_3,  /**< \brief   */
  IfxPort_PDx_Speed_Grade_4,  /**< \brief   */
} IfxPort_PDx_Speed_Grade;

#endif

/** \\brief  Port Input/Output Control Register 12 */
typedef struct _Ifx_P_IOCR12_Bits
{
    unsigned int reserved_0 : 3;              /**< \brief \internal Reserved */
    unsigned int PC12 : 5;                    /**< \brief [7:3]  (rw) */
    unsigned int reserved_8 : 3;              /**< \brief \internal Reserved */
    unsigned int PC13 : 5;                    /**< \brief [15:11]  (rw) */
    unsigned int reserved_16 : 3;             /**< \brief \internal Reserved */
    unsigned int PC14 : 5;                    /**< \brief [23:19]  (rw) */
    unsigned int reserved_24 : 3;             /**< \brief \internal Reserved */
    unsigned int PC15 : 5;                    /**< \brief [31:27]  (rw) */
} Ifx_P_IOCR12_Bits;


/** \\brief  Port Input/Output Control Register 12 */
typedef union
{
    /** \brief Unsigned access */
    unsigned int      U;
    /** \brief Signed access */
    signed int        I;
    /** \brief Bitfield access */
    Ifx_P_IOCR12_Bits B;
} Ifx_P_IOCR12;

/** \\brief  1C, Port Input/Output Control Register 12 */
#define P20_IOCR12 /*lint --e(923)*/ (*(volatile Ifx_P_IOCR12 *)0xF003B41Cu)

/** \\brief  Port Output Modification Register */
typedef struct _Ifx_P_OMR_Bits
{
    unsigned int PS0 : 1;                     /**< \brief [0:0]  (w) */
    unsigned int PS1 : 1;                     /**< \brief [1:1]  (w) */
    unsigned int PS2 : 1;                     /**< \brief [2:2]  (w) */
    unsigned int PS3 : 1;                     /**< \brief [3:3]  (w) */
    unsigned int PS4 : 1;                     /**< \brief [4:4]  (w) */
    unsigned int PS5 : 1;                     /**< \brief [5:5]  (w) */
    unsigned int PS6 : 1;                     /**< \brief [6:6]  (w) */
    unsigned int PS7 : 1;                     /**< \brief [7:7]  (w) */
    unsigned int PS8 : 1;                     /**< \brief [8:8]  (w) */
    unsigned int PS9 : 1;                     /**< \brief [9:9]  (w) */
    unsigned int PS10 : 1;                    /**< \brief [10:10]  (w) */
    unsigned int PS11 : 1;                    /**< \brief [11:11]  (w) */
    unsigned int PS12 : 1;                    /**< \brief [12:12]  (w) */
    unsigned int PS13 : 1;                    /**< \brief [13:13]  (w) */
    unsigned int PS14 : 1;                    /**< \brief [14:14]  (w) */
    unsigned int PS15 : 1;                    /**< \brief [15:15]  (w) */
    unsigned int PCL0 : 1;                    /**< \brief [16:16]  (w) */
    unsigned int PCL1 : 1;                    /**< \brief [17:17]  (w) */
    unsigned int PCL2 : 1;                    /**< \brief [18:18]  (w) */
    unsigned int PCL3 : 1;                    /**< \brief [19:19]  (w) */
    unsigned int PCL4 : 1;                    /**< \brief [20:20]  (w) */
    unsigned int PCL5 : 1;                    /**< \brief [21:21]  (w) */
    unsigned int PCL6 : 1;                    /**< \brief [22:22]  (w) */
    unsigned int PCL7 : 1;                    /**< \brief [23:23]  (w) */
    unsigned int PCL8 : 1;                    /**< \brief [24:24]  (w) */
    unsigned int PCL9 : 1;                    /**< \brief [25:25]  (w) */
    unsigned int PCL10 : 1;                   /**< \brief [26:26]  (w) */
    unsigned int PCL11 : 1;                   /**< \brief [27:27]  (w) */
    unsigned int PCL12 : 1;                   /**< \brief [28:28]  (w) */
    unsigned int PCL13 : 1;                   /**< \brief [29:29]  (w) */
    unsigned int PCL14 : 1;                   /**< \brief [30:30]  (w) */
    unsigned int PCL15 : 1;                   /**< \brief [31:31]  (w) */
} Ifx_P_OMR_Bits;

/** \\brief  Port Output Modification Register */
typedef union
{
    /** \brief Unsigned access */
    unsigned int   U;
    /** \brief Signed access */
    signed int     I;
    /** \brief Bitfield access */
    Ifx_P_OMR_Bits B;
} Ifx_P_OMR;


/** \\brief  4, Port Output Modification Register */
#define P20_OMR    /*lint --e(923)*/ (*(volatile Ifx_P_OMR *)0xF003B404u)

/** \brief Ifx_P output modification modes definition.
 *
 * \see Ifx_P.OMR, IfxPort_setPinState()
 */
typedef enum
{
    IfxPort_State_notChanged = (0 << 16) | (0 << 0),  /**< \brief Ifx_P pin is left unchanged. */
    IfxPort_State_high       = (0 << 16) | (1U << 0), /**< \brief Ifx_P pin is set to high. */
    IfxPort_State_low        = (1U << 16) | (0 << 0), /**< \brief Ifx_P pin is set to low. */
    IfxPort_State_toggled    = (1U << 16) | (1U << 0) /**< \brief Ifx_P pin is toggled. */
} IfxPort_State;


