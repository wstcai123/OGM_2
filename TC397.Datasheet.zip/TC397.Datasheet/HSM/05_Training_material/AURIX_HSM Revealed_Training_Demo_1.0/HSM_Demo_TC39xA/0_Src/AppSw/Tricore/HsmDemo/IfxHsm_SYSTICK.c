#include <common.h>
#include "registers_hsm.h"
#include "HSM_Test_def.h"
#include "Test_Print.h"

/* Test specific definitions */
#define SYSTICK_ERROR_THRESHOLD		1

void hsm_sysTick_Test(void);

void hsm_sysTick_Test(void)
{
	uint32 i;
	uint32 errors = 0;

	print_f("\nSYSTICK Demo: Started ");
	//Clear buffer
	for (i = 0; i < 0x100; i += 1)
	{
		HSM2HOSTbuf[i] = 0;
	}

	hsmReady = FALSE;
	print_f("\nSYSTICK Demo: Issue interrupt to HSM to enable Systick");
	HSM_HT2HSMF.U = (1 << CMD_RUN_SYSTICK);	//issue interrupt to HSM

	print_f("\nSYSTICK Demo: Waiting ");
	while (!hsmReady)		//wait until the HSM finishes
		;

	print_f("\nSYSTICK Demo: Finished - Check result");
	if (HSM_HSM2HTS.U != (0xCCCC0000 | CMD_RUN_SYSTICK))
	{
		print_f("\nSYSTICK_DEMO: Finished - Failed\n");
		__debug(); // not the correct response or timeout
	}
	for (i = 0; i < 0x100; i += 1)
	{
		if (HSM2HOSTbuf[i] > 200)	//check if response time is too big
		{
			errors++;
		}
	}
	if (errors > SYSTICK_ERROR_THRESHOLD)
	{
		print_f("\nSYSTICK Demo: Finished - Failed\n");
		__debug();
	}

	print_f("\nSYSTICK Demo: Finished - Success\n");
}

