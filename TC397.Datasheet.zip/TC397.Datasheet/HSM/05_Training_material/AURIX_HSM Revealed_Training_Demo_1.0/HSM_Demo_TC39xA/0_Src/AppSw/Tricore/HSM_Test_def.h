/*
 * HSM_Test_def.h
 */

#ifndef HSM_TEST_DEF_H_
#define HSM_TEST_DEF_H_


#define CMD_SETADDR_HOST2HSMBUF		0
#define CMD_SETADDR_HSM2HOSTBUF		1
#define CMD_RUN_SYSTICK				2
#define CMD_RUN_TRNG				3
#define CMD_AES_ECB_ENCRYPT			4
#define CMD_AES_ECB_DECRYPT			5
#define CMD_AES_CBC_ENCRYPT			6
#define CMD_AES_CBC_DECRYPT			7
#define CMD_ENCRYPTK0				8
#define CMD_DECRYPTK0				9
#define CMD_SETSIZE_HOST2HSMBUF     10
#define CMD_HASH_SHA_256			11

extern volatile uint32 HOST2HSMbuf[0x100];
extern volatile uint32 HSM2HOSTbuf[0x100];

extern volatile uint32 buf_temp[0x100];


extern volatile uint32 hsmInitFlag;
extern volatile uint32 hsmEncryptionEnd;
extern volatile uint32 hsmHashEnd;
extern volatile uint32 hsmReady;

void DBG_Memory_Trace_Init(void);
void DBG_Store_Trace(unsigned long id, unsigned long p0, unsigned long p1,
        unsigned long p2, unsigned long p3, unsigned long p4, unsigned long p5, ...);
extern unsigned long str_dbg(const char *input_chars);

extern void hsm_aes_ecb_Test(void);
extern void hsm_aes_cbc_Test(void);
extern void hsm_trng_Test(void);
extern void hsm_sysTick_Test(void);
extern void HashSha256_Test(void);
extern uint32 ChangeEndianness (uint32 i);

#include "Cpu/Irq/IfxCpu_Irq.h"

#endif /* HSM_TEST_DEF_H_ */
