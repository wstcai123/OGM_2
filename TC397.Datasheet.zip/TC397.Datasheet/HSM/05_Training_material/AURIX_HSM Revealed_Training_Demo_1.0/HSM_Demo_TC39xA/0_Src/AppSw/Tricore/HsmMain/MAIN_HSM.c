#define OS_COMMON_GLOBALS
#include "Ifx_Types.h"
#include "IfxPort.h"
#include "IfxSrc.h"
#include "IfxScuCcu.h"
#include "IfxStm.h"
#include "IfxCpu.h"
#include "IfxCpu_Irq.h"
#include "IfxCpu_Intrinsics.h"
#include <common.h>
#include "registers_hsm.h"
#include "HSM_Test_def.h"
#include "MAIN_HSM.h"
#include "Test_Print.h"


IFX_INLINE void setOutputPin (Ifx_P * port, uint8 pin, boolean state);

#define LED0_BLINK_INTERVAL_IN_SECONDS (1)
#define LED1_BLINK_INTERVAL_IN_SECONDS (2)
#define LED2_BLINK_INTERVAL_IN_SECONDS (4)

#define STM0_ISR_PRIORITY 10
#define STM1_ISR_PRIORITY 11
#define STM2_ISR_PRIORITY 12

void main_hsm(void);
void DemoApp_DummyFct(void);
void DemoApp_PrintChoices(void);
void DemoApp_CallMenuFct (char *my_fct_name);

const DemoApp_FctListType DemoApp_FctList[] =
{
  {" " ,DemoApp_DummyFct, "............ HSM Demo Examples..............."},
  {"1",hsm_sysTick_Test, "  SYSTICK Demo"},
  {"2",hsm_aes_ecb_Test, "  AES ECB Demo"},
  {"3",hsm_aes_cbc_Test, "  AES CBC Demo"},
  {"4",HashSha256_Test, "  HASH SHA-256 Demo"}
};

const DemoApp_MenuType DemoApp_DemoMenu=
{
  sizeof(DemoApp_FctList) / sizeof(DemoApp_FctListType),
  &DemoApp_FctList[0]
};

DemoApp_MenuType const *DemoApp_Menu_p;
char szString[80];
uint32 str_pos; /* position of the pointer in the receive buffer */

volatile uint32 Core0_Task0_count;
volatile uint8 Core0LedBlink;
volatile uint32 Core0_StmEventPassed = 0;
volatile uint32 Core1_Task0_count;
volatile uint8 Core1LedBlink;
volatile uint32 Core1_StmEventPassed = 0;
volatile uint32 Core2_Task0_count;
volatile uint8 Core2LedBlink;
volatile uint32 Core2_StmEventPassed = 0;

/* *INDENT-OFF* */
#if defined(__DCC__)
asm volatile uint32 *IfxCpu_Trap_getReturnAddress (void)
{
%
!"%a2"
	mov.aa %a2, %a11
}
#elif defined(__GNUC__)
IFX_INLINE uint32 *IfxCpu_Trap_getReturnAddress (void)
{
    uint32 *retAddr;
  __asm ("mov.aa %0, %%a11":"=a" (retAddr));
    return retAddr;
}

#elif defined(__TASKING__)
IFX_INLINE uint32 *IfxCpu_Trap_getReturnAddress (void)
{
	uint32 *retAddr;
  __asm ("mov.aa %0, a11":"=a" (retAddr));
    return retAddr;
}
#else
#error Compiler unsupported
#endif
/* *INDENT-ON* */

/**!
 * HSM Test Code Entry Point
 */
void main_hsm(void)
{
	int char_val;

	DemoApp_Menu_p = &DemoApp_DemoMenu;
	str_pos=0;

	DemoApp_PrintChoices();
	print_f("\nEnter Option Number: ");
	  for (;;)
	  {
		char_val = getlineWithPos(szString, sizeof szString - 1,&str_pos);
		if (char_val == CR)
		{
			str_pos = 0;
			print_f("\n\n");
			DemoApp_CallMenuFct(szString);
			DemoApp_PrintChoices();
		    print_f("\nEnter Option Number: ");
		}
	  }
}

/*******************************************************************************
** Syntax : void DemoApp_CallMenuFct(char *)                                  **
**                                                                            **
** Service ID:   : NA                                                         **
**                                                                            **
** Sync/Async:   : Synchronous                                                **
**                                                                            **
** Reentrancy:   : Non Reentrant                                              **
**                                                                            **
** Parameters (in): char describing the function                              **
**                                                                            **
** Parameters (out): none                                                     **
**                                                                            **
** Return value: none                                                         **
**                                                                            **
** Description : call the demo function corresponding to the parameter        **
*******************************************************************************/
void DemoApp_CallMenuFct (char *my_fct_name)
{
  uint32 cnt;
  uint32 cnt_max = DemoApp_Menu_p->size;

  for (cnt=0;cnt<cnt_max;cnt++)
  {
    if(DemoApp_Menu_p->list[cnt].fct_name[0] == my_fct_name[0])
    {
        (* DemoApp_Menu_p->list[cnt].fct_p)();

        return;
    }
  }
  print_f("\nEntered Option is not valid, Please Try again\n");
}

/*******************************************************************************
** Syntax : void DemoApp_PrintChoices(void)                                   **
**                                                                            **
** Service ID:   : NA                                                         **
**                                                                            **
** Sync/Async:   : Synchronous                                                **
**                                                                            **
** Reentrancy:   : Non Reentrant                                              **
**                                                                            **
** Parameters (in): none                                                      **
**                                                                            **
** Parameters (out): none                                                     **
**                                                                            **
** Return value: none                                                         **
**                                                                            **
** Description : print choices                                                **
*******************************************************************************/
void DemoApp_PrintChoices(void)
{
  uint32 cnt;
  uint32 cnt_max = DemoApp_Menu_p->size;

  print_f("\n");
  for (cnt=0;cnt<cnt_max;cnt++)
  {
    print_f(" <%s>: %s\n",DemoApp_Menu_p->list[cnt].fct_name,
                          DemoApp_Menu_p->list[cnt].fct_desc);
  }
}

void DemoApp_DummyFct(void)
{
	/* Just loop */
	print_f("\n Option is not valid ");
}


IFX_INTERRUPT (Stm0_Isr, 0, STM0_ISR_PRIORITY)
{
    uint32 stmTicks;
    __enable ();
    Core0_StmEventPassed = 1;
    stmTicks = (uint32) (LED0_BLINK_INTERVAL_IN_SECONDS * IfxStm_getFrequency (&MODULE_STM0));
    IfxStm_updateCompare (&MODULE_STM0, 0, IfxStm_getCompare (&MODULE_STM0, 0) + stmTicks);
    Core0LedBlink ^= 1;
    setOutputPin (&MODULE_P33, 4, Core0LedBlink);
    //test_a11 = IfxCpu_Trap_getReturnAddress ();
}

#if (IFXCPU_NUM_MODULES > 1)

IFX_INTERRUPT (Stm1_Isr, 0, STM1_ISR_PRIORITY)
{
    uint32 stmTicks;
    __enable ();
    Core1_StmEventPassed = 1;
    stmTicks = (uint32) (LED1_BLINK_INTERVAL_IN_SECONDS * IfxStm_getFrequency (&MODULE_STM1));
    IfxStm_updateCompare (&MODULE_STM1, 0, IfxStm_getCompare (&MODULE_STM1, 0) + stmTicks);
    Core1LedBlink ^= 1;
    setOutputPin (&MODULE_P33, 5, Core1LedBlink);
}
#endif /*#if (IFXCPU_NUM_MODULES > 1)*/

#if (IFXCPU_NUM_MODULES > 2)

IFX_INTERRUPT (Stm2_Isr, 1, STM2_ISR_PRIORITY)
{
    uint32 stmTicks;
    __enable ();
    Core2_StmEventPassed = 1;
    stmTicks = (uint32) (LED2_BLINK_INTERVAL_IN_SECONDS * IfxStm_getFrequency (&MODULE_STM2));
    IfxStm_updateCompare (&MODULE_STM2, 0, IfxStm_getCompare (&MODULE_STM2, 0) + stmTicks);
    Core2LedBlink ^= 1;
    setOutputPin (&MODULE_P33, 6, Core2LedBlink);
}
#endif

IFX_INLINE void setOutputPin (Ifx_P * port, uint8 pin, boolean state)
{
    if (state)
    {
        IfxPort_setPinState (port, pin, IfxPort_State_high);
    }
    else
    {
        IfxPort_setPinState (port, pin, IfxPort_State_low);
    }
}

void Initialize_StmTicks (void)
{
    IfxStm_CompareConfig stmCompareConfig;
    //    test_var= 1;
    // suspend by debugger enabled
    IfxStm_enableOcdsSuspend (&MODULE_STM0);
#if (IFXCPU_NUM_MODULES > 1)
    IfxStm_enableOcdsSuspend (&MODULE_STM1);
#endif /*#if (IFXCPU_NUM_MODULES > 1)*/
#if (IFXCPU_NUM_MODULES > 2)
    IfxStm_enableOcdsSuspend (&MODULE_STM2);
#endif
    //Call the constructor of configuration
    IfxStm_initCompareConfig (&stmCompareConfig);
    //Modify only the number of ticks and enable the trigger output
    stmCompareConfig.ticks = 1000;  /*Interrupt after 1000 ticks from now */
    stmCompareConfig.triggerPriority = STM0_ISR_PRIORITY;
    stmCompareConfig.typeOfService = IfxSrc_Tos_cpu0;

    //Now Compare functionality is initialized
    IfxStm_initCompare (&MODULE_STM0, &stmCompareConfig);

#if (IFXCPU_NUM_MODULES > 1)
    stmCompareConfig.triggerPriority = STM1_ISR_PRIORITY;
    stmCompareConfig.typeOfService = IfxSrc_Tos_cpu0;
    IfxStm_initCompare (&MODULE_STM1, &stmCompareConfig);
#endif /*#if (IFXCPU_NUM_MODULES > 1)*/

#if (IFXCPU_NUM_MODULES > 2)
    stmCompareConfig.triggerPriority = STM2_ISR_PRIORITY;
    stmCompareConfig.typeOfService = IfxSrc_Tos_cpu0;
    IfxStm_initCompare (&MODULE_STM2, &stmCompareConfig);
#endif
}

void myExample_InterruptsInit (void)
{
    IfxPort_setPinMode (&MODULE_P33, 4, IfxPort_Mode_outputPushPullGeneral);
#if (IFXCPU_NUM_MODULES > 1)
    IfxPort_setPinMode (&MODULE_P33, 5, IfxPort_Mode_outputPushPullGeneral);
#endif /*#if (IFXCPU_NUM_MODULES > 1)*/
#if (IFXCPU_NUM_MODULES > 2)
    IfxPort_setPinMode (&MODULE_P33, 6, IfxPort_Mode_outputPushPullGeneral);
#endif

#if defined(IFX_USE_SW_MANAGED_INT)
    interruptHandlerInstall (STM0_ISR_PRIORITY, (uint32) Stm0_Isr);
#if (IFXCPU_NUM_MODULES > 1)
    interruptHandlerInstall (STM1_ISR_PRIORITY, (uint32) Stm1_Isr);
#endif /*#if (IFXCPU_NUM_MODULES > 1)*/
#if (IFXCPU_NUM_MODULES > 2)
    interruptHandlerInstall (STM2_ISR_PRIORITY, (uint32) Stm2_Isr);
#endif /*#if (IFXCPU_NUM_MODULES > 2)*/
#endif

    Initialize_StmTicks ();
}
