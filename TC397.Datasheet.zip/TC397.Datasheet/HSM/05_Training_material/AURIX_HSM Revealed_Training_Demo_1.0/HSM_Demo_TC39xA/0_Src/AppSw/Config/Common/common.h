/**
* \file
* \brief Common Include File 
*
* The Include Structure uses this file as a common include file.
* Therefore nearly all definitions are done here.
*/

#ifndef COMMON_H
#define COMMON_H

#include "Ifx_reg.h"

/*
 * Most datatypes are already defined in the CPU abstraction module. At this point, we need to
 * define some substitutions for the operating system sourcecode.
 */
typedef unsigned char	BOOLEAN;	/*!< \brief Boolean value                   */
typedef unsigned char	INT8U;		/*!< \brief Unsigned 8 bit quantity         */
typedef signed char		INT8S;		/*!< \brief Signed 8 bit quantity           */
typedef unsigned short	INT16U;		/*!< \brief Unsigned 16 bit quantity        */
typedef signed short	INT16S;		/*!< \brief Signed 16 bit quantity          */
typedef unsigned long	INT32U;		/*!< \brief Unsigned 32 bit quantity        */
typedef signed long		INT32S;		/*!< \brief Signed 32 bit quantity          */

typedef INT32U OS_STK;          	/*!< \brief OS: Stack value                 */
typedef INT32U OS_CPU_SR;       	/*!< \brief OS: ICR Register                */

#include <stdio.h>
#include <stdlib.h>
#include "Std_Types.h"
#include "config_interface.h"
#include "IfxCpu_Intrinsics.h"


#ifdef  OS_COMMON_GLOBALS
#define OS_COMMON_EXT           /*!< \brief normal definition of variable      */
#else
#define OS_COMMON_EXT  extern   /*!< \brief external definition of variable      */
#endif

#define PATTERN_VERSION	0x02000000      /*!< \brief version of the Pattern (actual 2.00, 2x8bit+16bit PTE version)     */

// 1ms Counter
#define OS_TICKS_PER_SEC        1000    				/* Set the number of ticks in one second */
#define STM_CLK      (CONFIG_MISC._SPB_frequency_set)   /*!< \brief STM Clock is SYS Clock      */
#define STM0_RELOAD  (STM_CLK / OS_TICKS_PER_SEC)       /*!< \brief Reload Value for System Timer 0, 1ms period for CPU */


#define MEM_TRACE_MAX			0x800     	/*!< \brief size of trace ring buffer in ints */
#define MEM_TRACE_ADDR			0x7001A000	/*!< \brief start address of trace ring buffer */
#define MEM_TRACE_ID_INIT		0x1   		/*!< \brief identifier for trace ring buffer initialization */
#define MEM_TRACE_ID_TASKSW		0x2 		/*!< \brief identifier for trace ring buffer task switch */
#define MEM_TRACE_ISR_BEGIN		0   		/*!< \brief set to 1 for a trace ring buffer entry on interrupt */
#define MEM_TRACE_TASKSW		0      		/*!< \brief set to 1 for a trace ring buffer entry on task switch */
#define MEM_TRACE_INIT			1        	/*!< \brief set to 1 for a trace ring buffer initialization */
#define MEM_TRACE_WCPATTERN		0   		/*!< \brief set to 1 for a trace ring buffer worst case pattern */

OS_COMMON_EXT INT32U *pOS_MEM_TRACE;    /*!< \brief pointer to actual entry of trace ring buffer */
OS_COMMON_EXT INT32U OS_MEM_TRACE_cnt;  /*!< \brief actual index of trace ring buffer */


/* Interrupt definition */
#define DMA_ERRINT				0x2     /*!< \brief Interrupt Level  */
#define SBCU_ERRINT				0x6     /*!< \brief Interrupt Level  */
#define SRI_ERRINT				0x7     /*!< \brief Interrupt Level  */
#define SCU_FLASHERRINT			0x8     /*!< \brief Interrupt Level  */
#define DMA_CH07INT				0x13    /*!< \brief Interrupt Level  */
#define ASC0_ERRINT				0x14    /*!< \brief Interrupt Level  */
#define DMA_CH11INT				0x15    /*!< \brief Interrupt Level  */
#define ASC1_ERRINT				0x16    /*!< \brief Interrupt Level  */
#define DMA_CH01INT				0x17    /*!< \brief Interrupt Level  */
#define SPI0_ERRINT				0x18    /*!< \brief Interrupt Level  */
#define DMA_CH03INT				0x19    /*!< \brief Interrupt Level  */
#define SPI1_ERRINT				0x1A    /*!< \brief Interrupt Level  */
#define DMA_CH05INT				0x1B    /*!< \brief Interrupt Level  */
#define SPI2_ERRINT				0x1C    /*!< \brief Interrupt Level  */
#define DMA_CH00INT				0x1D    /*!< \brief Interrupt Level  */
#define DMA_CH02INT				0x1E    /*!< \brief Interrupt Level  */
#define DMA_CH04INT				0x1F    /*!< \brief Interrupt Level  */
#define DMA_CH06INT				0x20    /*!< \brief Interrupt Level  */
#define DMA_CH10INT				0x21    /*!< \brief Interrupt Level  */
#define DMA_CH12INT				0x22    /*!< \brief Interrupt Level  */
#define DMA_CH13INT				0x23    /*!< \brief Interrupt Level  */
#define DMA_CH14INT				0x24    /*!< \brief Interrupt Level  */
#define DMA_CH15INT				0x25    /*!< \brief Interrupt Level  */
#define DMA_CH16INT				0x26    /*!< \brief Interrupt Level  */
#define CAN_SRN0INT     		0x28    /*!< \brief Interrupt Level  */
#define CAN_SRN1INT     		0x29    /*!< \brief Interrupt Level  */
#define CAN_SRN2INT     		0x2A    /*!< \brief Interrupt Level  */
#define CAN_SRN3INT     		0x2B    /*!< \brief Interrupt Level  */
#define CAN_SRN4INT     		0x2C    /*!< \brief Interrupt Level  */
#define CAN_SRN5INT     		0x2D    /*!< \brief Interrupt Level  */
#define CAN_SRN6INT    			0x2E    /*!< \brief Interrupt Level  */
#define CAN_SRN7INT     		0x2F    /*!< \brief Interrupt Level  */
#define CPU_APPLPROC0WAKEINT 	0x30    /*!< \brief Interrupt Level Wake Proc0 */
#define CPU_APPLPROC0MSGINT 	0x31    /*!< \brief Interrupt Level Msg From Proc0 */
#define CPU_APPLPROC1WAKEINT	0x32	/*!< \brief Interrupt Level Wake Proc1 */
#define CPU_APPLPROC1MSGINT 	0x33    /*!< \brief Interrupt Level Msg From Proc1 */
#define ETH_INT         		0x34    /*!< \brief Interrupt Level for Ethernet */
#define PSI5_CH0INT  			0x35    /*!< \brief Interrupt Level  */
#define PSI5_CH1INT  			0x36    /*!< \brief Interrupt Level  */
#define PSI5_CH2INT  			0x37    /*!< \brief Interrupt Level  */
#define PSI5_ERRINT  			0x38    /*!< \brief Interrupt Level  */
#define HSSL_RXINT   			0x39    /*!< \brief Interrupt Level  */
#define HSSL_ERRINT  			0x3A    /*!< \brief Interrupt Level  */
#define HWIO_GROUP_LEVEL 		0x3E   	/*!< \brief Interrupt Level  */
#define OS_TICK_IRQ_PRIO 		0x3F   	/*!< \brief Interrupt Level  */
#define GTM_MCS00INT			0x40    /*!< \brief Interrupt Level  */
#define GTM_MCS01INT			0x41    /*!< \brief Interrupt Level  */
#define GTM_MCS02INT			0x42    /*!< \brief Interrupt Level  */
#define GTM_MCS03INT			0x43    /*!< \brief Interrupt Level  */
#define GTM_MCS04INT			0x44    /*!< \brief Interrupt Level  */
#define GTM_MCS05INT			0x45    /*!< \brief Interrupt Level  */
#define GTM_MCS06INT			0x46    /*!< \brief Interrupt Level  */
#define GTM_MCS07INT			0x47    /*!< \brief Interrupt Level  */
#define SENT_CH2INT				0x48    /*!< \brief Interrupt Level  */
#define SENT_CH3INT  			0x49    /*!< \brief Interrupt Level  */
#define SENT_CH4INT  			0x4A    /*!< \brief Interrupt Level  */
#define SENT_CH5INT  			0x4B    /*!< \brief Interrupt Level  */
#define SENT_CH6INT  			0x4C    /*!< \brief Interrupt Level  */
#define SENT_CH7INT  			0x4D    /*!< \brief Interrupt Level  */
#define SENT_CH8INT  			0x4E    /*!< \brief Interrupt Level  */
#define SENT_CH9INT  			0x4F    /*!< \brief Interrupt Level  */
#define SENT_ERRINT  			0x50    /*!< \brief Interrupt Level  */
#define IFLEX_TXINT	 			0x51   	/*!< \brief Interrupt Level  */
#define IFLEX_ERRINT 			0x52    /*!< \brief Interrupt Level  */
#define MEMCHK_DMAUPDATEINT 	0x53    /*!< \brief Interrupt Level  */
#define SMU0INT 				0x54    /*!< \brief Interrupt Level  */
#define SMU1INT 				0x55    /*!< \brief Interrupt Level  */
#define SMU2INT 				0x56    /*!< \brief Interrupt Level  */
#define VADC0INT 				0x57    /*!< \brief Interrupt Level for VADC group 0 */
#define VADC1INT 				0x58    /*!< \brief Interrupt Level for VADC group 1 */
#define VADC2INT 				0x59    /*!< \brief Interrupt Level for VADC group 2 */
#define VADC3INT 				0x5A    /*!< \brief Interrupt Level for VADC group 3 */
#define VADC4INT 				0x5B    /*!< \brief Interrupt Level for VADC group 4 */
#define VADC5INT 				0x5C    /*!< \brief Interrupt Level for VADC group 5 */
#define VADC6INT 				0x5D    /*!< \brief Interrupt Level for VADC group 6 */
#define VADC7INT 				0x5E    /*!< \brief Interrupt Level for VADC group 7 */
#define DSADC0INT 				0x5F    /*!< \brief Interrupt Level for DSADC channel 0 */
#define DSADC1INT 				0x60    /*!< \brief Interrupt Level for DSADC channel 1 */
#define DSADC2INT 				0x61    /*!< \brief Interrupt Level for DSADC channel 2 */
#define DSADC3INT 				0x62    /*!< \brief Interrupt Level for DSADC channel 3 */
#define DSADC4INT 				0x63    /*!< \brief Interrupt Level for DSADC channel 4 */
#define DSADC5INT 				0x64    /*!< \brief Interrupt Level for DSADC channel 5 */
#define DMA_ME1CH00INT 			0x65    /*!< \brief Interrupt Level for DMA ME1 channel 0 */
#define DMA_ME1CH01INT 			0x66    /*!< \brief Interrupt Level for DMA ME1 channel 1 */


// List of common Functions
void OS_Memory_Trace_Init (void);
void OS_Store_Trace (uint32 id, uint32 p0, uint32 p1, uint32 p2, uint32 p3, uint32 p4, uint32 p5);

#ifdef WINDRIVER
#pragma section CODE X
#endif

void FAIL (TFAIL_STATUS x, uint32 y);
void FAIL_TRAP (TFAIL_STATUS x, uint32 y, uint32 din);


#ifdef GNU
#pragma section ".bss.noclear" aw
#elif __TASKING__
#pragma noclear
#elif WINDRIVER
#pragma section SDATA ".data_noclear" ".bss_noclear" far-absolute
#else
#error "Please specify Compiler."
#endif

OS_COMMON_EXT TFAIL_BUF FAIL_BUF;       /*!< \brief Failure Buffer, will be filled with Debug Information and stored to Program Flash */
OS_COMMON_EXT volatile uint32 _hooksignal;      /*! \brief if startvector is 0xA0000004 0x0000EEEE is written, else 0x0000AAAA */
OS_COMMON_EXT uint32 interruptHandlerVectorTable[256];  /*!< \brief Interrupt Addresses */

#ifdef GNU
#pragma section
#pragma section ".sbss.CONFIG" aws 4
#elif __TASKING__
#pragma clear
#pragma section a0bss  "CONFIG"
#pragma align 4
#elif WINDRIVER
#pragma section SDATA ".data_config" ".sbss_config" far-absolute
#pragma pack(4,4,0)
#else
#error "Please specify Compiler."
#endif

OS_COMMON_EXT TCONFIG_APPLPROC	CONFIG_APPLPROC0;	/*!< \brief driver configuration for Application CPU0 */
OS_COMMON_EXT TCONFIG_APPLPROC	CONFIG_APPLPROC1;	/*!< \brief driver configuration for Application CPU1 */
OS_COMMON_EXT TCONFIG_STATUS 	CONFIG_STATUS;		/*!< \brief driver configuration ... */
OS_COMMON_EXT TCONFIG_PORTIOCR	CONFIG_PORTIOCR;	/*!< \brief driver configuration for Port IOCR registers */
OS_COMMON_EXT TCONFIG_PORTPDR	CONFIG_PORTPDR;		/*!< \brief driver configuration for Port PDR  */
OS_COMMON_EXT TCONFIG_SYSCLK	CONFIG_SYSCLK;		/*!< \brief driver configuration for SYSCLK */
OS_COMMON_EXT TCONFIG_MISC		CONFIG_MISC;		/*!< \brief driver configuration for misc. items */
OS_COMMON_EXT TCONFIG_WDT		CONFIG_WDT;			/*!< \brief driver configuration for watchdog */
OS_COMMON_EXT TCONFIG_SPI		CONFIG_SPI0;		/*!< \brief driver configuration for SPI0 */
OS_COMMON_EXT TCONFIG_SPI		CONFIG_SPI1;		/*!< \brief driver configuration for SPI1 */
OS_COMMON_EXT TCONFIG_ASC		CONFIG_ASC0;		/*!< \brief driver configuration for ASC0 */
OS_COMMON_EXT TCONFIG_ASC		CONFIG_ASC1;		/*!< \brief driver configuration for ASC1 */
OS_COMMON_EXT TCONFIG_STM		CONFIG_STM;			/*!< \brief driver configuration for System Timer */
OS_COMMON_EXT TCONFIG_SMU		CONFIG_SMU;			/*!< \brief driver configuration for SMU */
OS_COMMON_EXT TCONFIG_ALL		CONFIG_ALL;			/*!< \brief config collection */

#ifdef GNU
#pragma section
#elif __TASKING__
#pragma section a0bss
#pragma align restore
#elif WINDRIVER
#pragma section SDATA RW
#else
#error "Please specify Compiler."
#endif


#ifndef SETREG
# define SETREG(x,y) { uint32 *pmem; pmem=(uint32 *) (x); *pmem=y; }
#endif

// this macro is used to address SFRs memlocations directly in C programs
#ifndef MEM
# define MEM(address) (*((volatile unsigned int *)(address)))   // makes live easier
#endif
#ifndef MEM16
# define MEM16(address) (*((volatile unsigned short *)(address)))
#endif
#ifndef MEM8
# define MEM8(address) (*((volatile unsigned char *)(address)))
#endif

#endif
