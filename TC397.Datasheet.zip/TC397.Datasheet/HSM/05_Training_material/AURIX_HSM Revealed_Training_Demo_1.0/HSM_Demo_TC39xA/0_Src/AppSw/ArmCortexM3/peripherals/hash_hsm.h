// =============================================================================
// @file:    hash_hsm.h (HRM Doc_State_importance_=_required_Revision_2.0-BUILD-147)
// @purpose: Register Definition File for Infineon HSM Device Series
//
// THE SOURCE CODE AND ITS RELATED DOCUMENTATION IS PROVIDED "AS IS". INFINEON
// TECHNOLOGIES MAKES NO OTHER WARRANTY OF ANY KIND,WHETHER EXPRESS,IMPLIED OR,
// STATUTORY AND DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF MERCHANTABILITY,
// SATISFACTORY QUALITY, NON INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
//
// THE SOURCE CODE AND DOCUMENTATION MAY INCLUDE ERRORS. INFINEON TECHNOLOGIES
// RESERVES THE RIGHT TO INCORPORATE MODIFICATIONS TO THE SOURCE CODE IN LATER
// REVISIONS OF IT, AND TO MAKE IMPROVEMENTS OR CHANGES IN THE DOCUMENTATION OR
// THE PRODUCTS OR TECHNOLOGIES DESCRIBED THEREIN AT ANY TIME.
//
// INFINEON TECHNOLOGIES SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
// CONSEQUENTIAL DAMAGE OR LIABILITY ARISING FROM YOUR USE OF THE SOURCE CODE OR
// ANY DOCUMENTATION, INCLUDING BUT NOT LIMITED TO, LOST REVENUES, DATA OR
// PROFITS, DAMAGES OF ANY SPECIAL, INCIDENTAL OR CONSEQUENTIAL NATURE, PUNITIVE
// DAMAGES, LOSS OF PROPERTY OR LOSS OF PROFITS ARISING OUT OF OR IN CONNECTION
// WITH THIS AGREEMENT, OR BEING UNUSABLE, EVEN IF ADVISED OF THE POSSIBILITY OR
// PROBABILITY OF SUCH DAMAGES AND WHETHER A CLAIM FOR SUCH DAMAGE IS BASED UPON
// WARRANTY, CONTRACT, TORT, NEGLIGENCE OR OTHERWISE.
//
// (C)Copyright INFINEON TECHNOLOGIES All rights reserved
// =============================================================================



#ifndef __HASH_HSM_H__
#define __HASH_HSM_H__

typedef enum {false = 0, true = 1} BoolFalseTrue_t;
//typedef unsigned char  uint8_t;
//typedef unsigned long  uint32_t;
//typedef unsigned long long uint64_t;


#define __IFX_HASH_VERSION_MAIN         (0x0)                               /* [31:24] MODULE main version   */
#define __IFX_HASH_VERSION_SUB          (0x0)                               /* [23:16] MODULE sub version    */
#define __IFX_HASH_VERSION_CONFIG       (0x0)                               /* [15:0]  MODULE config version */
#define __IFX_HASH_VERSION              ((__IFX_HASH_VERSION_MAIN << 24) | \
                                         (__IFX_HASH_VERSION_SUB << 16)  | \
                                          __IFX_HASH_VERSION_CONFIG)                  /* MODULE version number        */

/******************************************************************************/
/*              Device Specific Peripheral registers structures               */
/******************************************************************************/



/*------------- HASH Module     ----------------------------------------------*/

/** \\brief HASH Configuration Register */
typedef union
{
  struct
  {
  	uint32_t ALGO      : 2;  /**< \brief \Hash Algorithm */
  	uint32_t           : 1;  /**< \brief \internal Reserved */
  	uint32_t IV_MODE   : 1;  /**< \brief \Initialization Value Mode */
  	uint32_t ORDER_OUT : 1;  /**< \brief \Output Word Sequence Order */
  	uint32_t           : 1;  /**< \brief \internal Reserved */
  	uint32_t BEND_OUT  : 1;  /**< \brief \Output Byte Endianness */
  	uint32_t BEND_IN   : 1;  /**< \brief \Input Byte Endianness */
  	uint32_t           : 24; /**< \brief \internal Reserved  */
  }  B;

  /** \brief Unsigned access */
  uint32_t          U;
  /** \brief Signed access */
  uint32_t           I;
} HSM_HASH_CFG_Type;


/** \\brief Hash Data Input Register */
typedef union
{
  struct
  {
  	uint32_t CTRL_ACC : 1;   /**< \brief \Control Access */
  	uint32_t DATA_ACC : 1;   /**< \brief \Data Access */
  	uint32_t          : 14;  /**< \brief \internal Reserved */
  }  B;

  /** \brief Unsigned access */
  uint32_t          U;
  /** \brief Signed access */
  uint32_t           I;
} HSM_HASH_DATA_Type;

/** \\brief HASH Status Register */
typedef union
{
  struct
  {
  	uint32_t BSY   : 1;    /**< \brief \Busy Flag */
  	uint32_t IV_OK : 1;    /**< \brief \Initialization Vector OK */
  	uint32_t DF_NF : 1;    /**< \brief \Data FIFO Not Full */
  	uint32_t       : 5;    /**< \brief \Reserved */
  	uint32_t CNT   : 4;    /**< \brief \Result Counter */
  	uint32_t       : 20;    /**< \brief \Reserved */
  }  B;
  /** \brief Unsigned access */
  uint32_t          U;
  /** \brief Signed access */
  uint32_t           I;
} HSM_HASH_STAT_Type;

/** \\brief Hash Output Value Register */
typedef union
{
  struct
  {
  	uint32_t HASH_VAL: 32;  /**< \brief \Hash Output Value */
  }  B;

  /** \brief Unsigned access */
  uint32_t          U;
  /** \brief Signed access */
  uint32_t           I;
} HSM_HASH_VAL_Type;


typedef struct
{
  __IO HSM_HASH_CFG_Type CFG        ; // HASH Configuration Register
  __I  HSM_HASH_STAT_Type STAT                ; // HASH Status Register
  __IO uint32_t HASH_IVIN                ; // Hash Initialization Value Register
  __I  HSM_HASH_VAL_Type VAL                 ; // Hash Output Value Register
  __IO HSM_HASH_DATA_Type DATA                ; // Hash Data Input Register
} HSM_HASH_TypeDef;


/* HASH Configuration Register Definitions */
#define HASH_CFG_ALGO_Pos             0                                /**< \brief HASH_CFG: ALGO Position */
#define HASH_CFG_ALGO_Msk            (0x3ul << HASH_CFG_ALGO_Pos)      /**< \brief HASH_CFG: ALGO Mask */
#define HASH_CFG_ALGO_NONE           (0x0ul << HASH_CFG_ALGO_Pos)
#define HASH_CFG_ALGO_MD5            (0x1ul << HASH_CFG_ALGO_Pos)
#define HASH_CFG_ALGO_SHA1           (0x2ul << HASH_CFG_ALGO_Pos)
#define HASH_CFG_ALGO_SHA256         (0x3ul << HASH_CFG_ALGO_Pos)
#define HASH_CFG_IV_MODE_Pos          3                                /**< \brief HASH_CFG: IV_MODE Position */
#define HASH_CFG_IV_MODE_Msk         (0x1ul << HASH_CFG_IV_MODE_Pos)   /**< \brief HASH_CFG: IV_MODE Mask */
#define HASH_CFG_IV_MODE_NO_IV       (0x0ul << HASH_CFG_IV_MODE_Pos)
#define HASH_CFG_IV_MODE_USE_IV      (0x1ul << HASH_CFG_IV_MODE_Pos)
#define HASH_CFG_ORDER_OUT_Pos        4                                /**< \brief HASH_CFG: ORDER_OUT Position */
#define HASH_CFG_ORDER_OUT_Msk       (0x1ul << HASH_CFG_ORDER_OUT_Pos) /**< \brief HASH_CFG: ORDER_OUT Mask */
#define HASH_CFG_ORDER_OUT_LSW_FIRST (0x0ul << HASH_CFG_ORDER_OUT_Pos)
#define HASH_CFG_ORDER_OUT_MSW_FIRST (0x1ul << HASH_CFG_ORDER_OUT_Pos)
#define HASH_CFG_BEND_OUT_Pos         6                                /**< \brief HASH_CFG: BEND_OUT Position */
#define HASH_CFG_BEND_OUT_Msk        (0x1ul << HASH_CFG_BEND_OUT_Pos)  /**< \brief HASH_CFG: BEND_OUT Mask */
#define HASH_CFG_BEND_OUT_BIG        (0x0ul << HASH_CFG_BEND_OUT_Pos)
#define HASH_CFG_BEND_OUT_LIT        (0x1ul << HASH_CFG_BEND_OUT_Pos)
#define HASH_CFG_BEND_IN_Pos          7                                /**< \brief HASH_CFG: BEND_IN Position */
#define HASH_CFG_BEND_IN_Msk         (0x1ul << HASH_CFG_BEND_IN_Pos)   /**< \brief HASH_CFG: BEND_IN Mask */
#define HASH_CFG_BEND_IN_BIG         (0x0ul << HASH_CFG_BEND_IN_Pos)
#define HASH_CFG_BEND_IN_LIT         (0x1ul << HASH_CFG_BEND_IN_Pos)


#endif  /* __HASH_HSM_H__ */
