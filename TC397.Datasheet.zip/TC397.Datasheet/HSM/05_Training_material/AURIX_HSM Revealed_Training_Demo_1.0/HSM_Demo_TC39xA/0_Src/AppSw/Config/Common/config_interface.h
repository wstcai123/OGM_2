/**
* \file
* \brief Common Config Interface
*
* The Structures can be used for Hook Configuration
*/
#ifndef CONFIG_INTERFACE_H
#define CONFIG_INTERFACE_H
/*!< \enum LED Status */
/*!< \brief LED Status enumeration for P33.6 and P33.7 Leds Triboard */
typedef enum
{
  LEDP336ON_LEDP337ON,          /*!< \brief Not used */
  LEDP336ON_LEDP337OFF,         /*!< \brief Not used */
  LEDP336OFF_LEDP337ON,         /*!< \brief Not used */
  LEDP336BLINKY_LEDP337ON,      /*!< \brief Normal Operation */
  LEDP336ON_LEDP337BLINKY,      /*!< \brief Failure Buffer Full */
  LEDP336BLINKY_LEDP337BLINKY,  /*!< \brief Failure Buffer Erased */
  LEDP336BLINKY_LEDP337NBLINKY  /*!< \brief Software Reset */
} TBLINKY_STATUS;

/*!< \enum for Driver Status */
/*!< \brief enum for Driver Status */
typedef enum
{
  DRV_UNINIT,                   /*!< \brief The Driver is not initialized, use xxx_init() */
  DRV_READY,                    /*!< \brief The Driver is ready to use, use xxx_start() */
  DRV_BUSY,                     /*!< \brief The Driver is busy, use xxx_reqstop() */
  DRV_REQSTOP,                  /*!< \brief The Driver is moving to DRV_STOP, wait for DRV_UNINIT */
  DRV_STOP                      /*!< \brief The Driver stopped, wait for DRV_UNINIT */
} TDRV_STATUS;

/*!< \brief enum for Failure Identification, used in TFAIL_BUF */
typedef enum
{
  NO_FAIL,                      /*!< \brief Failure ID Application Pattern */
  ID_SDMAME0_ERR,               /*!< \brief Failure ID Application Pattern */
  ID_SDMAME1_ERR,               /*!< \brief Failure ID Application Pattern */
  ID_DMAME0_ERR,                /*!< \brief Failure ID Application Pattern */
  ID_DMAME1_ERR,                /*!< \brief Failure ID Application Pattern */
  EVENT_TASK1MS,                /*!< \brief Failure ID Application Pattern */
  EVENT_TASK5MS,                /*!< \brief Failure ID Application Pattern */
  EVENT_TASK10MS,               /*!< \brief Failure ID Application Pattern */
  EVENT_TASK20MS,               /*!< \brief Failure ID Application Pattern */
  EVENT_TASK50MS,               /*!< \brief Failure ID Application Pattern */
  EVENT_TASK100MS,              /*!< \brief Failure ID Application Pattern */
  TIMEOUT_TASK1MS,              /*!< \brief Failure ID Application Pattern */
  TIMEOUT_TASK5MS,              /*!< \brief Failure ID Application Pattern */
  TIMEOUT_TASK10MS,             /*!< \brief Failure ID Application Pattern */
  TIMEOUT_TASK20MS,             /*!< \brief Failure ID Application Pattern */
  TIMEOUT_TASK50MS,             /*!< \brief Failure ID Application Pattern */
  TIMEOUT_TASK100MS,            /*!< \brief Failure ID Application Pattern */
  DFLASH_PROGRAM0,              /*!< \brief Failure ID Application Pattern */
  DFLASH_PROGRAM1,              /*!< \brief Failure ID Application Pattern */
  DFLASH_PROGRAM2,              /*!< \brief Failure ID Application Pattern */
  PFLASH_PROGRAM0,              /*!< \brief Failure ID Application Pattern */
  PFLASH_PROGRAM1,              /*!< \brief Failure ID Application Pattern */
  PFLASH_PROGRAM2,              /*!< \brief Failure ID Application Pattern */
  TRAP_MMU,                     /*!< \brief Failure ID Application Pattern */
  TRAP_PROTECTION,              /*!< \brief Failure ID Application Pattern */
  TRAP_INSTRUCTION,             /*!< \brief Failure ID Application Pattern */
  TRAP_CONTEXT,                 /*!< \brief Failure ID Application Pattern */
  TRAP_BUS,                     /*!< \brief Failure ID Application Pattern */
  TRAP_ASSERTION,               /*!< \brief Failure ID Application Pattern */
  TRAP_NMI,                     /*!< \brief Failure ID Application Pattern */
  ID_BENCHMARK_DATA,            /*!< \brief Failure ID Application Pattern */
  ID_BENCHMARK_ERR,             /*!< \brief Failure ID Application Pattern */
  ID_GPIO_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_GPIO_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_IFLEX_DATA,                /*!< \brief Failure ID Application Pattern */
  ID_IFLEX_ERR,                 /*!< \brief Failure ID Application Pattern */
  ID_SPI0_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_SPI0_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_SPI0_RXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_SPI0_TXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_SPI1_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_SPI1_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_SPI1_RXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_SPI1_TXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_ASC0_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_ASC0_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_ASC0_RXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_ASC0_TXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_ASC1_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_ASC1_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_ASC1_RXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_ASC1_TXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_CAN01_DATA,                /*!< \brief Failure ID Application Pattern */
  ID_CAN01_ERR,                 /*!< \brief Failure ID Application Pattern */
  ID_CAN01_CANSRN2,             /*!< \brief Failure ID Application Pattern */
  ID_CAN01_CANSRN3,             /*!< \brief Failure ID Application Pattern */
  ID_CAN01_CANSRN6,             /*!< \brief Failure ID Application Pattern */
  ID_CAN01_CANSRN7,             /*!< \brief Failure ID Application Pattern */
  ID_VADC_MIN,                  /*!< \brief Failure ID Application Pattern */
  ID_VADC_MAX,                  /*!< \brief Failure ID Application Pattern */
  ID_VADC_ASCANGEN,             /*!< \brief Failure ID Application Pattern */
  ID_VADC_ASCANCH,              /*!< \brief Failure ID Application Pattern */
  ID_VADC_ASCANGR,              /*!< \brief Failure ID Application Pattern */
  ID_PLL_NO_LOCK,               /*!< \brief Failure ID Application Pattern */
  ID_PLL_NO_CRYSTAL,            /*!< \brief Failure ID Application Pattern */
  ID_ERAYPLL_NO_LOCK,           /*!< \brief Failure ID Application Pattern */
  ID_MEMCHK_DATA,               /*!< \brief Failure ID Application Pattern */
  ID_MEMCHK_ERR,                /*!< \brief Failure ID Application Pattern */
  ID_DSADC_DATA,                /*!< \brief Failure ID Application Pattern */
  ID_DSADC_ERR,                 /*!< \brief Failure ID Application Pattern */
  ID_DSADC_MIN,                 /*!< \brief Failure ID Application Pattern */
  ID_DSADC_MAX,                 /*!< \brief Failure ID Application Pattern */
  ID_DFLASH_DATA,               /*!< \brief Failure ID Application Pattern */
  ID_DFLASH_ERR,                /*!< \brief Failure ID Application Pattern */
  ID_SENT_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_SENT_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_SENT_MISC,                 /*!< \brief Failure ID Application Pattern */
  ID_PSI5_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_PSI5_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_PSI5_MISC,                 /*!< \brief Failure ID Application Pattern */
  ID_CCU6X_ERR,                 /*!< \brief Failure ID Application Pattern */
  ID_SPI2_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_SPI2_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_SPI2_RXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_SPI2_TXLOSTDMA,            /*!< \brief Failure ID Application Pattern */
  ID_SPI3_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_SPI3_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_MCDS_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_APPLCPU0_ERR,              /*!< \brief Failure ID Application Pattern */
  ID_PORTTOGGLE_TX0LOST,        /*!< \brief Failure ID Application Pattern */
  ID_PORTTOGGLE_TX1LOST,        /*!< \brief Failure ID Application Pattern */
  ID_PORTTOGGLE_TX1PENDING,     /*!< \brief Failure ID Application Pattern */
  ID_SMU_SRN0,                  /*!< \brief Failure ID Application Pattern */
  ID_SMU_SRN1,                  /*!< \brief Failure ID Application Pattern */
  ID_SMU_SRN2,                  /*!< \brief Failure ID Application Pattern */
  ID_INT_UNKNOWN,               /*!< \brief Failure ID Application Pattern */
  ID_MSC0_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_MSC0_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_MSC1_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_MSC1_ERR,                  /*!< \brief Failure ID Application Pattern */
  ID_UNKNOWN_FAIL,              /*!< \brief Failure ID Application Pattern */
  ID_GTMMCS0,                   /*!< \brief Failure ID Application Pattern */
  ID_SBCUERRINT,                /*!< \brief Failure ID Application Pattern */
  ID_SRIERRINT,                 /*!< \brief Failure ID Application Pattern */
  ID_ETH_DATA,                  /*!< \brief Failure ID Application Pattern */
  ID_ETH_ERR,                   /*!< \brief Failure ID Application Pattern */
  ID_HSSL_DATA,                 /*!< \brief Failure ID Application Pattern */
  ID_HSSL_ERR                   /*!< \brief Failure ID Application Pattern */
}
TFAIL_STATUS;


/*! \brief structure of Failure Buffer, register will copied in case of failures */
typedef struct
{
  TFAIL_STATUS FAIL_ID;         /*!< \brief Failure ID */
  uint32 failid_detail;         /*!< \brief additional informantion, e.g. channel of VADC */
  uint32 cpu0_dbgsr;            /*!< \brief registers of CPU0, IO Processor */
  uint32 cpu0_pc;
  uint32 cpu0_a10;
  uint32 cpu0_a11;
  uint32 cpu0_pcxi;
  uint32 cpu0_fcx;
  uint32 cpu0_lcx;
  uint32 cpu0_psw;
  uint32 cpu0_dstr;
  uint32 cpu0_datr;
  uint32 cpu0_deadd;
  uint32 cpu0_diear;
  uint32 cpu0_dietr;
  uint32 cpu0_pstr;
  uint32 cpu0_piear;
  uint32 cpu0_pietr;

  uint32 cpu1_dbgsr;            /*!< \brief registers of CPU1, Application Processor 0 */
  uint32 cpu1_pc;
  uint32 cpu1_a10;
  uint32 cpu1_a11;
  uint32 cpu1_pcxi;
  uint32 cpu1_fcx;
  uint32 cpu1_lcx;
  uint32 cpu1_psw;
  uint32 cpu1_dstr;
  uint32 cpu1_datr;
  uint32 cpu1_deadd;
  uint32 cpu1_diear;
  uint32 cpu1_dietr;
  uint32 cpu1_pstr;
  uint32 cpu1_piear;
  uint32 cpu1_pietr;

  uint32 cpu2_dbgsr;            /*!< \brief registers of CPU2, Application Processor 1 */
  uint32 cpu2_pc;
  uint32 cpu2_a10;
  uint32 cpu2_a11;
  uint32 cpu2_pcxi;
  uint32 cpu2_fcx;
  uint32 cpu2_lcx;
  uint32 cpu2_psw;
  uint32 cpu2_dstr;
  uint32 cpu2_datr;
  uint32 cpu2_deadd;
  uint32 cpu2_diear;
  uint32 cpu2_dietr;
  uint32 cpu2_pstr;
  uint32 cpu2_piear;
  uint32 cpu2_pietr;

  uint32 scu_rststat;           /*!< \brief registers of SCU (incl. PLL, WDT, IDs... */
  uint32 scu_trapstat;
  uint32 scu_osccon;
  uint32 scu_pllstat;
  uint32 scu_pllcon0;
  uint32 scu_pllcon1;
  uint32 scu_pllcon2;
  uint32 scu_plleraystat;
  uint32 scu_plleraycon0;
  uint32 scu_plleraycon1;
  uint32 scu_ccucon0;
  uint32 scu_ccucon1;
  uint32 scu_ccucon2;
  uint32 scu_pmcsr0;
  uint32 scu_pmcsr1;
  uint32 scu_pmcsr2;
  uint32 scu_wdtssr;
  uint32 scu_wdtcpu0sr;
  uint32 scu_wdtcpu1sr;
  uint32 scu_wdtcpu2sr;
  uint32 scu_lclcon0;
  uint32 scu_lclcon1;
  uint32 scu_evrstat;
  uint32 scu_dtsstat;
  uint32 scu_ststat;
  uint32 scu_chipid;
  uint32 _startup_id;

  uint32 sdma_errsr0;           /*!< \brief registers of SDMA */
  uint32 sdma_errsr1;
  uint32 dma_errsr0;            /*!< \brief registers of DMA */
  uint32 dma_errsr1;

  uint32 stm0_tim0;             /*!< \brief registers of System Timers */
  uint32 stm0_cap;
  uint32 stm1_tim0;
  uint32 stm1_cap;
  uint32 stm2_tim0;
  uint32 stm2_cap;

  uint32 smu_ag0;               /*!< \brief registers of SMU */
  uint32 smu_ag1;
  uint32 smu_ag2;
  uint32 smu_ag3;
  uint32 smu_ag4;
  uint32 smu_ag5;

  uint32 xbar_intsat;           /*!< \brief registers of SRI/XBAR Bus */
  uint32 xbar_idintsat;
  uint32 xbar_idinten;
  uint32 xbar_erraddrd;
  uint32 xbar_erraddr0;
  uint32 xbar_erraddr1;
  uint32 xbar_erraddr3;
  uint32 xbar_erraddr4;
  uint32 xbar_erraddr5;
  uint32 xbar_erraddr6;
  uint32 xbar_erraddr7;
  uint32 xbar_erraddr8;
  uint32 xbar_erraddr9;
  uint32 xbar_errd;
  uint32 xbar_err0;
  uint32 xbar_err1;
  uint32 xbar_err3;
  uint32 xbar_err4;
  uint32 xbar_err5;
  uint32 xbar_err6;
  uint32 xbar_err7;
  uint32 xbar_err8;
  uint32 xbar_err9;

  uint32 sbcu_econ;             /*!< \brief registers of SBCU, SPB/FPI Bus */
  uint32 sbcu_eadd;
  uint32 sbcu_edat;

  uint32 flash0_fcon;           /*!< \brief registers of Flash Module */
  uint32 flash0_fsr;
  uint32 flash0_cbabcfg0;
  uint32 flash0_cbabstat0;
  uint32 flash0_cbabtop0;
  uint32 flash0_cbabcfg1;
  uint32 flash0_cbabstat1;
  uint32 flash0_cbabtop1;
  uint32 flash0_ubabcfg0;
  uint32 flash0_ubabstat0;
  uint32 flash0_ubabtop0;
  uint32 flash0_ubabcfg1;
  uint32 flash0_ubabstat1;
  uint32 flash0_ubabtop1;

  uint32 uniqueid0;             /*!< \brief Unique Chip Id */
  uint32 uniqueid1;
  uint32 uniqueid2;
  uint32 uniqueid3;
  uint32 mcds_fifonow;          /*!< \brief Fifo Now if traced was used */
  uint32 reserved[116];
  uint32 _version;              /*!< \brief Version of the Pattern */
  uint32 _crc;                  /*!< \brief Crc of the Failure Buffer */
} TFAIL_BUF;


/*! \brief structure to provide needed register values for a Port Pin */
typedef struct
{
  uint32 port;                  /*!< \brief the port number x=0...10 */
  uint32 bit;                   /*!< \brief the port bit y=0...15 */
  uint32 port_out;              /*!< \brief the Px_OUT address */
  uint32 port_in;               /*!< \brief the Px_IN address */
  uint32 port_omr;              /*!< \brief the Px_OMR address */
  uint32 set_high;              /*!< \brief the write mask Px_OMR to set bit y */
  uint32 set_low;               /*!< \brief the write mask Px_OMR to clear bit y */
  uint32 toggle;                /*!< \brief the write mask Px_OMR to toggle bit y */
  uint32 mask_or;               /*!< \brief the or mask */
  uint32 mask_and;              /*!< \brief the and mask */
} Tport_values;



/*! \brief structure for configuration misc. */
typedef struct
{
  sint32 (*_hook_init) (void);  /*!< \brief remote pointer to HW dependant initialization */
  sint32 (*_hook_fail) (void);  /*!< \brief remote pointer to HW dependant to fail identification */
  sint32 (*_hook_task1ms_init) (void);  /*!< \brief remote pointer to task 1ms initialization, exor */
  sint32 (*_hook_task1ms_main) (void);  /*!< \brief remote pointer to task 1ms main, exor */
  sint32 (*_hook_task5ms_init) (void);  /*!< \brief remote pointer to task 5ms initialization, exor */
  sint32 (*_hook_task5ms_main) (void);  /*!< \brief remote pointer to task 5ms main, exor */
  sint32 (*_hook_task10ms_init) (void); /*!< \brief remote pointer to task 10ms initialization, exor */
  sint32 (*_hook_task10ms_main) (void); /*!< \brief remote pointer to task 10ms main, exor */
  sint32 (*_hook_task20ms_init) (void); /*!< \brief remote pointer to task 20ms initialization, exor */
  sint32 (*_hook_task20ms_main) (void); /*!< \brief remote pointer to task 20ms main, exor */
  sint32 (*_hook_task50ms_init) (void); /*!< \brief remote pointer to task 50ms initialization, exor */
  sint32 (*_hook_task50ms_main) (void); /*!< \brief remote pointer to task 50ms main, exor */
  sint32 (*_hook_task100ms_init) (void);        /*!< \brief remote pointer to task 100ms initialization, exor */
  sint32 (*_hook_task100ms_main) (void);        /*!< \brief remote pointer to task 100ms main, exor */
  sint32 (*_hook_taskbenchmark_init) (void);    /*!< \brief remote pointer to task Benchmark initialization, exor */
  sint32 (*_hook_taskbenchmark_main) (void);    /*!< \brief remote pointer to task Benchmark main, exor */
  sint32 (*_hook_taskbackground_init) (void);   /*!< \brief remote pointer to task Background initialization, exor */
  sint32 (*_hook_taskbackground_main) (void);   /*!< \brief remote pointer to task Background main, exor */
  sint32 (*_hook_taskstart_init) (void);        /*!< \brief remote pointer to task start initialization, exor */
  sint32 (*_hook_taskstart_main) (void);        /*!< \brief remote pointer to task start main, exor */
  sint32 (*_hook_trapmmu) (void);       /*!< \brief remote pointer to trap mmu, exor */
  sint32 (*_hook_trapprotection) (void);        /*!< \brief remote pointer to trap protection, exor */
  sint32 (*_hook_trapinstruction) (void);       /*!< \brief remote pointer to trap instruction, exor */
  sint32 (*_hook_trapcontext) (void);   /*!< \brief remote pointer to trap context, exor */
  sint32 (*_hook_trapbus) (void);       /*!< \brief remote pointer to trap bus, exor */
  sint32 (*_hook_trapassertion) (void); /*!< \brief remote pointer to trap assertion, exor */
  sint32 (*_hook_trapnmi) (void);       /*!< \brief remote pointer to trap nmi, exor */
  sint32 (*_hook_sdmame0errint) (void); /*!< \brief remote pointer to interrupt dma error, exor */
  sint32 (*_hook_sdmame1errint) (void); /*!< \brief remote pointer to interrupt dma error, exor */
  sint32 (*_hook_dmame0errint) (void);  /*!< \brief remote pointer to interrupt dma error, exor */
  sint32 (*_hook_dmame1errint) (void);  /*!< \brief remote pointer to interrupt dma error, exor */
  sint32 (*_hook_sbcuerrint) (void);    /*!< \brief remote pointer to interrupt sbcu, exor */
  sint32 (*_hook_srierrint) (void);     /*!< \brief remote pointer to interrupt lbcu, exor */
  sint32 (*_hook_scuflasherrint) (void);        /*!< \brief remote pointer to interrupt scuflasherr , exor */
  float32 IPC_APPL;             /*!< \brief IPC of the Application Pattern based on fixed time / OS Timer ticks.    */
  float32 IPC_APPL_FIX;         /*!< \brief IPC of the Application Pattern based on clocks (performance counter). */
  uint32 _startup_id;           /*!< \brief ID for following startup procedure */
  uint32 _pattern_version;      /*!< \brief version of the pattern (8 bit version, 8 bit subversion, 16 bit PTE version) */
  uint16 _enabled_IDLE;         /*!< \brief if _enabled_IDLE==1 the CPU goes into IDLE mode inside the Background Task */
  uint16 _enabled_PORST_detection;      /*!< \brief if _enabled_PORST_detection==1 the pattern will be executed only after Power On Reset */
  uint32 _SRI_frequency_target; /*!< \brief _SRI_frequency target */
  uint32 _SRI_frequency_set;    /*!< \brief _SRI_frequency value determined */
  uint32 _SPB_frequency_set;    /*!< \brief _SPB_frequency value determined */
  uint32 _CRYSTAL_frequency_set;        /*!< \brief _CRYSTAL_frequency value determined */
  uint32 _FMPLL_PLLCON0;        /*!< \brief if _FMPLL 32bit value for register PLLCON0 if used only when not 0 */
  uint32 _FMPLL_PLLCON2;        /*!< \brief if _FMPLL 32bit value for register PLLCON2 */
  uint32 _EVR13CON;             /*!< \brief 32bit value for register EVR13CON */
  uint32 _EVR33CON;             /*!< \brief 32bit value for register EVR33CON */
  uint32 _EVRSDCTRL1;           /*!< \brief 32bit value for register EVRSDCTRL1 */
  uint32 _chipid;               /*!< \brief id of the used device, copy from SCU_CHIPID, could be overwritten */
  uint32 _FLASH0_FCON;          /*!< \brief 32bit value for register FLASH0_FCON register (waitstates for flash and soon) */
  uint16 _enabled_configstore;  /*!< \brief if 1 the pattern stops and executes the action according to _eraseonly_config (clear the sector for config and copy actual CONFIG values to sector) */
  uint16 _eraseonly_config;     /*!< \brief if 1 the pattern stops and erase only the sector with the config (actual CONFIG values are not written) */
  uint16 _enable_PLL_sequence;  /*!< \brief if _enable_PLL_sequence==1 then the PLL is written with Ramp-up sequence */
  uint16 _configfromflash;      /*!< \brief if 1 then the CONFIG was loaded from flash */
  uint32 _disable_failure_store;        /*!< \brief if 1 then any failure will not be store in the flash */
  TFAIL_STATUS _failid;         /*!< \brief failure id in case of faliure plausibility failure or trap */
  uint32 task_cnt_1ms;          /*!< \brief will be incremented for each task occurence */
  uint32 task_cnt_5ms;          /*!< \brief will be incremented for each task occurence */
  uint32 task_cnt_10ms;         /*!< \brief will be incremented for each task occurence */
  uint32 task_cnt_20ms;         /*!< \brief will be incremented for each task occurence */
  uint32 task_cnt_50ms;         /*!< \brief will be incremented for each task occurence */
  uint32 task_cnt_100ms;        /*!< \brief will be incremented for each task occurence */
  uint32 task_cnt_benchmark;    /*!< \brief will be incremented for each task occurence */
  uint32 _failbufaddr;          /*!< \brief addr of actual failure buffer address */
  float32 _tjuncC;              /*!< \brief Tjunction in C, updated every 100ms */
  TFAIL_BUF *_pfailbuf;         /*!< \brief pointer to FAIL_BUF, can be changed to check the status of already stored failures, e.g. 0xA001C0000 */
} TCONFIG_MISC;

/*! \brief structure for mcds */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint32 _fifonow;              /*!< \brief contains actual value of MCSD_FIFONOW register */
} TCONFIG_MCDS;

/*! \brief structure for configuration tom */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief ... */
} TCONFIG_TOM;


/*! \brief structure for configuration benchmark */
typedef struct
{
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief increment each time the benchmark was executed  */
  uint16 _delay_ms;             /*!< \brief sleep time of the benchmark after finalization, then the benchmark will be started again */
  uint32 _instrs;               /*!< \brief amount of instrs needed for one benchmark call */
  uint32 _clks;                 /*!< \brief amount of clocks needed for one benchmark call */
} TCONFIG_BENCHMARK;

/*! \brief structure for configuration watchdog */
typedef struct
{
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_setenable) (void);  /*!< \brief enable the watchdog function pointer */
  sint32 (*_setdisable) (void); /*!< \brief disable the watchdog function pointer */
  sint32 (*_trigger) (void);    /*!< \brief trigger the watchdog function pointer */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _password;             /*!< \brief password for watchdog */
  uint16 _reload;               /*!< \brief reload value for watchdog */
} TCONFIG_WDT;



/*! \brief structure for configuration Memchecker with DMA Background Transfer */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intdmaupdate) (void);       /*!< \brief dma interrupt update for memory checker */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief checksum error counter  */
  uint32 _area_start;           /*!< \brief start address granularity 2kByte */
  uint32 _area_len;             /*!< \brief len of area to be checked, granularity 1kbyte */
  uint32 _area_act;             /*!< \brief actual address of area to be checked, granularity 2kbyte */
  uint32 _checksum;             /*!< \brief checksum comparison */
  uint32 _checksum_valid;       /*!< \brief checksum_valid=1 if checksum was computed */
  uint16 _cnt;                  /*!< \brief amount of checks */
} TCONFIG_MEMCHK;

#define max_applcpu_buffer 0x10 /*!< \brief size of input/output paramete block */

/*! \brief structure for configuration application Processor */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intmsg) (void);     /*!< \brief message interrupt */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _cnt;                  /*!< \brief cnt amount of cpu activations */
  uint16 _cntwakesrc;           /*!< \brief cnt amount of cpu wakes */
  uint16 _cntwakedst;           /*!< \brief cnt amount of cpu wakes */
  uint16 _cntidlesrc;           /*!< \brief cnt amount of cpu idles */
  uint16 _cntidledst;           /*!< \brief cnt amount of cpu idles */
  float32 _ipc;                 /*!< \brief IPC rate */
  uint32 _clks;                 /*!< \brief clocks duration */
  uint32 _instrs;               /*!< \brief executed instructions */
  volatile uint32 _inparam[max_applcpu_buffer]; /*!< \brief the input parameter buffer */
  volatile uint32 _outparam[max_applcpu_buffer];        /*!< \brief the output parametet buffer */
} TCONFIG_APPLPROC;


#define max_spi_buffer 0x80     /*!< \brief maximum items for a spi block transfer */

/*! \brief structure for configuration SPI */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intrx) (void);      /*!< \brief receiver interrupt */
  sint32 (*_inttx) (void);      /*!< \brief transmitter interrupt */
  sint32 (*_interr) (void);     /*!< \brief error interrupt */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _loop;                 /*!< \brief if _loop==1 internal loop mode will be used, else an external connection is needed, link needs to be up, loop 1 to 4 possible (see phy) */
  uint16 _len;                  /*!< \brief the length of a block transfer, has to be less than max_spi_buffer/2 */
  uint32 _CLC;                  /*!< \brief the CLC value of the module */
  uint32 _GLOBALCON;            /*!< \brief the GLOBALCON Module register */
  uint32 _GLOBALCON1;           /*!< \brief the GLOBALCON1 Module register */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief cnt for transfer items */
  uint32 *pBuffertx;            /*!< \brief pointer to the transmit buffer */
  uint32 *pBufferrx;            /*!< \brief pointer to the receive buffer */
} TCONFIG_SPI;

#define max_eth_buffer 1600     /*!< \brief maximum bytes for a eth block transfer */

/*! \brief structure for configuration SPI */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_inteth) (void);     /*!< \brief interrupt of the ethernet */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _loop;                 /*!< \brief if _loop==1 internal loop mode will be used, else an external connection is needed */
  uint16 _len;                  /*!< \brief the length of a block transfer, has to be less than max_eth_buffer */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _msinterval;           /*!< \brief msec interval before transmit next paket */
  uint16 _MIICTRL;              /*!< \brief value for MIICTRL register */
  uint32 _PHYID;                /*!< \brief detected phyid (device number and device revision) */
  uint32 _txcnt;                /*!< \brief cnt for transmit items, need 32 bit for absdif */
  uint32 _rxcnt;                /*!< \brief cnt for receive items, need 32 bit for absdif */
  uint8 *pBuffertx;             /*!< \brief pointer to the transmit buffer */
  uint8 *pBufferrx;             /*!< \brief pointer to the receive buffer */
} TCONFIG_ETH;

#define max_hssl_buffer 8       /*!< \brief maximum items for a hssl block (8 words) transfer */

/*! \brief structure for configuration HSSL */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intrx) (void);      /*!< \brief receiver interrupt */
  sint32 (*_interr) (void);     /*!< \brief error interrupt */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _loop;                 /*!< \brief if _loop==1 internal loop mode will be used, else an external connection is needed, link needs to be up, loop 1 to 4 possible (see phy) */
  uint16 _len;                  /*!< \brief the length of a block transfer, has to be less than max_spi_buffer/2 */
  uint32 _HSCT_CONFIGPHY;       /*!< \brief the HSCT_CONFIGPHY Module register */
  uint32 _HSCT_INIT;            /*!< \brief the HSCT_INIT Module register */
  uint32 _HSCT_IFCTRL;          /*!< \brief the HSCT_IFCTRL Module register */
  uint32 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief cnt for transfer items */
  uint32 *pBuffertx;            /*!< \brief pointer to the transmit buffer */
  uint32 *pBufferrx;            /*!< \brief pointer to the receive buffer */
} TCONFIG_HSSL;

/*! \brief structure for smu */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intsmu0) (void);    /*!< \brief interrupt smu0 */
  sint32 (*_intsmu1) (void);    /*!< \brief interrupt smu1 */
  sint32 (*_intsmu2) (void);    /*!< \brief interrupt smu2 */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief number of activations */
} TCONFIG_SMU;

#define max_asc_buffer 0x80     /*!< \brief maximum items for a asc block transfer */
/*! \brief structure for configuration asynch. interface */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intrx) (void);      /*!< \brief interrupt receive */
  sint32 (*_inttx) (void);      /*!< \brief interrupt transmit */
  sint32 (*_interr) (void);     /*!< \brief interrupt error */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _loop;                 /*!< \brief if _loop==1 internal loop mode will be used, else an external connection is needed */
  uint16 _len;                  /*!< \brief length of transmit buffer */
  uint32 _CLC;                  /*!< \brief CLC register of module */
  uint32 _IOCR;                 /*!< \brief IOCR register of module */
  uint32 _BITCON;               /*!< \brief BITCON register of module */
  uint32 _BRG;                  /*!< \brief BRG register of module */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief number of transmitted blocks */
  uint8 *pBuffertx;             /*!< \brief pointer to the transmit buffer */
  uint8 *pBufferrx;             /*!< \brief pointer to the receive buffer */
} TCONFIG_ASC;

/*! \brief structure for configuration GTM Sequencer */
/* Instead of writing a Driver for each channel, a driver can be used for one MCS */
typedef struct
{
  sint32 (*_init) (sint32 ch);  /*!< \brief init function pointer */
  sint32 (*_clear_failure) (sint32 ch); /*!< \brief ... ch is sequencer channel */
  sint32 (*_start) (sint32 ch); /*!< \brief ... ch is sequencer channel */
  sint32 (*_status) (sint32 ch);        /*!< \brief ... ch is sequencer channel */
  sint32 (*_deinit) (sint32 ch);        /*!< \brief ... ch is sequencer channel */
  sint32 (*_reqstop) (sint32 ch);       /*!< \brief ... ch is sequencer channel */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intevt[8]) (void);  /*!< \brief interrupt receive ch is sequencer channel */
  sint32 (*_interr) (void);     /*!< \brief interrupt error */
  TDRV_STATUS _running[8];      /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled[8];           /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures[8];    /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data[8];     /*!< \brief data error counter  */
  uint16 _cnt[8];               /*!< \brief number of activiations for each channel */
} TCONFIG_GTMMCS;

/*! \brief structure for adc channel histogram */
typedef struct TADC_RESULT
{
  uint16 failure_min;           /*!< \brief failure counter adc(12bit) <0x7F0 */
  uint32 histo[0x20];           /*!< \brief histogram of adc 0x7F0<= && <0x810 */
  uint16 failure_max;           /*!< \brief failure counter adc(12bit >=0x810 */
} TADC_RESULT;

#define VADC_GROUPS 8           /*! \brief amount of VADC Groups */
#define VADC_CHANNELS_PER_GROUP 8       /*! \brief channels per group */

extern TADC_RESULT vadc_result[VADC_GROUPS][VADC_CHANNELS_PER_GROUP];

/*! \brief structure for configuration adc converter */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intscan) (void);    /*!< \brief interrupt autoscan */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _cnt;                  /*!< \brief count of Autoscans */
  uint8 _channels_ext_con[VADC_GROUPS]; /*!< \brief set bit then the channel is external connected */
  uint32 *pVadcresbuffer;       /*!< \brief pointer to resultbuffer for DMA */
  TADC_RESULT *pVadc_result;    /*!< \brief pointer to results for each group and each channel */
} TCONFIG_VADC;

/*! \brief structure for adc channel histogram */
typedef struct TDSADC_RESULT
{
  uint16 failure_min;           /*!< \brief failure counter adc(12bit) <0x7E0 */
  uint32 histo[0x40];           /*!< \brief histogram of adc 0x7E0<= && <0x820 */
  uint16 failure_max;           /*!< \brief failure counter adc(12bit >=0x820 */
} TDSADC_RESULT;

#define DSADC_CHANNELS 4        /*! \brief amount of DSADC modules */
#define DSADC_LEN_MAX 0x100     /*! \brief Length of the Result Buffer */

extern TDSADC_RESULT dsadc_result[DSADC_CHANNELS];      /*!< \brief results for each channel, histogram, min/max failures */

/*! \brief structure for configuration sadc converter */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intdmaupdate0) (void);      /*!< \brief interrupt dma update */
  sint32 (*_intdmaupdate1) (void);      /*!< \brief interrupt dma update */
  sint32 (*_intdmaupdate2) (void);      /*!< \brief interrupt dma update */
  sint32 (*_intdmaupdate3) (void);      /*!< \brief interrupt dma update */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _cnt[DSADC_CHANNELS];  /*!< \brief count of dsadc */
  sint32 _offset[DSADC_CHANNELS];       /*!< \brief offset values after calibration */
  uint16 _busy;                 /*!< \brief DSADCs are busy */
  uint32 _FCFGCx;               /*!< \brief Filterconfiguration Register */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  sint16 *pDsadcresbuffer;      /*!< \brief pointer to result buffer chx , used as destination of DMA... */
  TDSADC_RESULT *pDsadc_result; /*!< \brief pointer to results for each channel, histogram, min/max failures */
} TCONFIG_DSADC;

/*!< \brief enum for DFLASH Status during start */
typedef enum
{
  DFLASH_UNINIT,                /*!< \brief DFLASH no started */
  DFLASH_INIT_ERASE,            /*!< \brief DFLASH Erase All Sectors on Initialisation */
  DFLASH_READY                  /*!< \brief DFLASH is ready, Driver can be started */
} TDFLASH_STATUS;

/*! \brief structure for configuration dflash driver */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  TDFLASH_STATUS _dflashstate;  /*!< \brief will be set to two if initial erase is completed */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _suspend_enabled;      /*!< \brief if _suspend_enabled==1 the suspend/resume feature is activated */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _suspendreq;           /*!< \brief set when a suspend is requested */
  uint16 _erasereq;             /*!< \brief set when an erase is requested */
  uint16 _progreq;              /*!< \brief set when a program is requested */
  uint32 _cnt;                  /*!< \brief count of programed pages */
  uint32 _lastFSR;              /*!< \brief last content of FSR before CLEAR Status command */
  uint32 _actprogaddr;          /*!< \brief actual address for programming */
  uint32 _msinterval;           /*!< \brief msec interval before start of next possible program */
  uint32 _tmpmsinterval;        /*!< \brief msec since last program */
} TCONFIG_DFLASH;


#define max_can01_buffer 256    /*!< \brief maximum items for a can0 <-> can 1 block transfer */

/*! \brief structure for configuration can interface 0<->1 communication */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_int0) (void);       /*!< \brief interrupt error/warning can bus 0 */
  sint32 (*_int1) (void);       /*!< \brief interrupt error/warning can bus 1 */
  sint32 (*_int2) (void);       /*!< \brief not used */
  sint32 (*_int3) (void);       /*!< \brief not used */
  sint32 (*_int4) (void);       /*!< \brief interrupt tx/rx can bus 0 */
  sint32 (*_int5) (void);       /*!< \brief interrupt tx/rx can bus 1 */
  sint32 (*_int6) (void);       /*!< \brief not used */
  sint32 (*_int7) (void);       /*!< \brief not used */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _loop;                 /*!< \brief if _loop==1 internal loop mode will be used, else an external connection is needed */
  uint16 _len;                  /*!< \brief len of block transmit */
  uint32 _CLC;                  /*!< \brief CLC register */
  uint32 _FDR;                  /*!< \brief FDR register */
  uint32 _NBTR0;                /*!< \brief NBTR0 register */
  uint32 _NBTR1;                /*!< \brief NBTR1 register */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief count of block transfers */
  uint16 _buffer_act;           /*!< \brief actual index of transmit buffer */
  uint32 *pBuffer;              /*!< \brief pointer to transmit buffer */
} TCONFIG_CAN01;

/*! \brief structure for port toggling entry with DMA */
typedef struct
{
  uint32 _PORT_ADDR_OMR;        /*!< \brief Port address of the OMR */
  uint32 _PORT_OMR_VALUE;       /*!< \brief OMR value to write */
} TPORTTOGGLE_PORTLISTENTRY;

#define PORTTOGGLE_LIST_LEN 20  /*!< \brief maximum items for DMA port toggling, limited for save space in the config */

/*! \brief structure for configuration of Porttoggling via DMA */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_inttx0) (void);     /*!< \brief interrupt transmit */
  sint32 (*_inttx1) (void);     /*!< \brief interrupt transmit */
  uint16 _len;                  /*!< \brief len of block transmit */
  TDRV_STATUS _running;         /*!< \brief always one */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief counter for processed Lists */
  uint16 _caprelticks;          /*!< \brief reload value for timer tick used for DMA trigger */
  TPORTTOGGLE_PORTLISTENTRY _list[PORTTOGGLE_LIST_LEN]; /*!< \brief list to of toggle entries */
} TCONFIG_PORTTOGGLE;


/*! \brief structure for configuration of STM */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_int0) (void);       /*!< \brief interrupt to OS */
  TDRV_STATUS _running;         /*!< \brief always one */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint32 _stm0_offset;          /*!< \brief counter for offset stm0 sint32 */
  uint16 _cnt;                  /*!< \brief counter - not used */
} TCONFIG_STM;


/*! \brief structure for configuration GPIO, looped set and read of pins */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint32 _inport;               /*!< \brief the input Port */
  uint32 _inbit;                /*!< \brief the bit of the input Port */
  uint32 _iniocr;               /*!< \brief the bitfield for the input Control (0 and 3 for input only, 1 for pulldown, 2 for pullup) */
  uint32 _outport;              /*!< \brief the outport Port */
  uint32 _outbit;               /*!< \brief the bit of the output Port */
  uint32 _outiocr;              /*!< \brief the bitfield for the output Control (0x10 for push-pull, 0x18 for Open-drain) */
  uint16 _delay_us;             /*!< \brief the amount of time in us, where the input->output loop is applied, should be less than 1ms */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief count of loops  */
  Tport_values gpio_in;         /*!< \brief input structure of input pin, will be set by init  */
  Tport_values gpio_out;        /*!< \brief output structure of input pin, will be set by init  */
} TCONFIG_GPIO;


#define max_iflex_buffer 256    /*!< \brief maximum items for a flexray block transfer */
/*! \brief structure for configuration iflex */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_inttx) (void);      /*!< \brief interrupt transceive Flexray... */
  sint32 (*_interr) (void);     /*!< \brief interrupt error Flexray */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint16 _loop;                 /*!< \brief if _loop==1 internal loop mode will be used, else an external connection is needed */
  uint16 _len;                  /*!< \brief length of buffer */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief counter of transmited blocks */
  uint16 _buffer_act;           /*!< \brief actual index of transmit buffer */
  uint32 *pBuffer;              /*!< \brief pointer to transmit buffer */
} TCONFIG_IFLEX;


/*! \brief structure for configuration msc */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint32 _CLC;                  /*!< \brief CLC register of module */
  uint32 _FDR;                  /*!< \brief FDR register of module */
  uint32 _OCR;                  /*!< \brief OCR register of module */
  uint32 _DSS;                  /*!< \brief DSS register of module */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief counter */
} TCONFIG_MSC;


/*! \brief structure for configuration sysclock */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint32 _FDR;                  /*!< \brief FDR register of module */
  uint32 _EXTCON;               /*!< \brief EXTCON register of module */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief counter */
  uint16 _delay;                /*< \brief counter value for delayed EXTCLK0 start */
} TCONFIG_SYSCLK;

/*! \brief structure for configuration worst case pattern, high IPC rate */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _delay_us;             /*!< \brief execution time of worstcase pattern, should be less than <1ms */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief counter */
} TCONFIG_WORSTCASE;


/*! \brief structure for configuration of Px_IOCRy */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  uint32 _P00_IOCR0;            /*!< \brief List of value which will be copied in the corresponding Pxy_IOCRz Registers. */
  uint32 _P00_IOCR4;
  uint32 _P00_IOCR8;
  uint32 _P00_IOCR12;
  uint32 _P01_IOCR0;
  uint32 _P01_IOCR4;
  uint32 _P02_IOCR0;
  uint32 _P02_IOCR4;
  uint32 _P02_IOCR8;
  uint32 _P10_IOCR0;
  uint32 _P10_IOCR4;
  uint32 _P10_IOCR8;
  uint32 _P11_IOCR0;
  uint32 _P11_IOCR4;
  uint32 _P11_IOCR8;
  uint32 _P11_IOCR12;
  uint32 _P12_IOCR0;
  uint32 _P13_IOCR0;
  uint32 _P14_IOCR0;
  uint32 _P14_IOCR4;
  uint32 _P14_IOCR8;
  uint32 _P15_IOCR0;
  uint32 _P15_IOCR4;
  uint32 _P15_IOCR8;
  uint32 _P20_IOCR0;
  uint32 _P20_IOCR4;
  uint32 _P20_IOCR8;
  uint32 _P20_IOCR12;
  uint32 _P21_IOCR0;
  uint32 _P21_IOCR4;
  uint32 _P22_IOCR0;
  uint32 _P22_IOCR4;
  uint32 _P22_IOCR8;
  uint32 _P23_IOCR0;
  uint32 _P23_IOCR4;
  uint32 _P32_IOCR0;
  uint32 _P32_IOCR4;
  uint32 _P33_IOCR0;
  uint32 _P33_IOCR4;
  uint32 _P33_IOCR8;
  uint32 _P33_IOCR12;
  uint32 _P34_IOCR0;
  uint32 _P34_IOCR4;
  uint32 _P40_IOCR0;
  uint32 _P40_IOCR4;
  uint32 _P40_IOCR8;
}
TCONFIG_PORTIOCR;


/*! \brief structure for configuration Px_PDR */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  uint32 _P00_PDR0;             /*!< \brief List of value which will be copied in the corresponding Pxy_PDRz Registers. */
  uint32 _P00_PDR1;
  uint32 _P01_PDR0;
  uint32 _P02_PDR0;
  uint32 _P02_PDR1;
  uint32 _P10_PDR0;
  uint32 _P10_PDR1;
  uint32 _P11_PDR0;
  uint32 _P11_PDR1;
  uint32 _P12_PDR0;
  uint32 _P13_PDR0;
  uint32 _P14_PDR0;
  uint32 _P14_PDR1;
  uint32 _P15_PDR0;
  uint32 _P15_PDR1;
  uint32 _P20_PDR0;
  uint32 _P20_PDR1;
  uint32 _P21_PDR0;
  uint32 _P22_PDR0;
  uint32 _P22_PDR1;
  uint32 _P23_PDR0;
  uint32 _P32_PDR0;
  uint32 _P33_PDR0;
  uint32 _P33_PDR1;
  uint32 _P34_PDR0;
  uint32 _P40_PDR0;
  uint32 _P40_PDR1;
}
TCONFIG_PORTPDR;
/*! \brief structure for hystheresis measurement  */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
  uint16 _cnt;                  /*!< \brief counter */
} TCONFIG_STATUS;

/*! \brief structure for configuration SENT interface */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (sint32 ch); /*!< \brief ... */
  sint32 (*_start) (sint32 ch); /*!< \brief ... */
  sint32 (*_status) (sint32 ch);        /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intrx) (sint32 ch); /*!< \brief interrupt receive */
  sint32 (*_interr) (void);     /*!< \brief interrupt error */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  TDRV_STATUS _channel_state[8];        /*!< \brief status of channnel, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _channel_enabled[8];   /*!< \brief if _enabled==0 the channel is deactivated and will not start, can be changed on the fly by user */
  uint16 _ignorefailures[8];    /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint32 _CLC;                  /*!< \brief CLC register of module */
  uint32 _FDR;                  /*!< \brief FDR register of module */
  uint16 _DIV[8];               /*!< \brief DIV field of register CFDRx of module */
  uint16 _PDIV[8];              /*!< \brief PDIV field of register CPDRx of module */
  uint16 _failures_err[8];      /*!< \brief normal error counter  */
  uint16 _failures_data[8];     /*!< \brief data error counter  */
  uint16 _nibble_rx_act[8];     /*!< \brief actual index of received nibble */
  uint16 _nibble_cnt[8];        /*!< \brief number of nibble transmit/receive */
  uint16 _cnt[8];               /*!< \brief number of transmitted blocks */
} TCONFIG_SENT;


/*! \brief structure for configuration PSI5 interface */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (sint32 ch); /*!< \brief ... */
  sint32 (*_start) (sint32 ch); /*!< \brief ... */
  sint32 (*_status) (sint32 ch);        /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  sint32 (*_intrx) (sint32 ch); /*!< \brief interrupt receive */
  sint32 (*_interr) (void);     /*!< \brief interrupt error */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  TDRV_STATUS _channel_state[3];        /*!< \brief status of channnel, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _channel_enabled[3];   /*!< \brief if _enabled==0 the channel is deactivated and will not start, can be changed on the fly by user */
  uint16 _ignorefailures[3];    /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint32 _FDR;                  /*!< \brief FDR register of module */
  uint32 _FDRL;                 /*!< \brief FDRL register of module */
  uint32 _FDRH;                 /*!< \brief FDRH register of module */
  uint32 _RCRA[3];              /*!< \brief RCRAx register of module */
  uint32 _RCRB[3];              /*!< \brief RCRBx register of module */
  uint32 _RCRC[3];              /*!< \brief RCRCx register of module */
  uint32 _data2rec[3];          /*!< \brief data which must be received */
  uint16 _failures_err[3];      /*!< \brief normal error counter  */
  uint16 _failures_data[3];     /*!< \brief data error counter  */
  uint16 _cnt[3];               /*!< \brief counter */
} TCONFIG_PSI5;


/*! \brief structure for configuration external burst access */
/* not implemented for TC27x */
typedef struct
{
  sint32 (*_init) (void);       /*!< \brief init function pointer */
  sint32 (*_clear_failure) (void);      /*!< \brief ... */
  sint32 (*_start) (void);      /*!< \brief ... */
  sint32 (*_status) (void);     /*!< \brief ... */
  sint32 (*_deinit) (void);     /*!< \brief ... */
  sint32 (*_reqstop) (void);    /*!< \brief ... */
  sint32 (*_default) (void);    /*!< \brief ... */
  TDRV_STATUS _running;         /*!< \brief status of driver, do not change by Debugger */
  uint16 _enabled;              /*!< \brief if _enabled==0 the driver is deactivated, can be changed on the fly by user */
  uint16 _ignorefailures;       /*!< \brief if _ignorefailures==1 failures will be ignored and no fail entry will be created */
  uint32 _CLC;                  /*!< \brief CLC register of module EBU */
  uint32 _MODCON;               /*!< \brief MODCON register of module */
  uint32 _ADDRSEL0;             /*!< \brief ADDRSEL0 register of module EBU */
  uint32 _BUSRCON0;             /*!< \brief BUSRCON0 register of module EBU */
  uint32 _BUSWCON0;             /*!< \brief BUSWCON0 register of module EBU */
  uint32 _BUSRAP0;              /*!< \brief BUSRAP0 register of module EBU */
  uint32 _BUSWAP0;              /*!< \brief BUSWAP0 register of module EBU */
  uint32 _offset;               /*!< \brief offset for burst access  */
  uint32 _flash_manu_id;        /*!< \brief flash manufacturer ID  */
  uint32 _flash_device_id;      /*!< \brief flash device ID  */
  uint32 _flash_bcr;            /*!< \brief burst configuration register of flash */
  uint16 _failures_err;         /*!< \brief normal error counter  */
  uint16 _failures_data;        /*!< \brief data error counter  */
} TCONFIG_EXTBURST;


/*! \brief structure for all drivers */
typedef struct
{
  TCONFIG_PORTTOGGLE *pCONFIG_PORTTOGGLE;       /*!< \brief driver configuration pointer DMA Port Toggling */
  TCONFIG_STATUS *pCONFIG_STATUS;       /*!< \brief driver configuration pointer for Hystheresis and Status */
  TCONFIG_PORTIOCR *pCONFIG_PORTIOCR;   /*!< \brief driver configuration pointer for Port IOCR registers */
  TCONFIG_PORTPDR *pCONFIG_PORTPDR;     /*!< \brief driver configuration pointer for Port PDR  */
  TCONFIG_SYSCLK *pCONFIG_SYSCLK;       /*!< \brief driver configuration pointer for SYSCLK */
  TCONFIG_GPIO *pCONFIG_GPIO;   /*!< \brief driver configuration pointer for Looped GPIO */
  TCONFIG_MISC *pCONFIG_MISC;   /*!< \brief driver configuration pointer for misc. items */
  TCONFIG_BENCHMARK *pCONFIG_BENCHMARK; /*!< \brief driver configuration pointer for benchmark */
  TCONFIG_WDT *pCONFIG_WDT;     /*!< \brief driver configuration  pointer for watchdog */
  TCONFIG_SPI *pCONFIG_SPI0;    /*!< \brief driver configuration  pointer for SPI0 */
  TCONFIG_SPI *pCONFIG_SPI1;    /*!< \brief driver configuration  pointer for SPI1 */
  TCONFIG_SPI *pCONFIG_SPI2;    /*!< \brief driver configuration  pointer for SPI2 */
  TCONFIG_ASC *pCONFIG_ASC0;    /*!< \brief driver configuration  pointer for ASC0 */
  TCONFIG_ASC *pCONFIG_ASC1;    /*!< \brief driver configuration  pointer for ASC1 */
  TCONFIG_VADC *pCONFIG_VADC;   /*!< \brief driver configuration pointer for VADC */
  TCONFIG_DSADC *pCONFIG_DSADC; /*!< \brief driver configuration pointer for VADC */
  TCONFIG_CAN01 *pCONFIG_CAN01; /*!< \brief driver configuration  pointer for CAN0<->CAN1 communication */
  TCONFIG_WORSTCASE *pCONFIG_WORSTCASE; /*!< \brief driver configuration  pointer for Worst Case Pattern */
  TCONFIG_STM *pCONFIG_STM;     /*!< \brief driver configuration pointer for System Timer */
  TCONFIG_APPLPROC *pCONFIG_APPLPROC0;  /*!< \brief driver configuration pointer for Application CPU0 driver */
  TCONFIG_APPLPROC *pCONFIG_APPLPROC1;  /*!< \brief driver configuration pointer for Application CPU1 driver */
  TCONFIG_IFLEX *pCONFIG_IFLEX; /*!< \brief driver configuration  pointer for IFLEX */
  TCONFIG_MSC *pCONFIG_MSC0;    /*!< \brief driver configuration  pointer for MSC0 */
  TCONFIG_MSC *pCONFIG_MSC1;    /*!< \brief driver configuration  pointer for MSC1 */
  TCONFIG_GTMMCS *pCONFIG_GTMMCS0;      /*!< \brief driver configuration  pointer for GTMMCS0 */
  TCONFIG_GTMMCS *pCONFIG_GTMMCS1;      /*!< \brief driver configuration  pointer for GTMMCS1 */
  TCONFIG_GTMMCS *pCONFIG_GTMMCS2;      /*!< \brief driver configuration  pointer for GTMMCS2 */
  TCONFIG_SMU *pCONFIG_SMU;     /*!< \brief driver configuration  pointer for SMU */
  TCONFIG_TOM *pCONFIG_TOM;     /*!< \brief driver configuration  pointer for GTM TOMs */
  TCONFIG_DFLASH *pCONFIG_DFLASH;       /*!< \brief driver configuration  pointer for DFLASH */
  TCONFIG_MEMCHK *pCONFIG_MEMCHK;       /*!< \brief driver configuration  pointer for MEMCHK */
  TCONFIG_MCDS *pCONFIG_MCDS;   /*!< \brief driver configuration  pointer for MCDS */
  TCONFIG_SENT *pCONFIG_SENT;   /*!< \brief driver configuration pointer for SENT */
  TCONFIG_ETH *pCONFIG_ETH;     /*!< \brief driver configuration pointer for Ethernet */
  TCONFIG_PSI5 *pCONFIG_PSI5;   /*!< \brief driver configuration pointer for PSI5 */
  TCONFIG_HSSL *pCONFIG_HSSL;   /*!< \brief driver configuration  pointer for HSSL */
} TCONFIG_ALL;                  /*!< \brief type config collection */
#endif
