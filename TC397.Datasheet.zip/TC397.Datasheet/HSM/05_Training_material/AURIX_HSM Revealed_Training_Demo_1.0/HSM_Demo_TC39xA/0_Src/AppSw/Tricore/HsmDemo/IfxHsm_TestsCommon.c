#include <common.h>
#include "registers_hsm.h"
#include "HSM_Test_def.h"
#include "IfxScuCcu.h"
#include "MAIN_HSM.h"
#include "Test_Print.h"

volatile uint32 HOST2HSMbuf[0x100];
volatile uint32 HSM2HOSTbuf[0x100];
volatile uint32 buf_temp[0x100];

volatile uint32 hsmInitFlag = FALSE;
volatile uint32 hsmEncryptionEnd = FALSE;
volatile uint32 hsmHashEnd = FALSE;
volatile uint32 hsmReady = FALSE;

void hsm_TestInit(void);
void init_interrupts(void);
sint32 Bridge2Host_IRQHandler(void);

uint32 ChangeEndianness (uint32 i);


uint32 ChangeEndianness(uint32 value)
{
    uint32 result = 0;
    result |= (value & 0x000000FF) << 24;
    result |= (value & 0x0000FF00) << 8;
    result |= (value & 0x00FF0000) >> 8;
    result |= (value & 0xFF000000) >> 24;
    return result;
}

/**!
 *
 */
void hsm_TestInit(void)
{
	uint32 i;

	__enable(); //Enable the Interrupts

	init_interrupts();

	if (HSM_HT2HSMS.U != 0x50000011)
	{
		print_f("\nDEMO: HSM is not started correctly\n");
		__debug(); //HSM not ok
	}


	HSM_DBGBASE.U = 0xE0000000;		// Start after Halt after Reset
	MEM (0xF004002C) = 0xFFFFFFFF;	// HSM2HTIE, enable Interrupts from Bridge to Host
	HSM_DBGBASE.U = 0x20000000;		// I want to see SRAM

	while (!hsmInitFlag)
		;

	if (HSM_HSM2HTS.U != 0x1234567A)
	{
		print_f("\nDEMO: HSM is not started correctly\n");
		__debug(); // not the correct response
	}


	/****************************************************/
	/* Send address of HOST to HSM buffer in local Data Ram of Tricore to HSM
	 * Confirmation by 0xCCCC0000 or with mask and fill buffer with 0x0.... */
	hsmReady = FALSE;
	HOST2HSMbuf[0] = 0xEEEEEEEE;			// this has to be overwritten by HSM
	HOST2HSMbuf[0xFF] = 0xEEEEEEEE;			// this has to be overwritten by HSM
	HSM_HT2HSMS.U = (uint32) &HOST2HSMbuf[0];
	HSM_HT2HSMF.U = (1 << CMD_SETADDR_HOST2HSMBUF); //issue interrupt to HSM

	while (!hsmReady)
		;

	if (HSM_HSM2HTS.U != (0xCCCC0000 | CMD_SETADDR_HOST2HSMBUF))
	{
		print_f("\nDEMO: HSM is not started correctly\n");
		__debug(); // not the correct response or timeout
	}

	for (i = 0; i < 0x100; i += 1)
	{
		if (HOST2HSMbuf[i] != (0x00010000 | i))		// HSM has to clear the buffer
		{
			print_f("\nDEMO: HSM is not started correctly\n");
			__debug();
		}
	}

	/****************************************************/
	/* Send address of HSM to HOST buffer in local Data Ram of Tricore to HSM
	 * Confirmation by 0xCCCC0000 or with mask and fill buffer with 0x0.... */
	hsmReady = FALSE;
	HSM2HOSTbuf[0] = 0xEEEEEEEE;			// this has to be overwritten by HSM
	HSM2HOSTbuf[0xFF] = 0xEEEEEEEE;			// this has to be overwritten by HSM
	HSM_HT2HSMS.U = (uint32) &HSM2HOSTbuf[0];
	HSM_HT2HSMF.U = (1 << CMD_SETADDR_HSM2HOSTBUF); //issue interrupt to HSM

	while (!hsmReady)
		;

	if (HSM_HSM2HTS.U != (0xCCCC0000 | CMD_SETADDR_HSM2HOSTBUF))
	{
		print_f("\nDEMO: HSM is not started correctly\n");
		__debug(); // not the correct response or timeout
	}


	for (i = 0; i < 0x100; i += 1)
	{
		if (HSM2HOSTbuf[i] != (0x00020000 | i))		// HSM has to init the buffer
		{
			print_f("\nDEMO: HSM is not started correctly\n");
			__debug();
		}
	}

	print_f("\nDEMO: HSM and Tricore has setup HSM/HOST buffers!");

	//Clear buffers
	for (i = 0; i < 0x100; i += 1)
	{
		HSM2HOSTbuf[i] = 0x0;
		HOST2HSMbuf[i] = 0x0;
	}
}


/**********************************************************************************/
void init_interrupts(void)
{

	SRC_HSM0.U = (0 << 11) | (1 << 10) | 1;		/* 0<11 => ON CPU0, 1<<10 => Enable*/
	SRC_HSM1.U = (0 << 11) | (1 << 10) | 16;	/* 0<11 => ON CPU0, 1<<10 => Enable */

	interruptHandlerInstall(1, (uint32) &Bridge2Host_IRQHandler);
	interruptHandlerInstall(16, (uint32) &Bridge2Host_IRQHandler);
}

sint32 Bridge2Host_IRQHandler(void)
{
	if (HSM_HSM2HTF.U == 0x1)			//Initialization
	{
		print_f("\nDEMO: Bridge2Host Interrupt: HSM has initialized correctly!");
		hsmInitFlag = TRUE;
		HSM_HSM2HTF.U = 0x1;
		return (0);
	}
	if (HSM_HSM2HTF.U == 0x2)			//Encryption
	{
		//print_f("\nDEMO: Bridge2Host Interrupt: HSM_HSM2HTF == 0x2 ");
		hsmEncryptionEnd = TRUE;
		HSM_HSM2HTF.U = 0x2;
		return (0);
	}
	if (HSM_HSM2HTF.U == 0x4)			//Decryption
	{
		//print_f("\nDEMO: Bridge2Host Interrupt: HSM_HSM2HTF == 0x4 ");
		hsmEncryptionEnd = TRUE;
		HSM_HSM2HTF.U = 0x4;
		return (0);
	}
	if (HSM_HSM2HTF.U == 0x10)			//HASH - to be changed to 0x10
	{
		//print_f("\nDEMO: Bridge2Host Interrupt: HSM_HSM2HTF == 0x10 ");
		hsmHashEnd    = TRUE;
		HSM_HSM2HTF.U = 0x10;
		return (0);
	}
	if (HSM_HSM2HTF.U == 0x8)			//HSM Ready
	{
		if (hsmReady == FALSE)
			hsmReady = TRUE;
		HSM_HSM2HTF.U = 0x8;
	}
	return (0);
}

