/**
 * \file Std_Types.h
 * \copyright Copyright (c) 2012 Infineon Technologies AG. All rights reserved.
 *
 *
 * $Revision:  $
 * $Date:  $
 *
 *                                 IMPORTANT NOTICE
 *
 *
 * Infineon Technologies AG (Infineon) is supplying this file for use
 * exclusively with Infineon's microcontroller products. This file can be freely
 * distributed within development tools that are supporting such microcontroller
 * products.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 */
#ifndef STD_TYPES_H 
#define STD_TYPES_H 
/** This files contains definition compatible with AUTOSAR, do not modify except
 * for updating according to the latest AUTROSAR version
 */

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/

#include "Compilers.h"/* mapping compiler specific keywords */
#include "Platform_Types.h"             /* platform specific type definitions */


/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/

/* for OSEK compliance this typedef has been added */
#ifndef STATUSTYPEDEFINED 
  #define STATUSTYPEDEFINED 

  typedef unsigned char StatusType; 
  #define E_OK      0U

#endif

/*
  The Std_ReturnType (STD005) may be used with the following values (STD011):
  E_OK:     0
  E_NOT_OK: 1
*/
typedef uint8 Std_ReturnType;
#define E_NOT_OK    1U

typedef struct
{
   uint16 vendorID;
   uint16  moduleID;
   uint8  sw_major_version;
   uint8  sw_minor_version;
   uint8  sw_patch_version;
} Std_VersionInfoType; /* STD015                                */


#define STD_HIGH    1U  /* Physical state 5V or 3.3V             */
#define STD_LOW     0U  /* Physical state 0V                     */

#define STD_ACTIVE  1U  /* Logical state active                  */
#define STD_IDLE    0U  /* Logical state idle                    */

#ifndef ON             /* avoid clash with existing definitions */
   #define ON       1U
#endif

#ifndef OFF            /* avoid clash with existing definitions */
   #define OFF      0U
#endif

#ifndef STD_ON             /* avoid clash with existing definitions */
   #define STD_ON       1U
#endif

#ifndef STD_OFF            /* avoid clash with existing definitions */
   #define STD_OFF      0U
#endif



#endif  /* STD_TYPES_H */
