
#include "IFX_HSM.h"
#include "core_cmInstr.h"
#include "ports.h"

/*******************************************************************************************************/

const unsigned int internalKey1[4] __attribute__ ((section (".key"))) = {
		0x16157e2b,
		0xa6d2ae28,
		0x8815f7ab,
		0x3c4fcf09,
};


//helper macros for mem access
#ifndef MEM
# define MEM(register) (*((volatile unsigned int *)(register))) // makes live easier
#endif
#ifndef MEM16
# define MEM16(register) (*((volatile unsigned short *)(register)))
#endif
#ifndef MEM8
# define MEM8(register) (*((volatile unsigned char *)(register)))
#endif


extern void __init(void);
extern unsigned long _etext;
// start address for the initialization values of the .data section. defined in linker script
extern unsigned long _sidata;
// start address for the .data section. defined in linker script
extern unsigned long _sdata;
// end address for the .data section. defined in linker script
extern unsigned long _edata;
// start address for the .bss section. defined in linker script
extern unsigned long _sbss;
// end address for the .bss section. defined in linker script
extern unsigned long _ebss;
// init value for the stack pointer. defined in linker script
#if defined(__GNUC__)
extern void _estack;
#define IFX_HSM_INITIAL_STACK_POINTER &_estack
#define INTERRUPT_ATTRIBUTE __attribute__ ((__interrupt__))
#endif
#if defined(__TASKING__)
extern unsigned int _lc_ub_stack[];
#define IFX_HSM_INITIAL_STACK_POINTER _lc_ub_stack
#define INTERRUPT_ATTRIBUTE
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////
// Prototypes
////////////////////////////////////////////////////////////////////////////////////////////////////
// The emulated Reset entry
void Reset_Handler(void)
INTERRUPT_ATTRIBUTE;

int main(void);
void AES_ECB_Encrypt(short int keyNr,const unsigned int* keyword);
void AES_ECB_Decrypt(short int keyNr,const unsigned int* keyword);
void AES_CBC_Encrypt(void);
void AES_CBC_Decrypt(void);
void HASH_SHA_256(void);


/////////////////////////////////////////////////////////keyNr///////////////////////////////////////////
// Variable
////////////////////////////////////////////////////////////////////////////////////////////////////
volatile unsigned int * volatile pHOST2HSMbuf;	//pointer to buffer for Host to HSM parameter transfer
volatile unsigned int * volatile pHSM2HOSTbuf;	//pointer to buffer for HSM to Host parameter transfer

volatile int command;		//command which is executed
volatile int tick_cnt;		//counter for tick interrupt generation
volatile int trng_cnt;		//counter for trng interrupt generation
volatile int tick_cntstate;

#define CMD_WAIT					-2	//Negative commands are commands which are used for intermediate state
#define CMD_NOTHINGTODO				-1	//After receiving a command and correct execution this state should be reached
#define CMD_SETADDR_HOST2HSMBUF		0	//HSM supports commands 0-5
#define CMD_SETADDR_HSM2HOSTBUF		1
#define CMD_RUN_SYSTICK				2
#define CMD_RUN_TRNG				3
#define CMD_AES_ECB_ENCRYPT			4
#define CMD_AES_ECB_DECRYPT			5
#define CMD_AES_CBC_ENCRYPT			6
#define CMD_AES_CBC_DECRYPT			7
#define CMD_ENCRYPTK0				8
#define CMD_DECRYPTK0				9
#define CMD_SETSIZE_HOST2HSMBUF     10
#define CMD_HASH_SHA256             11

////////////////////////////////////////////////////////////////////////////////////////////////////
// Local AES Definition
////////////////////////////////////////////////////////////////////////////////////////////////////
#define BIT31   0x80000000
#define BIT30   0x40000000
#define BIT29   0x20000000
#define BIT28   0x10000000
#define BIT27   0x08000000
#define BIT26   0x04000000
#define BIT25   0x02000000
#define BIT24   0x01000000
#define BIT23   0x00800000
#define BIT22   0x00400000
#define BIT21   0x00200000
#define BIT20   0x00100000
#define BIT19   0x00080000
#define BIT18   0x00040000
#define BIT17   0x00020000
#define BIT16   0x00010000
#define BIT15   0x00008000
#define BIT14   0x00004000
#define BIT13   0x00002000
#define BIT12   0x00001000
#define BIT11   0x00000800
#define BIT10   0x00000400
#define BIT9    0x00000200
#define BIT8    0x00000100
#define BIT7    0x00000080
#define BIT6    0x00000040
#define BIT5    0x00000020
#define BIT4    0x00000010
#define BIT3    0x00000008
#define BIT2    0x00000004
#define BIT1    0x00000002
#define BIT0    0x00000001

//Defines for the AESCTRL register
#define AESCTRL_ECB_ENC             0x00000000
#define AESCTRL_ECB_DEC             0x00001000
#define AESCTRL_CBC_ENC             0x00002000
#define AESCTRL_CBC_DEC             0x00003000
#define AESCTRL_WK                  0x00010000
#define AESCTRL_LK                  0x00011000
#define AESCTRL_WCV                 0x00012000
#define AESCTRL_RCV                 0x00013000
#define AESCTRL_KEY0                0x00000000
#define AESCTRL_KEY1                0x00000010
#define AESCTRL_KEY2                0x00000020
#define AESCTRL_KEY3                0x00000030
#define AESCTRL_KEY4                0x00000040
#define AESCTRL_KEY5                0x00000050
#define AESCTRL_KEY6                0x00000060
#define AESCTRL_KEY7                0x00000070
#define AESCTRL_KEYOLD              0x000001F0
#define AESCTRL_CV0                 0x00000000
#define AESCTRL_CV1                 0x00000001
#define AESCTRL_CV2                 0x00000002
#define AESCTRL_CV3                 0x00000003
#define AESCTRL_CV4                 0x00000004

// Defines for the AESSTAT register
#define AESSTAT_LOCK1_MASK         (BIT2)
#define AESSTAT_LOCK1              (BIT2)
#define AESSTAT_LOCK0_MASK         (BIT1)
#define AESSTAT_LOCK0              (BIT1)
#define AESSTAT_LOCK_MASK          (BIT2|BIT1)
#define AESSTAT_LOCK               (BIT2|BIT1)
#define AESSTAT_BSY_MASK           (BIT0)
#define AESSTAT_BSY                (BIT0)

////////////////////////////////////////////////////////////////////////////////////////////////////
// Forward declaration of the default fault handlers.
////////////////////////////////////////////////////////////////////////////////////////////////////
void Default_Handler(void);
void Reset_Handler(void);
void NonMaskableInt_Handler(void);
void HardFault_Handler(void);
void BusFault_Handler(void);
void UsageFault_Handler(void);
void MemoryManagement_Handler(void);
void SVCall_Handler(void);
void DebugMonitor_Handler(void);
void PendSV_Handler(void);
void SysTick_Handler(void);

// External Interrupts
void TIM0_IRQHandler(void);
void TIM1_IRQHandler(void);
void TRNG_IRQHandler(void);
void Bridge_IRQHandler(void);
void BridgeErr_IRQHandler(void);
void SensInt_IRQHandler(void);
void ExtInt_IRQHandler(void);
void PKCReady_IRQHandler(void);
void PKCError_IRQHandler(void);

////////////////////////////////////////////////////////////////////////////////////////////////////
// interrupt vector table
////////////////////////////////////////////////////////////////////////////////////////////////////

__attribute__ ((section (".isr_vector")))
void (* const g_pfnVectors[])(void) =
{
	IFX_HSM_INITIAL_STACK_POINTER, /* The initial stack pointer */
	Reset_Handler, /* Reset Handler */
	NonMaskableInt_Handler, /* NMI Handler */
	HardFault_Handler, /* Hard Fault Handler */
	MemoryManagement_Handler, /* MPU Fault Handler */
	BusFault_Handler, /* Bus Fault Handler */
	UsageFault_Handler, /* Usage Fault Handler */
	Default_Handler, /* Reserved */
	Default_Handler, /* Reserved */
	Default_Handler, /* Reserved */
	Default_Handler, /* Reserved */
	SVCall_Handler, /* SVCall Handler */
	DebugMonitor_Handler, /* Debug Monitor Handler */
	Default_Handler, /* Reserved */
	PendSV_Handler, /* PendSV Handler */
	SysTick_Handler, /* SysTick Handler */
	/* External Interrupts*/
	TIM0_IRQHandler, /* 0:  Timer 0 Interrupt        */
	TIM1_IRQHandler, /* 1:  Timer 1 Interrupt        */
	TRNG_IRQHandler, /* 2:  TRNG Interrupt           */
	Bridge_IRQHandler, /* 3:  Bridge Service Interrupt */
	BridgeErr_IRQHandler, /* 4:  Bridge Error Interrupt   */
	SensInt_IRQHandler, /* 5:  Volt. Sensor Interrupt   */
	ExtInt_IRQHandler, /* 6:  External Application Interrupt  */
	Default_Handler, /* Reserved */
	PKCReady_IRQHandler, /* 7: PKC Ready Interrupt */
	PKCError_IRQHandler, /* 8: PKC Error Interrupt */
};

////////////////////////////////////////////////////////////////////////////////////////////////////
// This code is called after each reset
////////////////////////////////////////////////////////////////////////////////////////////////////
void Reset_Handler(void)
{
	__asm volatile ("MSR msp, %0\n\t"::"r" (IFX_HSM_INITIAL_STACK_POINTER));

#if defined(__GNUC__)
	/* Initialize data and bss */
	unsigned long *pulSrc, *pulDest;
	//replacement of the c initialization
	/* Copy the data segment initializers from flash to SRAM */

	pulSrc = &_sidata;

	for (pulDest = &_sdata; pulDest < &_edata;)
	{
		*(pulDest++) = *(pulSrc++);
	}
	/* Zero fill the bss segment. */
	for (pulDest = &_sbss; pulDest < &_ebss;)
	{
		*(pulDest++) = 0;
	}
#endif

#if defined(__TASKING__)
	__init();
#endif

	// Set marker - First value after successful boot
	HSM_BRIDGE->HSM2HTS = 0x1234567A;

	/* Enable output pin connected to LED on P20.14 */
	P20_IOCR12.B.PC14 = IfxPort_PCx_Output_PushPull_gpio;

	/* Call the application's entry point. */
	main();
	// we should never reach this point
	while (1)
		;
}

void Default_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff00FF;
	while (1)
		;
}

void NonMaskableInt_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff0001;
	while (1)
		;
}

void HardFault_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff0002;
	while (1)
		;
}

void MemoryManagement_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff0003;
	while (1)
		;
}

void BusFault_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff0004;
	while (1)
		;
}

void UsageFault_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff0005;
	while (1)
		;
}

void SVCall_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff0006;
	while (1)
		;
}

void DebugMonitor_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff0007;
	while (1)
		;
}

void PendSV_Handler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefff0008;
	while (1)
		;
}

void SysTick_Handler(void)
{
	if (tick_cntstate == 1) /* SysTick demo case active*/
	{
		pHSM2HOSTbuf[tick_cnt++] = SysTick->LOAD - SysTick->VAL;	/* Store response time */

		P20_OMR.U = IfxPort_State_toggled << 14; /* toggle LED */

		if (tick_cnt == 0x100)
		{
			command = CMD_NOTHINGTODO;
			//SysTick->CTRL = 0x0;			/* turn SYS Tick off or keep it on for the LED toggle */
			tick_cntstate = 0;
			tick_cnt = 0;
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | CMD_RUN_SYSTICK;
			HSM_BRIDGE->HSM2HTF = 0x8;		/*Raise an Interrupt to the Host (Tricore) */
		}
	}
	else
	{
		tick_cnt++;
		if (tick_cnt == 200)
		{
			P20_OMR.U = IfxPort_State_toggled << 14;
			tick_cnt = 0;
		}
	}
}

void TIM0_IRQHandler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefef0010;
	while (1)
		;
}

void TIM1_IRQHandler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefef0011;
	while (1)
		;
}

void TRNG_IRQHandler(void)
{
#ifndef TOMG_NO_CACHE
	int i;
#endif

	if (HSM_TRNG->TRNG_STAT == 0x0001)				//Random data ready
	{
		/* Read random value */
		pHSM2HOSTbuf[trng_cnt] = HSM_TRNG->TRNG_DATA32;
		trng_cnt += 1;
	}
	else if (HSM_TRNG->TRNG_STAT == 0x0200)			//Only Quality Warning set - Low entropy
	{
		HSM_TRNG->TRNG_STAT = 0x0400;		//Discard data and clear Warning flag
	}
	else if ((HSM_TRNG->TRNG_STAT & 0x0004) != 0)	//Error
	{
		HSM_TRNG->TRNG_CTRL = 0x6;			//Turn TRNG off
		HSM_TRNG->TRNG_STAT = 0x0408;		//Discard data and clear Warning and Error flags

		HSM_BRIDGE->HSM2HTS = 0xefef0012;	//Signal error to the Host
		HSM_BRIDGE->HSM2HTF = 0x8;			//Raise an Interrupt to the Host (Tricore)
	}

	if (trng_cnt == 1)
	{
	}
	else if (trng_cnt == 0x100)
	{
#ifndef TOMG_NO_CACHE
		for (i = 0; i < 0x100; i++)
			HSM_CACHE->CACHE_BC = (unsigned int) &pHSM2HOSTbuf[i];
#endif

		command = CMD_NOTHINGTODO;
		HSM_TRNG->TRNG_CTRL = 0x6;		//turn TRNG off

		HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | CMD_RUN_TRNG;
		HSM_BRIDGE->HSM2HTF = 0x8;		//Raise an Interrupt to the Host (Tricore)
	}
}

// The Bridge Handler receives the interrupt triggered by Host, see Aurix access to HT2HSMF
// Depending on the bit, a command is executed
void Bridge_IRQHandler(void)
{
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_SETADDR_HOST2HSMBUF)) {
		command = CMD_SETADDR_HOST2HSMBUF; // show command to while loop in main
		//clear flags, should not be removed by potential compiler optimizations,
		//volatile definition required, which is for us the case
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF;
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_SETADDR_HSM2HOSTBUF)) {
		command = CMD_SETADDR_HSM2HOSTBUF;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_RUN_SYSTICK)) {
		command = CMD_RUN_SYSTICK;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_RUN_TRNG)) {
		command = CMD_RUN_TRNG;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_AES_ECB_ENCRYPT)) {
		command = CMD_AES_ECB_ENCRYPT;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_AES_ECB_DECRYPT)) {
		command = CMD_AES_ECB_DECRYPT;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_AES_CBC_ENCRYPT)) {
		command = CMD_AES_CBC_ENCRYPT;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_AES_CBC_DECRYPT)) {
		command = CMD_AES_CBC_DECRYPT;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_ENCRYPTK0)) {
		command = CMD_ENCRYPTK0;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}
	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_DECRYPTK0)) {
		command = CMD_DECRYPTK0;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}

	if (HSM_BRIDGE->HT2HSMF == (1 << CMD_HASH_SHA256)) {
		command = CMD_HASH_SHA256;
		HSM_BRIDGE->HT2HSMF = HSM_BRIDGE->HT2HSMF; //clear flags
		return;
	}

	HSM_BRIDGE->HSM2HTS = 0xefef0013;
	while (1)
		;
}

void BridgeErr_IRQHandler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefef0014;
	while (1)
		;
}

void SensInt_IRQHandler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefef0015;
	while (1)
		;
}

void ExtInt_IRQHandler(void) {
	HSM_BRIDGE->HSM2HTS = 0xefef0016;
	while (1)
		;
}

void PKCReady_IRQHandler(void){
	HSM_BRIDGE->HSM2HTS = 0xefef0017;
	while (1)
		;
}
void PKCError_IRQHandler(void){
	HSM_BRIDGE->HSM2HTS = 0xefef0018;
	while (1)
		;
}

unsigned uiNoCommandCnt = 0;

int main(void)
{
	int i;
	int result = 0;

	command = CMD_NOTHINGTODO;

	//The TRNG is enabled after Boot
	//The corresponding spec. shows turned off, additional information will be handed over which registers are touched during boot
	HSM_TRNG->TRNG_CTRL = 0x6;
	NVIC_ClearPendingIRQ(TRNG_IRQn);

	NVIC_EnableIRQ(TIM0_IRQn);
	NVIC_EnableIRQ(TIM1_IRQn);
	NVIC_EnableIRQ(TRNG_IRQn);
	NVIC_EnableIRQ(Bridge_IRQn);
	NVIC_EnableIRQ(BridgeErr_IRQn);
	NVIC_EnableIRQ(SensInt_IRQn);
	NVIC_EnableIRQ(ExtInt_IRQn);

	HSM_BRIDGE->HT2HSMIE = 0xFFFFFFFF; //enable Interrupts from Host to Bridge
	HSM_BRIDGE->HSM2HTF = 1; //Raise an Interrupt to the Host (Tricore)

	while (1 == 1)
	{
		switch (command)
		{
		case CMD_WAIT:
		{
			uiNoCommandCnt++; //Important!!! Tasking Compiler does not work if the case if empty (only break)
			break;
		}
		/****************************************************/
		case CMD_NOTHINGTODO:
		{
			uiNoCommandCnt++; //Important!!! Tasking Compiler does not work if the case if empty (only break)
			break;
		}
		/****************************************************/
		case CMD_SETADDR_HOST2HSMBUF:
		{
			HSM_BRIDGE->SAHBASE = (HSM_BRIDGE->HT2HSMS & 0xFFFF0000);
			pHOST2HSMbuf = (unsigned int *)(0xF0050000 | (HSM_BRIDGE->HT2HSMS & 0x0000FFFF));

			for (i = 0; i < 0x100; i++)
				pHOST2HSMbuf[i] = 0x00010000 | i; //fill with a pattern

			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command; //confirm that the command was executed
			command = CMD_NOTHINGTODO;
			HSM_BRIDGE->HSM2HTF = 0x8; //Raise an Interrupt to the Host (Tricore)
			break;
		}
		/****************************************************/
		case CMD_SETADDR_HSM2HOSTBUF:
		{
			pHSM2HOSTbuf = (unsigned int *)(0xF0050000 | (HSM_BRIDGE->HT2HSMS & 0x0000FFFF));

			for (i = 0; i < 0x100; i++)
				pHSM2HOSTbuf[i] = 0x00020000 | i; //fill with a pattern
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command;
			command = CMD_NOTHINGTODO;
			HSM_BRIDGE->HSM2HTF = 0x8; //Raise an Interrupt to the Host (Tricore)
			break;
		}
		/****************************************************/
		case CMD_RUN_SYSTICK:
		{
			SysTick->CTRL = 0x0;			//Disable Systick
			SysTick->LOAD = 62500 - 1;		//Reload Value (10ms)
			SysTick->CTRL = 0x7;			//SYSTICK Enable, generate Interrupt, Use Core clock
			tick_cnt = 0;					//counter incremented inside the interrupt
			tick_cntstate = 1;              //state used to toggle LED
			command = CMD_WAIT;				//command confirmation and parameter passing is done inside interrupt
			break;
		}
		/****************************************************/
		case CMD_RUN_TRNG:
		{
			HSM_TRNG->TRNG_CTRL = 0x2;			//turn trng 32bit on
			result = HSM_TRNG->TRNG_DATA32;		//Dummy Read to unlock the TRGN

			trng_cnt = 0;					//counter incremented inside the interrupt
			command = CMD_WAIT; 			//command confirmation and parameter passing is done inside interrupt
			break;
		}
		/****************************************************/
		case CMD_AES_ECB_ENCRYPT:
		{
			AES_ECB_Encrypt(AESCTRL_KEY5, &internalKey1);	//execute encryption
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command;		//confirm to Host
			HSM_BRIDGE->HSM2HTF = 0x2;						//Raise an Interrupt to the Host (Tricore)
			command = CMD_NOTHINGTODO;
			break;
		}
		/****************************************************/
		case CMD_AES_ECB_DECRYPT:
		{
			AES_ECB_Decrypt(AESCTRL_KEY5, &internalKey1);
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command;
			HSM_BRIDGE->HSM2HTF = 0x4;					//Raise an Interrupt to the Host (Tricore)
			command = CMD_NOTHINGTODO;
			break;
		}
		/****************************************************/
		case CMD_AES_CBC_ENCRYPT:
		{
			AES_CBC_Encrypt();								//execute encryption
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command;	//confirm to Host
			command = CMD_NOTHINGTODO;
			HSM_BRIDGE->HSM2HTF = 0x2;					//Raise an Interrupt to the Host (Tricore)
			break;
		}
		/****************************************************/
		case CMD_AES_CBC_DECRYPT:
		{
			AES_CBC_Decrypt();
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command;
			command = CMD_NOTHINGTODO;
			HSM_BRIDGE->HSM2HTF = 0x4;					//Raise an Interrupt to the Host (Tricore)
			break;
		}
		/****************************************************/
		case CMD_ENCRYPTK0:
		{
			AES_ECB_Encrypt(AESCTRL_KEY0, &internalKey1);	//execute encryption
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command;		//confirm to Host
			HSM_BRIDGE->HSM2HTF = 0x8;						//Raise an Interrupt to the Host (Tricore)
			command = CMD_NOTHINGTODO;
			break;
		}
		/****************************************************/
		case CMD_DECRYPTK0:
		{
			AES_ECB_Decrypt(AESCTRL_KEY0, &internalKey1);
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command;
			HSM_BRIDGE->HSM2HTF = 0x8; //Raise an Interrupt to the Host (Tricore)
			command = CMD_NOTHINGTODO;
			break;
		}
		/****************************************************/
		case CMD_HASH_SHA256:
		{
			HASH_SHA_256();
			HSM_BRIDGE->HSM2HTS = 0xCCCC0000 | command;
			HSM_BRIDGE->HSM2HTF = 0x10; //Raise an Interrupt to the Host (Tricore)
			command = CMD_NOTHINGTODO;
			break;
		}
		/****************************************************/
		default:
		{
			HSM_BRIDGE->HSM2HTS = 0xefef00FF; //only valid commands from host are accepted
			while (1)
				;
		}
	}
}
	// This point will never be reached.
	return result;
}

//Example taken over from Target Spec for ECB encryption
void AES_ECB_Encrypt(short int keyNr, const unsigned int* keyword)
{
	int i;

	if (keyNr > 1)
	{
		HSM_AES->AESIN0 = keyword[0];
		HSM_AES->AESIN1 = keyword[1];
		HSM_AES->AESIN2 = keyword[2];
		HSM_AES->AESIN3 = keyword[3];

		// Load the key in K5
		HSM_AES->AESCTRL = AESCTRL_WK | (keyNr);
	}

	i = 0;
	while (i < 0x100)
	{
		HSM_AES->AESIN0 = pHOST2HSMbuf[i];
		HSM_AES->AESIN1 = pHOST2HSMbuf[i + 1];
		HSM_AES->AESIN2 = pHOST2HSMbuf[i + 2];
		HSM_AES->AESIN3 = pHOST2HSMbuf[i + 3];

		// Encrypt using ECB with K5
		HSM_AES->AESCTRL = AESCTRL_ECB_ENC | (keyNr);
		// Do nothing loop while the AES is busy
		while ((HSM_AES->AESSTAT & AESSTAT_BSY_MASK) == AESSTAT_BSY);

		pHSM2HOSTbuf[i] = HSM_AES->AESOUT0;
		pHSM2HOSTbuf[i + 1] = HSM_AES->AESOUT1;
		pHSM2HOSTbuf[i + 2] = HSM_AES->AESOUT2;
		pHSM2HOSTbuf[i + 3] = HSM_AES->AESOUT3;
		i += 4;
	}
}

void AES_ECB_Decrypt(short int keyNr, const unsigned int* keyword)
{
	int i;

	if (keyNr > 1)
	{
		HSM_AES->AESIN0 = keyword[0];
		HSM_AES->AESIN1 = keyword[1];
		HSM_AES->AESIN2 = keyword[2];
		HSM_AES->AESIN3 = keyword[3];
		// Load the key in K5
		HSM_AES->AESCTRL = AESCTRL_WK | (keyNr);
	}

	i = 0;
	while (i < 0x100)
	{
		HSM_AES->AESIN0 = pHOST2HSMbuf[i];
		HSM_AES->AESIN1 = pHOST2HSMbuf[i + 1];
		HSM_AES->AESIN2 = pHOST2HSMbuf[i + 2];
		HSM_AES->AESIN3 = pHOST2HSMbuf[i + 3];

		// Decrypt using ECB with K5
		HSM_AES->AESCTRL = AESCTRL_ECB_DEC | (keyNr);
		// Do nothing loop while the AES is busy
		while ((HSM_AES->AESSTAT & AESSTAT_BSY_MASK) == AESSTAT_BSY);

		pHSM2HOSTbuf[i] = HSM_AES->AESOUT0;
		pHSM2HOSTbuf[i + 1] = HSM_AES->AESOUT1;
		pHSM2HOSTbuf[i + 2] = HSM_AES->AESOUT2;
		pHSM2HOSTbuf[i + 3] = HSM_AES->AESOUT3;
		i += 4;
	}
}

//Example taken over from Target Spec for CBC encryption
void AES_CBC_Encrypt(void)
{
	int i;

	HSM_AES->AESIN0 = 0x16157e2b;
	HSM_AES->AESIN1 = 0xa6d2ae28;
	HSM_AES->AESIN2 = 0x8815f7ab;
	HSM_AES->AESIN3 = 0x3c4fcf09;
	// Load the key to K5 register
	HSM_AES->AESCTRL = AESCTRL_WK | AESCTRL_KEY5;

	HSM_AES->AESIN0 = 0x03020100; //Initial Value (IV)
	HSM_AES->AESIN1 = 0x07060504;
	HSM_AES->AESIN2 = 0x0B0A0908;
	HSM_AES->AESIN3 = 0x0F0E0D0C;
	// Load Initial Value (IV) to CV0 register
	HSM_AES->AESCTRL = AESCTRL_WCV | AESCTRL_CV0; // IV--->CV0

	i = 0;
	while (i < 16)
	{
		HSM_AES->AESIN0 = pHOST2HSMbuf[i];
		HSM_AES->AESIN1 = pHOST2HSMbuf[i + 1];
		HSM_AES->AESIN2 = pHOST2HSMbuf[i + 2];
		HSM_AES->AESIN3 = pHOST2HSMbuf[i + 3];
		// Encrypt using CBC with K5 and CV0
		HSM_AES->AESCTRL = AESCTRL_CBC_ENC | AESCTRL_KEY5 | AESCTRL_CV0;
		// Do nothing loop while the AES is busy
		while ((HSM_AES->AESSTAT & AESSTAT_BSY_MASK) == AESSTAT_BSY);

		pHSM2HOSTbuf[i] = HSM_AES->AESOUT0;
		pHSM2HOSTbuf[i + 1] = HSM_AES->AESOUT1;
		pHSM2HOSTbuf[i + 2] = HSM_AES->AESOUT2;
		pHSM2HOSTbuf[i + 3] = HSM_AES->AESOUT3;
		i += 4;
	}
}

void AES_CBC_Decrypt(void)
{
	int i;

	HSM_AES->AESIN0 = 0x16157e2b;
	HSM_AES->AESIN1 = 0xa6d2ae28;
	HSM_AES->AESIN2 = 0x8815f7ab;
	HSM_AES->AESIN3 = 0x3c4fcf09;
	// Load the key in K5 register
	HSM_AES->AESCTRL = AESCTRL_WK | AESCTRL_KEY5;

	HSM_AES->AESIN0 = 0x03020100;
	HSM_AES->AESIN1 = 0x07060504;
	HSM_AES->AESIN2 = 0x0B0A0908;
	HSM_AES->AESIN3 = 0x0F0E0D0C;
	// Load Initial Value (IV) to CV0 register
	HSM_AES->AESCTRL = AESCTRL_WCV | AESCTRL_CV0;

	i = 0;
	while (i < 16)
	{
		HSM_AES->AESIN0 = pHOST2HSMbuf[i];
		HSM_AES->AESIN1 = pHOST2HSMbuf[i + 1];
		HSM_AES->AESIN2 = pHOST2HSMbuf[i + 2];
		HSM_AES->AESIN3 = pHOST2HSMbuf[i + 3];

		// Decrypt using CBC with K5 and CV0
		HSM_AES->AESCTRL = AESCTRL_CBC_DEC | AESCTRL_KEY5 | AESCTRL_CV0;
		// Do nothing loop while the AES is busy
		while ((HSM_AES->AESSTAT & AESSTAT_BSY_MASK) == AESSTAT_BSY);

		pHSM2HOSTbuf[i] = HSM_AES->AESOUT0;
		pHSM2HOSTbuf[i + 1] = HSM_AES->AESOUT1;
		pHSM2HOSTbuf[i + 2] = HSM_AES->AESOUT2;
		pHSM2HOSTbuf[i + 3] = HSM_AES->AESOUT3;
		i += 4;
	}
}
void HASH_SHA_256(void)
{
	uint32_t i;

	HSM_HASH->CFG.U = HASH_CFG_ALGO_SHA256 |
				HASH_CFG_IV_MODE_NO_IV |
				HASH_CFG_ORDER_OUT_MSW_FIRST |
				HASH_CFG_BEND_OUT_LIT |
				HASH_CFG_BEND_IN_LIT;

	/* data is 512 bits - load it for Hashing*/
	for (i = 0; i < 16; i += 1)
	{
		HSM_HASH->DATA.U = pHOST2HSMbuf[i];
	}
	/* Poll until HASH_STAT.DF_NF is 1, then goto step 2. */
	while (HSM_HASH->STAT.B.DF_NF == false);

	/* Perform the last block - padding and data length */
	HSM_HASH->DATA.U = 	0x00000080;
	for (i = 1; i < 14; i++)
	{
		HSM_HASH->DATA.U = 0x00000000;
	}
	HSM_HASH->DATA.U = 0x00000000;
	HSM_HASH->DATA.U = 0x00020000;  // 512 bits = 0x200
	//Wait as HASH is still busy
	while (HSM_HASH->STAT.B.BSY == true) ;
	/* write back hash to host memory */
	for ( i = 0; i < 8; i++)
	{
		pHSM2HOSTbuf[i] = HSM_HASH->VAL.U;
	}
	/* Each read decrements the HASH_STAT.CNT bit field. this bit field counts the number
	 * of 32-bit words available as result until that field is 0.
	 */
	if (HSM_HASH->STAT.B.CNT == 0)
	{
		/* all result registers are ready */
		pHSM2HOSTbuf[8] = 0xAA; //just for confirmation
	}
}
