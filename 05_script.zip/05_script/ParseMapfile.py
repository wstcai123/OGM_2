import sys

dict = {
	"CORE0_NONQM_CORE0MPU   " : ["_lc_gb_RAM_PARTITION_CORE0_NONQM", "_lc_gb_RAM_PARTITION_CORE0_NONQM_MPU_RESERVED"],
	"CORE0_QM_CORE0MPU      " : ["_lc_gb_RAM_PARTITION_CORE0_QM",    "_lc_gb_RAM_PARTITION_CORE0_QM_MPU_RESERVED"   ],
	"CORE1_NONQM_CORE0MPU   " : ["_lc_gb_RAM_PARTITION_CORE1_NONQM", "_lc_gb_RAM_PARTITION_CORE1_NONQM_MPU_RESERVED"],
	"CORE1_QM_CORE0MPU      " : ["_lc_gb_RAM_PARTITION_CORE1_QM",    "_lc_gb_RAM_PARTITION_CORE1_QM_MPU_RESERVED"   ],
	"CORE2_NONQM_CORE0MPU   " : ["_lc_gb_RAM_PARTITION_CORE2_NONQM", "_lc_gb_RAM_PARTITION_CORE2_NONQM_MPU_RESERVED"],
	"CORE2_QM_CORE0MPU      " : ["_lc_gb_RAM_PARTITION_CORE2_QM",    "_lc_gb_RAM_PARTITION_CORE2_QM_MPU_RESERVED"   ],
	"CORE2_ASILA_CORE0MPU   " : ["_lc_gb_RAM_PARTITION_CORE2_ASILA", "_lc_gb_RAM_PARTITION_CORE2_ASILA_RES_GROUP"   ],
	"DLMU0_DLMU3_LMU0_ASILB " : ["_lc_gb_RAM_DLMU0_VHSM_IPC",        "_lc_gb_RAM_LMU0_ASILB_MPU_RESERVED"           ],
	"TRUSTED_WRITE_LMU1_To_F" : ["_lc_ge_RAM_LMU0_MISC",             "0xFFFFFFF8"                                   ],
	"RAM_PSPR0_RESERVED     " : ["_lc_gb_RAM_PSPR0_RESERVED",        "_lc_ge_RAM_PSPR0_RESERVED"                    ],
	"RAM_PSPR1_RESERVED     " : ["_lc_gb_RAM_PSPR1_RESERVED",        "_lc_ge_RAM_PSPR1_RESERVED"                    ],
	"RAM_LMU0_MISC          " : ["_lc_gb_RAM_LMU0_MISC",             "_lc_gb_RAM_LMU0_MISC_MPU_RESERVED"            ],
	"TRUSTED_WRITE_8_to_B   " : ["0x80000000",                       "0xAFFFFFF0"                                   ]
}

targetAddr = ""

with open('PR56453_APP.map') as map:
    for line in map:
        if "|" in line:
            tmplist = line.replace(" ","").split("|")
            for value in dict.values():
                if tmplist[1] in value and "_" in tmplist[1]:
                    if tmplist[1] == value[0]:
                        value[0] = tmplist[2]
                    else:
                        value[1] = tmplist[2]
            if sys.argv[1] in tmplist and "0x" in tmplist[2]:
                targetAddr = tmplist[2]

for key in dict.keys():
    print(key + "  " + dict[key][0] + "  " + dict[key][1])

print("\n" + targetAddr)