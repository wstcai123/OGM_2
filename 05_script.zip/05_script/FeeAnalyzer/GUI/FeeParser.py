#!/usr/bin/python
# -*- coding: UTF-8 -*-
 
import os
import csv
import sys
import binascii
from functools import partial
from bs4 import BeautifulSoup
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QSize
from ui import Ui_MainWindow
 
'''
  xx xx xx xx   xx xx xx xx      # First 8 bytes of 1st page, page size is 256 bytes
  |  |  |
  |  +--+------- Link Table Size # Total link entry in current sector
  +------------- Sector Id       # Unique id of sector, when switch sector, this id will plus 1
  
  xx xx xx xx   xx xx xx xx      # First 8 bytes of following page
  |  |  |  |
  +--+--+--+---- Link Entry Addr # Every link entry is an abs address in flash
'''
class Sector():
    def __init__(self):
        self.id = ""
        self.linkTable = []
        self.linkTableSize = 0
        # Record all the blocks existed in original dump file, there may be repeated block
        self.natureBlockList = []
        # Record all the unique blocks existed in original dump file
        self.uniqueBlockList = []
 
    def setId(self, Id):
        self.id = Id
 
    def addLinkTable(self, linkEntry):
        self.linkTable.append("0x" + linkEntry[4:6] + linkEntry[2:4] + linkEntry[0:2])
 
    def setLinkTableSize(self, linkTableSize):
        self.linkTableSize = int(linkTableSize[0:2] + linkTableSize[3:4], 16)
 
    def addNatureBlock(self, block):
        self.natureBlockList.append(block)
 
    def addUniqueBlock(self, block):
        self.uniqueBlockList.append(block)
 
''' 
  xx xx xx xx   xx xx xx xx    # First 8 bytes of 1st page, page size is 256 bytes
  |     |
  |     +------- Instance id   # One block may have several instance, other instance will be pointed by link entry
  +------------- Block Tag     # Unique tag of block, block tag will decide block type
  
  xx xx xx xx   xx xx xx xx    # First 8 bytes of 2nd page
  |  |  |  |
  +--+--+--+----               # If block instance is 2, 2nd page is link entry
                               # Else, 2nd page is data
  
  xx xx xx xx   xx xx xx xx    # First 8 bytes of 3rd page
  |  |  |  |
  +--+--+--+----               # If block instance is 2, 3rd page is link entry
                               # Else
                                   - If block data page counter > 1, 3rd page is data
                                   - Else, 3rd page is penultimate page
  
  xx xx xx xx   xx xx xx xx    # First 8 bytes of 4th page
  |  |  |  |
  +--+--+--+----               # If block instance is 2, 4th page is last page
                               # Else,
                                   - If block data page counter > 2, 4th page is data
                                   - If block data page counter = 2, 4th page is penultimate page
                                   - Else, 4th page is last page
  
  xx xx xx xx   xx xx xx xx    # First 8 bytes of penultimate page
  |  |  |  |
  +--+--+--+----               # Static bytes
                                   - 0A 00 08 00 09 00 05 XX
  
  xx xx xx xx   xx xx xx xx    # First 8 bytes of last page
  |  |  |  |
  +--+--+--+----               # Block tailer
                                   - Tailer will point to the 1st byte of the 1st page of the next block with the same tag
                                   - If all 0xFF, which means current block is the last one with this tag
'''
class Block():
    def __init__(self, BlockDictionary, SectorBaseAddr, PageSize):
        self.absAddress = ""
        self.tailer = ""
        self.data = ""
        self.tag = ""
        self.dataPageCounter = 0
        self.instance = 0
        self.dataSize = 0
        self.linkEntry = []
        self.PageSize = PageSize
        self.BlockDictionary = BlockDictionary
        self.SectorBaseAddr = SectorBaseAddr
 
    def setTailer(self, tailer):
        self.tailer = tailer
 
    def setTag(self, tag):
        self.tag = tag
 
    def setInstance(self, instance):
        try:
            self.instance = int(instance)
        except Exception as e:
            pass
 
    def setDataSize(self, size):
        self.dataSize = int(size[2:] + size[:2], 16) + 1
        self.dataPageCounter = int((self.dataSize + 1) / self.PageSize)
 
    def setAbsAddress(self, currentPageCounter):
        self.absAddress = self.SectorBaseAddr + currentPageCounter * self.PageSize
 
    def addLinkEntry(self, linkEntry):
        self.linkEntry.append(hex(int(linkEntry[4:6] + linkEntry[2:4] + linkEntry[0:2], 16) - 0x300))
 
    def setData(self, data):
        try:
            len = self.BlockDictionary[self.tag][0] * 2
            self.data = ' '.join(a+b for a,b in zip(data[0:len][::2], data[0:len][1::2]))
        except Exception as e:
            pass
 
class FeeParser(QtWidgets.QMainWindow, Ui_MainWindow):
  def __init__(self):
    super(FeeParser, self).__init__()
    self.setupUi(self)
    self.txtWidget = QTextEdit(self)
    self.gridLayout_2.addWidget(self.txtWidget)
    self.btnWidgetLst = []
    self.FeePartitionLst = []
    self.BlockDictionary = {}
    self.SectorDescriptor = Sector()
    self.pushButton.clicked.connect(self.ImportArxml)
    self.pushButton_2.clicked.connect(self.ImportDumpFile)
    self.pushButton_3.clicked.connect(self.StartParse)
    self.arxmlFile = ""
    self.dumpFile = ""
    self.SectorBaseAddr = 0
 
  def ImportArxml(self):
    fname = QFileDialog.getOpenFileName(None, "Select arxml", "/", "*.arxml")
    if fname[0]:
        self.arxmlFile = fname[0]
        self.txtWidget.setText(self.arxmlFile + " has been selected")
 
  def ImportDumpFile(self):
    #fname = QFileDialog.getOpenFileName(None, "Select dump", "/", "*.bin")
    fname = QFileDialog.getOpenFileName(None, "Select dump", "/", "*.*")
    if fname[0]:
        self.dumpFile = fname[0]
        self.txtWidget.setText(self.dumpFile + " has been selected")
 
  def StartParse(self):
    if self.arxmlFile == "" or self.dumpFile == "" or self.lineEdit.text() == "":
        self.txtWidget.setText("Plese import file and set base address!!")
    else:
        if self.comboBox.currentText() == "":
            self.GenBlockDictionaryFromArxml("")
            self.GenFeePartitionList()
        else:
            self.SectorBaseAddr = int(self.lineEdit.text(),16)
            self.BlockDictionary = self.GenBlockDictionaryFromArxml(self.comboBox.currentText())
            self.SectorDescriptor = self.ParseDumpFile()
            self.GenBlockWidgetList()
			
            # Export all block info into csv
            '''output = csv.writer(open("output.csv", 'w', newline=''))
            output.writerow(["Block Tag", "Block Name", "Block Size (Bytes)", "Block Data"])
            for block in self.SectorDescriptor.natureBlockList:
                output.writerow([block.tag, self.BlockDictionary[block.tag][1], self.BlockDictionary[block.tag][0], block.data])'''
 
  def GenFeePartitionList(self):
    feeCounter = 0
    self.comboBox.clear()
    for fee in self.FeePartitionLst:
        self.comboBox.addItem("")
        self.comboBox.setItemText(feeCounter, fee)
        feeCounter += 1
 
  def GenBlockWidgetList(self):
    for btnWidget in self.btnWidgetLst:
        self.gridLayout.removeWidget(btnWidget)
 
    self.btnWidgetLst = []
    for tag in self.BlockDictionary:
        blockName = self.BlockDictionary[tag][1]
        btnWidget = QPushButton(blockName, self)
        btnWidget.clicked.connect(partial(self.UpdateTextWidget, tag))
        self.btnWidgetLst.append(btnWidget)
        self.gridLayout.addWidget(btnWidget)
 
  def UpdateTextWidget(self, targetTag):
    printText = ""
    for block in self.SectorDescriptor.natureBlockList:
        if targetTag == block.tag:
            printText += block.data + "\n\n"
    self.txtWidget.setText(printText)
 
  '''
  BlockDictionary = {
    tag :  [ # Unique id of block
      size,  # Total byte size of block
      name ] # Name of block
  }
  '''
  def GenBlockDictionaryFromArxml(self, targetPartition):
    tag = ""
    size = 0
    BlockDictionary = {}
    handler = open(self.arxmlFile).read()
    soup = BeautifulSoup(handler, 'html.parser')
    for ecuc_container in soup.find_all('ecuc-container-value'):
        for def_ref in ecuc_container.find_all('definition-ref'):
            # Find block tag
            if (def_ref.get_text() == '/MICROSAR/Fee/FeeBlockConfiguration/FeeBlockId'):
                tag = hex(int(def_ref.find_next('value').text))[2:].zfill(2)
 
            # Find block size
            if (def_ref.get_text() == '/MICROSAR/Fee/FeeBlockConfiguration/FeeBlockSize'):
                size = int(def_ref.find_next('value').text)
 
            # Find block name
            name = ecuc_container.find('short-name').text
 
            # Construct block
            block = [size, name]
            
            # Push block to fee list
            if (def_ref.get_text() == '/MICROSAR/Fee/FeeBlockConfiguration/FeePartition'):
                tmpPar = def_ref.find_next('value-ref').text[16:]
                if tmpPar not in self.FeePartitionLst:
                    self.FeePartitionLst.append(tmpPar)
                if targetPartition == tmpPar and tag not in BlockDictionary:
                    BlockDictionary[tag] = block
    return BlockDictionary
 
  def ParseDumpFile(self):
    file = open(self.dumpFile, 'rb')
    TotalSize = os.path.getsize(self.dumpFile)
    PageSize = 256
    TotalPageCounter = TotalSize / PageSize
    sector = Sector()
    # Record internal page counter in current block
    BlockPageCounter = 0
    # Record current page number in origin dump file
    CurrentPageCounter = 0
    # Temp string to store block data
    tempData = ""
 
    while CurrentPageCounter < TotalPageCounter:
        page = str(binascii.b2a_hex(file.read(PageSize)))[2:]
        # Parse Sector Header
        if CurrentPageCounter == 0:
            sector.setId(page[0:2])
            sector.setLinkTableSize(page[2:6])
        # Parse Sector Link Table
        elif CurrentPageCounter <= sector.linkTableSize:
            sector.addLinkTable(page[0:6])
        # Parse Blocks
        else:
            BlockPageCounter += 1
            # Parse Block Header
            if BlockPageCounter == 1:
                # If no more block, break while
                if page[0:2] == "ff":
                    break
                # Else, create a new block
                tempBlock = Block(self.BlockDictionary, self.SectorBaseAddr, PageSize)
                tempBlock.setTag(page[0:2])
                tempBlock.setInstance(page[4:6])
                tempBlock.setAbsAddress(CurrentPageCounter)
 
                if tempBlock.instance != 2:
                    tempBlock.setDataSize(page[8:12])
            elif BlockPageCounter == 2:
                # If block instance is 2, 2nd page should includes one link entry
                if tempBlock.instance == 2:
                    tempBlock.addLinkEntry(page[0:6])
                # Else, 2nd page should be data
                else:
                    tempData += page[0:-2]
            elif BlockPageCounter == 3:
                # If block instance is 2, 3rd page should includes another link entry
                if tempBlock.instance == 2:
                    tempBlock.addLinkEntry(page[0:6])
                # If current block data page number >= 2, 3rd page should be data
                else:
                    if 2 <= tempBlock.dataPageCounter:
                        tempData += page[0:-2]
            else:
                if tempBlock.dataPageCounter == 2:
                    # Move to tailer page
                    page = str(binascii.b2a_hex(file.read(PageSize)))[2:]
                    CurrentPageCounter += 1
                elif tempBlock.dataPageCounter == 3:
                    # Current page is data
                    tempData += page[0:-2]
                    # Move to tailer page
                    page = str(binascii.b2a_hex(file.read(PageSize)))[2:]
                    page = str(binascii.b2a_hex(file.read(PageSize)))[2:]
                    CurrentPageCounter += 2
                elif tempBlock.dataPageCounter > 3:
                    # Current page is data
                    tempData += page[0:-2]
                    # More data page is needed
                    remainPageNumber = int(tempBlock.dataPageCounter - 3)
                    page = str(binascii.b2a_hex(file.read(PageSize * remainPageNumber)))[2:]
                    tempData += page[0:-2]
                    CurrentPageCounter += remainPageNumber
                    # Move to tailer page
                    page = str(binascii.b2a_hex(file.read(PageSize)))[2:]
                    page = str(binascii.b2a_hex(file.read(PageSize)))[2:]
                    CurrentPageCounter += 2
                else:
                    pass
 
                # Push block to nature block list
                tempBlock.setTailer(page[0:8])
                tempBlock.setData(tempData[2:])
                sector.addNatureBlock(tempBlock)
                # Reset temp variables
                tempData = ""
                BlockPageCounter = 0
 
        # Move to next page
        CurrentPageCounter += 1
    return sector
 
if __name__ == "__main__":
  app = QtWidgets.QApplication(sys.argv)
  form = FeeParser()
  form.show()
  app.exec_()