# coding=utf-8
# 解析 elf 文件需要导入的依赖库
# 安装 pyelftools 库
from elftools.elf.elffile import ELFFile

def main():
    segDict = {}
    segCnt = 0
    memSize = 0
    fileSize = 0
    output = open('RamRom_Report.txt','w')
    output.write("Elf file type is EXEC (Executable file)\n")
    output.write("Entry point 0x1d000004\n")
    output.write("There are 68 program headers, starting at offset 52\n\n")
    output.write("Program Headers:\n")
    output.write("Type      Offset    VirtAddr    PhysAddr  FileSiz     MemSiz    Flg  Align\n")
    file = open(r'SAIFRGen21RRPU_D7_R06a01.elf', 'rb')
    elf_file = ELFFile(file)
    #print(elf_file.header)
    #print(elf_file.num_segments())
    #print(elf_file.num_sections())
    '''for segment in elf_file.iter_segments():
        print(segment)
        #print(segment.header['p_align'])'''
    for segment in elf_file.iter_segments():
        segDict[segment.header['p_vaddr']] = ""
        fileSize += segment.header['p_filesz']
        memSize += segment.header['p_memsz']
        output.write(segment.header['p_type'].ljust(10))
        output.write(hex(segment.header['p_offset']).ljust(10))
        output.write(hex(segment.header['p_vaddr']).ljust(12))
        output.write(hex(segment.header['p_paddr']).ljust(10))
        output.write(hex(segment.header['p_filesz']).ljust(12))
        output.write(hex(segment.header['p_memsz']).ljust(10))
        #output.write(hex(segment.header['p_flags']).ljust(5))
        if segment.header['p_flags'] & 4 == 4:
            output.write("R")
        else:
            output.write(" ")
        if segment.header['p_flags'] & 2 == 2:
            output.write("W")
        else:
            output.write(" ")
        if segment.header['p_flags'] & 1 == 1:
            output.write("E")
        else:
            output.write(" ")
        output.write("  ")
        output.write(hex(segment.header['p_align']))
        output.write("\n")
    for section in elf_file.iter_sections():
        if section.header['sh_addr'] in segDict:
            segDict[section.header['sh_addr']] += " " + section.name
        #print(section.name)
        #print(section.header)
    output.write("\n Section to Segment mapping:\n")
    output.write("  Segment Sections...\n")
    for value in segDict.values():
        output.write(str(segCnt))
        segCnt += 1
        output.write(value)
        output.write("\n")
    RomTotalSize = 8 * 1024 * 1024
    RamTotalSize = 32 * 1024 * 1024
    output.write("\n")
    output.write('Rom Usage: {:.2%}'.format(fileSize / RomTotalSize) + "  # FileSize / 8M\n")
    output.write('Ram Usage: {:.2%}'.format(memSize / RamTotalSize) + "  # MemSize / 32M\n")

if __name__ == '__main__':
    main()