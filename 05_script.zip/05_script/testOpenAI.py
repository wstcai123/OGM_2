import requests
from requests.structures 
import CaseInsensitiveDict

openai.api_key = "YOUR_API_KEY" # 替换为自己的API密钥
def generate_image(prompt):    
  headers = CaseInsensitiveDict()    
  headers["Content-Type"] = "application/json"    
  headers["Authorization"] = f"Bearer {openai.api_key}"    
  data = """{"""
  data += f'"model": "image-alpha-001",'
  data += f'"prompt": "{prompt}",'
  data += """        "num_images":1,        "size":"256x256",        "response_format":"url"    }    """    
  resp = requests.post("https://api.openai.com/v1/images/generations", headers=headers, data=data)    
  if resp.status_code != 200:        
      raise ValueError("Failed to generate image "+resp.text)    
  response_text = resp.json()    
  return response_text['data'][0]['url']# 调用API生成图像
 
url = generate_image("a photo of an assassin riding on a horse on a grass field")
print(url)