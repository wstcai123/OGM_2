#!/usr/bin/python
#_*_ coding:utf_8 _*_

import os
import binascii

VectorLocation = {0:"LOVEC", 1:"HIVEC"}
EarlyHandoff = {0:"No Early Handoff", 1:"Early Handoff Enabled"}
Endianness = {0:"Little Endian", 1:"Big Endian"}
PartitionOwner = {0:"FSBL", 1:"U_Boot", 2:"Reserved", 3:"Reserved"}
RsaAuthCertPresent = {0:"No", 1:"Yes"}
ChecksumType = {0:"None", 1:"Reserved", 2:"Reserved", 3:"SHA3", 4:"Reserved", 5:"Reserved", 6:"Reserved", 7:"Reserved"}
DestinationCpu = {0:"None", 1:"A53_0", 2:"A53_1", 3:"A53_2", 4:"A53_3", 5:"R5_0", 6:"R5_1", 7:"R5_lockstep", 8:"PMU"}
EncryptionPresent = {0:"Not Encrypted", 1:"Encrypted"}
DestinationDevice = {0:"None", 1:"PS", 2:"PL", 3:"Reserved"}
A5xExecState = {0:"AARCH64", 1:"AARCH32"}
ExceptionLevel = {0:"EL0", 1:"EL1", 2:"EL2", 3:"EL3"}
TrustZone = {0:"Non_secure", 1:"Secure"}

if __name__=='__main__':
    path = "SAIFRGen21R____D7_R06a01_26M.bin"
    file = open(path, 'rb')  
    ImageHeaderTableOffset = 0x98
    BootStartAddress = 0x0
    AppAStartAddress = 0x00200000
    AppBStartAddress = 0x02600000
    DeviceBootHeaderStartAddr = [BootStartAddress, AppAStartAddress, AppBStartAddress]
    output = open("output.txt", "w")
    if os.path.getsize(path) == 26752 * 1024:
        Num = 2
    elif os.path.getsize(path) == 65536 * 1024:
        Num = 3
    else:
        print("Error!!")
    
    for idx in range(Num):
        # Parse Device Boot Header
        ImageHeaderTablePointer = ""
        PartitionHeaderPointer = ""
        file.seek(ImageHeaderTableOffset + DeviceBootHeaderStartAddr[idx])
        for i in range(4):
            ImageHeaderTablePointer = str(binascii.b2a_hex(file.read(1)))[2:-1] + ImageHeaderTablePointer
        for i in range(4):
            PartitionHeaderPointer = str(binascii.b2a_hex(file.read(1)))[2:-1] + PartitionHeaderPointer
        output.write("       Device Boot Header\n")
        output.write("ImageHeadTablePointer :0x" + ImageHeaderTablePointer + "\n")
        output.write("PartitionHeadPointer  :0x" + PartitionHeaderPointer + "\n\n")
        
        # Parse Image Header Table
        file.seek(int(ImageHeaderTablePointer,16) + DeviceBootHeaderStartAddr[idx])
        Version = binascii.b2a_hex(file.read(4))
        TotalParHeaderNumber = int(binascii.b2a_hex(file.read(1)),16)
        DumpByte = binascii.b2a_hex(file.read(3))
        FirstPartiHeaderOffset = binascii.b2a_hex(file.read(4))
        FirstImageHeaderOffset = binascii.b2a_hex(file.read(4))
        HeaderAuthCertificate = binascii.b2a_hex(file.read(4))
        BootDeviceForFsbl = binascii.b2a_hex(file.read(4))
        DumpByte = binascii.b2a_hex(file.read(36))
        Checksum = binascii.b2a_hex(file.read(4))
        output.write("       Image Header Table\n")
        output.write("Version               :" + str(Version) + "\n")
        output.write("TotalParHeaderNumber  :" + str(TotalParHeaderNumber) + "\n")
        output.write("FirstPartiHeadOffset  :" + str(FirstPartiHeaderOffset) + "\n")
        output.write("FirstImageHeadOffset  :" + str(FirstImageHeaderOffset) + "\n")
        output.write("BootDeviceForFsbl     :" + str(BootDeviceForFsbl) + "\n")
        output.write("Checksum              :" + str(Checksum) + "\n\n")
        
        # Parse Image Header
        PartiHeadCounter = 0
        ImageHeadCounter = 0
        tmpParNumberList = []
        tmpImageNameList = []
        while PartiHeadCounter < TotalParHeaderNumber:
            tmpParNumberList.append(PartiHeadCounter + 1)
            NextImageHeaderOffset = binascii.b2a_hex(file.read(4))
            CorrespondingParHeader = binascii.b2a_hex(file.read(4))
            DumpByte = binascii.b2a_hex(file.read(4))
            PartitionNumber = int(binascii.b2a_hex(file.read(1)),16)
            DumpByte = binascii.b2a_hex(file.read(3))
            ImageName = ""
            for i in range(12):
                tmpImageName = ""
                for i in range(4):
                    tmpChar = int(binascii.b2a_hex(file.read(1)),16)
                    if tmpChar != 0 and tmpChar != 255:
                        tmpImageName = chr(tmpChar) + tmpImageName
                ImageName += tmpImageName
            ImageHeadCounter += 1
            PartiHeadCounter += PartitionNumber
            tmpImageNameList.append(ImageName)
            output.write("       Image Header " + str(ImageHeadCounter) + "\n")
            output.write("NextImageHeaderOffset :" + str(NextImageHeaderOffset) + "\n")
            output.write("CorrespondingParHeader:" + str(CorrespondingParHeader) + "\n")
            output.write("PartitionNumber       :" + str(PartitionNumber) + "\n")
            output.write("ImageName             :" + str(ImageName) + "\n\n")
        
        # Parse Partition Header
        RelatedImageName = ""
        PartiHeadCounter = 0
        file.seek(int(PartitionHeaderPointer,16) + DeviceBootHeaderStartAddr[idx])
        output.write("_____________________________________________________________________________________________________________________________________________________________________________________________________\n")
        output.write("Partition Header No. | RelatedImageName | EncryptedParDataLen | UnencryptedParDataLen | TotalParWordLen | NextParHeadOffset | DestExecutionAddr | DestLoadAddr | ActualParWordOffset | SectionCount |\n")
        output.write("---------------------|------------------|---------------------|-----------------------|-----------------|-------------------|-------------------|--------------|---------------------|--------------|\n")
        while PartiHeadCounter < TotalParHeaderNumber:
            DestExecAddr = ""
            DestLoadAddr = ""
            Attribute = ""
            PartiHeadCounter += 1
            EncryptedParDataLen = binascii.b2a_hex(file.read(4))
            UnencryptedParDataLen = binascii.b2a_hex(file.read(4))
            TotalParWordLen = binascii.b2a_hex(file.read(4))
            NextParHeadOffset = binascii.b2a_hex(file.read(4))
            for i in range(8):
                DestExecAddr = str(binascii.b2a_hex(file.read(1)))[2:-1] + DestExecAddr
            for i in range(8):
                DestLoadAddr = str(binascii.b2a_hex(file.read(1)))[2:-1] + DestLoadAddr
            ActualParWordOffset = binascii.b2a_hex(file.read(4))
            for i in range(4):
                Attribute = str(binascii.b2a_hex(file.read(1)))[2:-1] + Attribute
            Attribute = bin(int(Attribute,16))[2:].zfill(32)[::-1]
            SectionCount = binascii.b2a_hex(file.read(1))
            DumpByte = binascii.b2a_hex(file.read(3))
            ChecksumWordOffset = binascii.b2a_hex(file.read(4))
            ImageHeadWordOffset = binascii.b2a_hex(file.read(4))
            PartitionId = binascii.b2a_hex(file.read(4))
            DumpByte = binascii.b2a_hex(file.read(4))
            HeaderChecksum = binascii.b2a_hex(file.read(4))
            if tmpParNumberList != [] and PartiHeadCounter == tmpParNumberList[0]:
                RelatedImageName = tmpImageNameList[0]
                tmpParNumberList.pop(0)
                tmpImageNameList.pop(0)
            output.write("       Partition Header " + str(PartiHeadCounter) + "\n")
            output.write("RelatedImageName      : " + RelatedImageName + "\n")
            output.write("EncryptedParDataLen   :" + str(EncryptedParDataLen) + "\n")
            output.write("UnencryptedParDataLen :" + str(UnencryptedParDataLen) + "\n")
            output.write("TotalParWordLen       :" + str(TotalParWordLen) + "\n")
            output.write("NextParHeadOffset     :" + str(NextParHeadOffset) + "\n")
            output.write("DestExecutionAddr     :0x" + DestExecAddr[8:] + "\n")
            output.write("DestLoadAddr          :0x" + DestLoadAddr[8:] + "\n")
            output.write("ActualParWordOffset   :" + str(ActualParWordOffset) + "\n")
            output.write("SectionCount          :" + str(int(SectionCount,16)) + "\n")
            output.write("ChecksumWordOffset    :" + str(ChecksumWordOffset) + "\n")
            output.write("ImageHeadWordOffset   :" + str(ImageHeadWordOffset) + "\n")
            output.write("PartitionId           :" + str(int(PartitionId,16)) + "\n")
            output.write("HeaderChecksum        :" + str(HeaderChecksum) + "\n")
            output.write("Attribute             :" + Attribute + "\n")
            output.write(" |_ VectorLocation    :" + VectorLocation[int(Attribute[23])] + "\n")
            output.write(" |_ EarlyHandoff      :" + EarlyHandoff[int(Attribute[19])] + "\n")
            output.write(" |_ Endianness        :" + Endianness[int(Attribute[18])] + "\n")
            output.write(" |_ PartitionOwner    :" + PartitionOwner[int(Attribute[16:17],2)] + "\n")
            output.write(" |_ RsaAuthCertPresent:" + RsaAuthCertPresent[int(Attribute[15])] + "\n")
            output.write(" |_ ChecksumType      :" + ChecksumType[int(Attribute[12:14],2)] + "\n")
            output.write(" |_ DestinationCpu    :" + DestinationCpu[int(Attribute[8:11],2)] + "\n")
            output.write(" |_ EncryptionPresent :" + EncryptionPresent[int(Attribute[7])] + "\n")
            output.write(" |_ DestinationDevice :" + DestinationDevice[int(Attribute[4:6],2)] + "\n")
            output.write(" |_ A5xExecState      :" + A5xExecState[int(Attribute[3])] + "\n")
            output.write(" |_ ExceptionLevel    :" + ExceptionLevel[int(Attribute[1:2],2)] + "\n")
            output.write(" |_ TrustZone         :" + TrustZone[int(Attribute[0])] + "\n\n")
             
            '''output.write("%21s"%(str(PartiHeadCounter)))
            output.write("---------------------|------------------|---------------------|-----------------------|-----------------|-------------------|-------------------|--------------|---------------------|--------------|\n")'''