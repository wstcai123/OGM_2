from Crypto.Hash import CMAC
from Crypto.Cipher import AES
from binascii import hexlify, unhexlify

RandomNumber = "596db5cb228e" # Please input random number here
KeyOfMrr = "6b308618148f48399bab627671dc38d2"
KeyOfSrr = "00000000000000000000000000000000"
secret= unhexlify(KeyOfSrr)
challenge = unhexlify(RandomNumber)
cmac = CMAC.new(secret, challenge, ciphermod=AES)
print(cmac.hexdigest())