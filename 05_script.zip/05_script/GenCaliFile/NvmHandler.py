'''OutputFile = open("fd30.bin", "ab+")
OriginData = open("fd30.txt", "r")
for line in OriginData:
	bytelist = line.split("0x")[1:]
	for strVal in bytelist:
		byte = int(strVal, base=16).to_bytes(1,"big")
		OutputFile.write(byte)'''


fd30 = open("fd30.bin", "ab+")
fd32 = open("fd32.bin", "ab+")
fd36 = open("fd36.bin", "ab+")

fd30_start = "EOL_Calibration_Parameters"
fd30_end = "Tx	22 FD 32"
fd36_start = "RCS_Calibration"
fd36_end = "Tx	22 FD 37"
fd32_start = "Element"
fd32_end1 = "Tx	22 FD 33"
fd32_end2 = "Tx	22 FD 34"
fd32_end3 = "Tx	22 FD 35"
fd32_end4 = "Tx	22 FD 36"

fd30_en = 0
fd32_en = 0
fd36_en = 0

OriginData = open("DiagConsoleLog.txt", "r")
for line in OriginData:
	if fd30_start in line:
		fd30_en = 1
	elif fd30_end in line:
		fd30_en = 0
	elif fd32_start in line:
		fd32_en = 1
	elif fd32_end1 in line or fd32_end2 in line or fd32_end3 in line or fd32_end4 in line :
		fd32_en = 0
	elif fd36_start in line:
		fd36_en = 1
	elif fd36_end in line:
		fd36_en = 0
	
	if fd30_en == 1:
		bytelist = line.split("0x")[1:]
		for strVal in bytelist:
			byte = int(strVal, base=16).to_bytes(1,"big")
			fd30.write(byte)
	elif fd32_en == 1:
		bytelist = line.split("0x")[1:]
		for strVal in bytelist:
			byte = int(strVal, base=16).to_bytes(1,"big")
			fd32.write(byte)
	elif fd36_en == 1:
		bytelist = line.split("0x")[1:]
		for strVal in bytelist:
			byte = int(strVal, base=16).to_bytes(1,"big")
			fd36.write(byte)