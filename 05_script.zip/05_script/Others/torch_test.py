import ssl
ssl._create_default_https_context = ssl._create_unverified_context

import torch
from diffusers import StableDiffusionPipeline

model_id = "CompVis/stable-diffusion-v1-4"
device = "cuda"
access_tokens = "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"

pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16, revision="fp16", use_auth_token=access_tokens, verify=False)
pipe = pipe.to(device)

prompt = "a photo of an astronaut riding a horse on mars"
image = pipe(prompt).images[0]  
    
image.save("astronaut_rides_horse.png")