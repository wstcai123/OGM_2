import sys
import csv
import dpkt
import zlib
import socket

class Parser():
    def __init__(self):
        #              Range,      Velocity,   Azimuth,    Elevation,  Rcs,        Snr         Power
        self.Factor = [0.006103609,0.000915541,0.002746624,0.002746624,0.470588235,0.235294118,0.470588235]    
        self.Offset = [0,          0,          -90,        -90,        -60,        0,          0]
        # Total bytes of all 3000 target list should be 84087
        self.TotalByte = []
        # Record the No. of current packet in whole wireshark log
        self.TotalCounter = 0
        # Record the byte offset of the next frame that should be received
        self.ByteOffset = 0
    
    def ParsePtl(self, InputLog):
        ### Start Parse
        fhdl = open(InputLog, 'rb')
        # Judge pcap or pcapng
        try:
            pcap = dpkt.pcap.Reader(fhdl)
        except Exception as e:
            fhdl.seek(0, 0)
            pcap = dpkt.pcapng.Reader(fhdl)
        # Traverse every frame
        for timestamp, buffer in pcap:
            self.TotalCounter += 1
            ethernet = dpkt.ethernet.Ethernet(buffer)
            # Filter message we don't need
            if not isinstance(ethernet.data, dpkt.ip.IP):
                continue
            ip = ethernet.data
            if socket.inet_ntoa(ip.src) != "192.168.0.60":
                continue
            # If potocol is udp or tcp, we need to get its data for twice. If tcp, we need check PostPtlFlag and PrePtlFlag
            if isinstance(ip.data, dpkt.udp.UDP):
                udp = ip.data
                packet = udp.data
            elif isinstance(ip.data, dpkt.tcp.TCP):
                tcp = ip.data
                packet = tcp.data
            else:
                packet = ip.data
            # Only parse udp packet with specific length, every 3000 target list is composed of 57 packets ( 8 groups )
            if packet[732] != 0 or packet[733] != 0 or packet[734] != 0 or packet[735] != 0:
                print(packet[732])
                print(packet[733])
                print(packet[734])
                print(packet[735])

if __name__=='__main__':
    myParser = Parser()
    myParser.ParsePtl("Diag_Test2022-09-30_00-38-54.pcapng")