import struct
import os

def WriteFile():
    filepath = 'wholeFF.bin'
    binfile = open(filepath, 'ab+')
    data = 255
    for i in range(1024*1024):
        binfile.write(struct.pack('B',data))
    binfile.close()

if __name__ == '__main__':
    WriteFile()