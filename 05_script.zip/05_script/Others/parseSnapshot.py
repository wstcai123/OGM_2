responseStr = "59 18 01 9C 70 00 2C 03 0A FD 21 00 00 FD 27 00 FD 1E FF FD 17 00 FD 25 00 00 00 FD 0A 00 00 FD 0B 00 00 01 0B 00 00 00 00 00 00 FD 0D 00 00 00 00 00 00 00 00 FD 1A 00 00 00 00 00 00"
responseStr = "59 18 01 9C 98 00 2C 01 05 01 12 89 E1 01 00 13 28 D0 01 30 01 0B 16 08 1A 0B 21 28 E0 10 00 00 03 0A FD 21 00 00 FD 27 88 FD 1E FF FD 17 00 FD 25 00 15 0D FD 0A F9 01 FD 0B F9 01 01 0B 16 08 1D 11 07 37 FD 0D 00 00 00 00 00 00 00 00 FD 1A 00 00 00 00 00 00"

def ParseSnapshot(responseStr):
    responseList = responseStr.split(" ")
    print("Memory Selection : " + str(responseList[2]))
    print("DTC Mask Record  : " + str(responseList[3]) + str(responseList[4]) + str(responseList[5]))
    print("Status Of DTC    : " + str(responseList[6]))
    print("Snapshot Number  : " + str(responseList[7]))
    print("Vehicle Speed    : " + str(responseList[11]) + str(responseList[12]))
    print("Battery Voltage  : " + str(responseList[15]))
    print("Radar Mode       : " + str(responseList[18]))
    print("System Mode      : " + str(responseList[21]))
    print("Vehicle Distance : " + str(responseList[24]) + str(responseList[25]) + str(responseList[26]))
    print("Temperature LPD  : " + str(responseList[29]) + str(responseList[30]))
    print("Temperature FPD  : " + str(responseList[33]) + str(responseList[34]))
    print("Timestamp        : " + str(responseList[37]) + str(responseList[38]) + str(responseList[39]) + str(responseList[40]) + str(responseList[41]) + str(responseList[42]))
    print("RF Chip 1 Tempe  : " + str(responseList[45]) + str(responseList[46]))
    print("RF Chip 2 Tempe  : " + str(responseList[47]) + str(responseList[48]))
    print("RF Chip 3 Tempe  : " + str(responseList[49]) + str(responseList[50]))
    print("RF Chip 4 Tempe  : " + str(responseList[51]) + str(responseList[52]))
    print("Monitor Trace    : " + str(responseList[55]) + str(responseList[56]) + str(responseList[57]) + str(responseList[58]) + str(responseList[59]) + str(responseList[60]))

ParseSnapshot(responseStr)