import ssl
ssl._create_default_https_context = ssl._create_unverified_context

from diffusers import StableDiffusionPipeline
import matplotlib.pyplot as plt

import ssl
ssl._create_default_https_context = ssl._create_unverified_context

access_tokens = "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"

model = StableDiffusionPipeline.from_pretrained("CompVis/stable-diffusion-v1-4", use_auth_token=access_tokens, cert_reqs=ssl.CERT_NONE)
model.to("cuda")

prompt = "Tokyo Sky Tree by Marc Chagall"

import re
filename = re.sub(r'[\\/:*?"<>|,]+', '', prompt).replace(' ', '_')

num = 4

for i in range(num):
    image = model(prompt, num_inference_steps=100)["sample"][0]
    outputfile = f'{filename} _{i:02} .png'
    image.save(f"outputfile/{outputfile}")

for i in range():
    outputfile = f'{filename} _{i:02} .png'
    plt.imshow(plt.imread(f"outputfile/{outputfile}"))
    plt.axis('off')