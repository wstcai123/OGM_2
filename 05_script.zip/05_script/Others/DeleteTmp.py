import os

root = "C:/Users/Z0089052/OneDrive - ZF Friedrichshafen AG/Documents/01_mks/ZF_FRGen21R____D7_R99a01"
for dirpath, dirnames, filenames in os.walk(root):
    for filepath in filenames:
        if os.path.join(dirpath, filepath).endswith(".tmp"):
            os.remove(os.path.join(dirpath, filepath))