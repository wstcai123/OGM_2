import paddlehub as hub
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import ssl

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

module = hub.Module(name="ernie_vilg")

image_text = ['宁静的小镇']

my_style = '油画'
images = module.generate_image(text_prompt=image_text, style=my_style, output_dir="./")