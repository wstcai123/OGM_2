import subprocess
def runcmd(command):
    ret = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8", timeout=1)
    if ret.returncode == 0:
        print(ret.stdout)
        print(len(ret.stdout))
    else:
        print("error:",ret.stderr)


runcmd(["arp","-a"])