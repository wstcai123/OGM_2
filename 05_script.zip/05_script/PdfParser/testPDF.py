from PyPDF2 import PdfReader

file = open("1.txt", mode="w", encoding='utf-8', errors='ignore')
reader = PdfReader("test.pdf") 
number_of_pages = len(reader.pages)
page = reader.pages[0]
text = page.extract_text() 
file.write(text) 