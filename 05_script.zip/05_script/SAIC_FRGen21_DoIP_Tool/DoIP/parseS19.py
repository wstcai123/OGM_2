flashFiles = ["SAIFRGen21R____D7_R05a13_CAL.s19"]

MotorolaFormatDict = {'S1':8,'S2':10,'S3':12}
FlashUnitList = []
 
counter = 0
for file in flashFiles:
   findStartFlag = False
   originData = ""
   counter = 0
   with open(file, "r") as s19Handler:
      for line in s19Handler.readlines():
        if line[:2] in MotorolaFormatDict:
          counter += 1
          idx = MotorolaFormatDict[line[0:2]]
          byteNumber = int(line[2:4],16)
          originData += line[idx:-3]
          if findStartFlag == False:
            findStartFlag = True
            startAddr = line[4:idx]
          endAddr = int(line[4:idx],16) + byteNumber - 5
          if counter < 10:
            print(line[idx:-3])
            print("\n")
            print(originData)
            print("\n")
 
   size = format(endAddr - int(startAddr,16), 'x').zfill(8)
   addr = startAddr
   print(size)
   print(addr)
   print(counter)