# @Time : 2021/6/24 22:30 
# @Author : Tesla
# @File : 13.修改本地连接mac地址.py 
# @Software: PyCharm
# Csdn : https://blog.csdn.net/zhu6201976
 
import re
import sys
import ctypes
import winreg
import platform
import subprocess
 
class CommunicateInstance():
    def __init__(self, remoteMac, remoteIp, localMac, localIp, vlanId, ethCard):
        self.remoteMac = remoteMac
        self.remoteIp = remoteIp
        self.localMac = localMac
        self.localIp = localIp
        self.vlanId = vlanId
        self.ethCard = ethCard
 
class SetCommEnvironment():
    """
    修改 本地连接 mac地址
    """
 
    def __init__(self, commInstance):
        # regex to MAC address like 00-00-00-00-00-00 or 00:00:00:00:00:00 or
        # 000000000000
        self.MAC_ADDRESS_RE = re.compile(r"""
            ([0-9A-F]{1,2})[:-]?
            ([0-9A-F]{1,2})[:-]?
            ([0-9A-F]{1,2})[:-]?
            ([0-9A-F]{1,2})[:-]?
            ([0-9A-F]{1,2})[:-]?
            ([0-9A-F]{1,2})
            """, re.I | re.VERBOSE)  # re.I: case-insensitive matching. re.VERBOSE: just look nicer.
 
        self.WIN_REGISTRY_PATH = "SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002BE10318}"
        self.commInstance = commInstance
 
    def is_admin(self):
        """
        is user an admin?
        :return:
        """
        if ctypes.windll.shell32.IsUserAnAdmin() == 0:
            print('Sorry! You should run this with administrative privileges if you want to change your MAC address.')
            sys.exit()
 
    def get_macinfos(self):
        """
        查看所有mac信息
        :return:
        """
        print('=' * 50)
        mac_info = subprocess.check_output('GETMAC /v /FO list', stderr=subprocess.STDOUT)
        mac_info = mac_info.decode('gbk')
        print('Your MAC address:\n', mac_info)
 
    def get_target_device(self):
        """
        返回 本地连接 网络适配器
        :return:
        """
        mac_info = subprocess.check_output('GETMAC /v /FO list', stderr=subprocess.STDOUT)
        mac_info = mac_info.decode('gbk')
        #search = re.search(r'(本地连接)\s+网络适配器: (.+)\s+物理地址:', mac_info)
        search = re.search(r'Intel(R) Ethernet Controller (3) I225-LM - VLAN : VLAN131', mac_info)
        target_name, target_device = (search.group(1), search.group(2).strip()) if search else ('', '')
        '''if not all([target_name, target_device]):
            print('Cannot find the target device')
            sys.exit()'''
 
        print(target_name, target_device)
        target_device = "Intel(R) Ethernet Controller (3) I225-LM"
        return target_device
 
    def setMac(self):
        """
        设置新mac地址
        :param target_device: 本地连接 网络适配器
        :param new_mac: 新mac地址
        :return:
        """
        if not self.MAC_ADDRESS_RE.match(self.commInstance.localMac):
            print('Please input a correct MAC address')
            return
 
        # Locate adapter's registry and update network address (mac)
        reg_hdl = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
        key = winreg.OpenKey(reg_hdl, self.WIN_REGISTRY_PATH)
        info = winreg.QueryInfoKey(key)
 
        # Find adapter key based on sub keys
        adapter_key = None
        adapter_path = None
        target_index = -1
 
        for index in range(info[0]):
            subkey = winreg.EnumKey(key, index)
            path = self.WIN_REGISTRY_PATH + "\\" + subkey
 
            if subkey == 'Properties':
                break
 
            # Check for adapter match for appropriate interface
            new_key = winreg.OpenKey(reg_hdl, path)
            try:
                adapterDesc = winreg.QueryValueEx(new_key, "DriverDesc")
                if adapterDesc[0] == self.commInstance.ethCard:
                    adapter_path = path
                    target_index = index
                    break
                else:
                    winreg.CloseKey(new_key)
            except (WindowsError) as err:
                if err.errno == 2:  # register value not found, ok to ignore
                    pass
                else:
                    raise err
 
        if adapter_path is None:
            print('Device not found.')
            winreg.CloseKey(key)
            winreg.CloseKey(reg_hdl)
            return
 
        # Registry path found update mac addr
        adapter_key = winreg.OpenKey(reg_hdl, adapter_path, 0, winreg.KEY_WRITE)
        winreg.SetValueEx(adapter_key, "NetworkAddress", 0, winreg.REG_SZ, self.commInstance.localMac)
        winreg.CloseKey(adapter_key)
        winreg.CloseKey(key)
        winreg.CloseKey(reg_hdl)
 
        # Adapter must be restarted in order for change to take affect
        # print 'Now you should restart your netsh'
        self.restart_adapter(target_index, self.commInstance.ethCard)
 
    def restart_adapter(self, target_index, target_device):
        """
        Disables and then re-enables device interface
        """
        if platform.release() == 'XP':
            # description, adapter_name, address, current_address = find_interface(device)
            cmd = "devcon hwids =net"
            try:
                result = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
            except FileNotFoundError:
                raise
            query = '(' + target_device + '\r\n\s*.*:\r\n\s*)PCI\\\\(([A-Z]|[0-9]|_|&)*)'
            query = query.encode('ascii')
            match = re.search(query, result)
            cmd = 'devcon restart "PCI\\' + str(match.group(2).decode('ascii')) + '"'
            subprocess.check_output(cmd, stderr=subprocess.STDOUT)
        else:
            cmd = "wmic path win32_networkadapter where index=" + str(target_index) + " call disable"
            subprocess.check_output(cmd)
            cmd = "wmic path win32_networkadapter where index=" + str(target_index) + " call enable"
            subprocess.check_output(cmd)
 
    def run(self):
        self.is_admin()
        self.get_macinfos()
        target_device = self.get_target_device()
        print(target_device)
        self.setMac()
        self.setVlan()
        self.setIp()
        self.setStaticArp()
 
    def setVlan(self):
        Command = 'Add-IntelNetVLAN -ParentName "' + self.commInstance.ethCard +'" -VLANID ' + self.commInstance.vlanId
        print(Command)
        print(self.runCommand(Command))
 
    def setIp(self):
        Command = 'netsh interface ipv4 set address "' + self.commInstance.ethCard +'" -VLANID:VLAN' + self.commInstance.vlanId + '" static ' + self.commInstance.localIp
        print(Command)
        print(self.runCommand(Command))
 
    def removeVlan(self):
        Command = 'Remove-IntelNetVLAN -ParentName "' + self.commInstance.ethCard +'" -VLANID ' + self.commInstance.vlanId
        print(Command)
        print(self.runCommand(Command))
 
    def setStaticArp(self):
        Command = 'arp -s ' + self.commInstance.remoteIp + ' ' + self.commInstance.remoteMac + " " + self.commInstance.localIp
        print(Command)
        print(self.runCommand(Command))
 
    def runCommand(self, command):
        POWERSHELL_COMMAND = r'C:\WINDOWS\system32\WindowsPowerShell\v1.0\powershell.exe'
        subprocess.Popen([POWERSHELL_COMMAND, command],
                  stdout = subprocess.PIPE,
                  stderr = subprocess.PIPE)
 
if __name__ == '__main__':
    commInstance = CommunicateInstance(remoteMac="02-80-5E-1F-01-28", remoteIp="172.31.134.40", localMac="02805E1F0121", localIp="172.31.134.33", vlanId="134", ethCard="Intel(R) Ethernet Controller (3) I225-LM")
    setEnv = SetCommEnvironment(commInstance)
    setEnv.run()