import sys
import time
import socket
import binascii
from functools import partial
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from UI import Ui_MainWindow
from PyDoIP import DoIP_Client
from SwitchButton import SwitchBtn

class FlashUnitInfo():
    def __init__(self):
        self.size = 0
        self.addr = ""
        self.data = ""
 
class FlashThread(QThread):
    _signal_1 = pyqtSignal(int)
    _signal_2 = pyqtSignal(str)
 
    def __init__(self, doipClient, flashFiles):
        super(FlashThread, self).__init__()
        self.doipClient = doipClient
        self.flashFiles = flashFiles
 
    def __del__(self):
        self.wait()
 
    def run(self):
        # Number means data start index in line
        MotorolaFormatDict = {'S1':8,'S2':10,'S3':12}
        FlashUnitList = []
        originData = ""
        startAddr = ""
        endAddr = 0
 
        # Define error code
        ErrorCode = 0
        ErrorDescription = ""
 
        # Define progress value
        progress = 0
 
        for file in self.flashFiles:
            flashUnit = FlashUnitInfo()
            with open(file, "r") as s19Handler:
                #lineCounter = len(s19Handler.readlines())
                #print(lineCounter)
                for line in s19Handler.readlines():
                    #print(line[:2])
                    if line[:2] in MotorolaFormatDict:
                        idx = MotorolaFormatDict[line[0:2]]
                        byteNumber = int(line[2:4],16)
                        originData += line[idx:-3]
                        # 1st line inclueds start address
                        if startAddr == "":
                            startAddr = line[4:idx]
                        # FRGen21 s19 file end flag is "A5A5", bytes after end flag are not needed, 5 bytes totally
                        #print(line[4:idx])
                        endAddr = int(line[4:idx],16) + byteNumber - 5
                        #progress += 5 / lineCounter
                        self._signal_1.emit(progress)
 
            flashUnit.size = format(endAddr - int(startAddr, 16), 'x').zfill(8)
            flashUnit.addr = startAddr
            flashUnit.data = originData
            FlashUnitList.append(flashUnit)
            progress += 2
            self._signal_1.emit(progress)
 
        self.doipClient.DoIPSendSingleCommand("1002")
        time.sleep(3)
        self.doipClient.DisconnectFromDoIPServer()
        time.sleep(3)
        self.doipClient.ConnectToDoIPServer()
        time.sleep(3)
        if self.doipClient.DoIPSecurityAccess("05") == 0:
            dll = "dll/seedkey_Programming.dll"
            key = self.doipClient.DoIPGenerateAccessKeyViaDll(dll, self.doipClient._RxDoIPMsg.payload)
            if self.doipClient.DoIPSecurityAccess("06", key) == 0:
                while self.doipClient._DoIPUDSRecv() == 0:
                    if self.doipClient._RxDoIPMsg.payload == "6706":
                        pass
 
        for flashUnit in FlashUnitList:
            maxBlockByteCount = self.doipClient.DoIPRequestDownload(flashUnit.addr, flashUnit.size)
 
            if maxBlockByteCount >= 2:
                # subtract 2 for SID and index
                maxBlockByteCount -= 2
            else:
                ErrorDescription = "0x34 service error ..\n"
                ErrorCode = 1
 
            totalBlockNumber = len(FlashUnitList) * len(flashUnit.data) / (maxBlockByteCount * 2)
            currentBlockIndex = 1
            currentDataOffset = 0
            while currentDataOffset < len(flashUnit.data):
                blockIndex = '%.2X' % (currentBlockIndex & 0xFF)
 
                if len(flashUnit.data) - currentDataOffset > (maxBlockByteCount * 2):
                    blockData = flashUnit.data[currentDataOffset : currentDataOffset + maxBlockByteCount * 2]
                    currentDataOffset += maxBlockByteCount * 2
                else:
                    blockData = flashUnit.data[currentDataOffset :]
                    currentDataOffset = len(flashUnit.data)
 
                if self.doipClient.DoIPTransferData(blockIndex, blockData) != 0:
                    ErrorDescription = "0x36 service error ..\n"
                    ErrorCode = 2
                    break
                else:
                    progress += 90 / totalBlockNumber
                    self._signal_1.emit(progress)
                    currentBlockIndex += 1
 
            if ErrorCode == 0:
                if self.doipClient.DoIPRequestTransferExit("00") != 0:
                    ErrorDescription = "0x37 service error ..\n"
                    ErrorCode = 3
 
        # Programming Integrity Check
        if ErrorCode == 0:
            if self.doipClient.DoIPRoutineControl("01", "DFFF") != 0:
                ErrorDescription = "0xDFFF service error ..\n"
                ErrorCode = 4
            else:
                progress = 98
                self._signal_1.emit(progress)
 
        # Programming Dependencies Check
        if ErrorCode == 0:
            if self.doipClient.DoIPRoutineControl("01", "FF01") != 0:
                ErrorDescription = "0xFF01 service error ..\n"
                ErrorCode = 5
            else:
                progress = 100
                self._signal_1.emit(progress)
 
        '''self.doipClient.DoIPReadDID("B088")
        self.doipClient.DoIPReadDID("F1A0")
        self.doipClient.DoIPSwitchDiagnosticSession_Test(2)
        self.doipClient.DoIPReadDID("B088")
        self.doipClient.DoIPReadDID("F1A0")'''
        #self.doipClient.DoIPSwitchDiagnosticSession(1)
 
        # Return back to application
        '''if ErrorCode == 0:
            if self.doipClient.DoIPEcuReset("01") != 0:
                ErrorDescription = "0x1101 service error ..\n"
                ErrorCode = 6'''
 
        self._signal_2.emit(ErrorDescription)
 
class SAIC_DoIP(QtWidgets.QMainWindow, Ui_MainWindow):
  def __init__(self):
    super(SAIC_DoIP, self).__init__()
    self.setupUi(self)
    self.pushButton.clicked.connect(self.SendSingleCommand)
    self.pushButton_2.clicked.connect(self.ImportFlashFile)
    self.pushButton_3.clicked.connect(self.AddServiceToSeq)
    self.pushButton_4.clicked.connect(self.StartCommandSequence)
    self.pushButton_5.clicked.connect(self.StartFlash)
    self.pushButton_6.clicked.connect(self.EstablishTcpConnection)
    self.svcNumber = 0
    self.widgetDict = {}
    #self.switchBtn.checkedChanged.connect(self.ChangeTcpSocketState)
    self.doipClient = DoIP_Client('172.31.134.33', 13400, '0E80')
    #self.switchBtn = SwitchBtn()
    #self.gridLayout_3.addWidget(self.switchBtn, 0, 0)
    self.flashFiles = []
    self._isTCPConnected = False
 
  def __del__(self):
    self.doipClient.DisconnectFromDoIPServer()
 
  def StartFlash(self):
    self.flashThread = FlashThread(self.doipClient, self.flashFiles)
    self.flashThread._signal_1.connect(self.PrintProgress)
    self.flashThread._signal_2.connect(self.PrintErrorCode)
    self.flashThread.start()
    self.pushButton_5.setEnabled(False)
 
  def ImportFlashFile(self):
    self.flashFiles = QFileDialog.getOpenFileNames(None, "Select s19", "C:/Users/Z0089052/Documents/99_work/SAIC_FRGEN21_Development_Main/ZZZ_Build_Products", "*.s19")[0]
    for file in self.flashFiles:
        self.textEdit.insertPlainText(file + " has been selected.\n")
 
  @pyqtSlot(int)
  def PrintProgress(self, step):
    self.progressBar.setValue(step)
    if step == 100:
      self.pushButton_5.setEnabled(True)
 
  @pyqtSlot(str)
  def PrintErrorCode(self, ErrorCode):
    self.textEdit.insertPlainText(ErrorCode)
    self.pushButton_5.setEnabled(True)
 
  def AddServiceToSeq(self):
    service = self.comboBox.currentText()[2:4] + self.lineEdit.text().replace(" ","")
    txtWidget  = QLabel(service, self)
    editWidget = QLineEdit("", self)
    btnWidget  = QPushButton("-", self)
    self.widgetDict[self.svcNumber] = [txtWidget, editWidget, btnWidget, service, True]
    btnWidget.clicked.connect(partial(self.RemoveServiceFromSeq, self.svcNumber))
    self.gridLayout.addWidget(txtWidget,  self.svcNumber, 0)
    self.gridLayout.addWidget(editWidget, self.svcNumber, 1)
    self.gridLayout.addWidget(btnWidget,  self.svcNumber, 4)
    self.svcNumber += 1
 
  def RemoveServiceFromSeq(self, svcNumber):
    txtWidget  = self.widgetDict[svcNumber][0]
    editWidget = self.widgetDict[svcNumber][1]
    btnWidget  = self.widgetDict[svcNumber][2]
    txtWidget.setParent(None)
    editWidget.setParent(None)
    btnWidget.setParent(None)
    self.gridLayout.removeWidget(txtWidget)
    self.gridLayout.removeWidget(editWidget)
    self.gridLayout.removeWidget(btnWidget)
    self.widgetDict[svcNumber][4] = False
 
  def StartCommandSequence(self):
    if self.lineEdit_2.text() == "":
        self.textEdit.insertPlainText("Please input repeat times !!\n")
    else:
        repeatTimes = int(self.lineEdit_2.text())
        for i in range(repeatTimes):
            for key in self.widgetDict:
                if self.widgetDict[key][4] == True:
                    self.textEdit.insertPlainText(self.widgetDict[key][2] + " \n")
 
  def SendSingleCommand(self):
    if self.lineEdit.text() == "":
      self.textEdit.insertPlainText("Please input a completed command !!")
    else:
      diagService = self.comboBox.currentText()[2:4] + self.lineEdit.text().replace(" ","")
      self.textEdit.insertPlainText(diagService + " \n")
      rcvPayload = self.doipClient.DoIPSendSingleCommand(diagService)
      if None != rcvPayload:
        self.textEdit.insertPlainText(rcvPayload + " \n")
 
  def Print(self, text):
    self.textEdit.insertPlainText(text)
 
  def EstablishTcpConnection(self):
    if not self._isTCPConnected:
      self.doipClient.ConnectToDoIPServer()
      if self._isTCPConnected:
        self.textEdit.insertPlainText("Tcp connection established Successfully !!\n")
        self.pushButton_6.setText("Disconnect Tcp")
    else:
      self.doipClient.DisconnectFromDoIPServer()
      if not self._isTCPConnected:
        self.textEdit.insertPlainText("Tcp connection disconnected !!\n")
        self.pushButton_6.setText("Connect Tcp")
 
  @pyqtSlot(int)
  def ChangeTcpSocketState(self, state):
    self.switchBtn.mousePressEvent()
 
if __name__ == '__main__':
  app = QtWidgets.QApplication(sys.argv)
  form = SAIC_DoIP()
  form.show()
  app.exec_()