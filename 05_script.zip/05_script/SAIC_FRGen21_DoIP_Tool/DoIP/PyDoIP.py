import os
import sys
import time
import socket
import binascii
import platform
import PyUDS
from ctypes import *

# DoIP Header Structure : <protocol version><inverse protocol version><payload type><payloadlength><payload>
# Payload format : <local ecu address> <optional: target ecu addres> <optional message ><ASRBISO><ASRBOEM>

PROTOCOL_VERSION = DOIP_PV = '02'
INVERSE_PROTOCOL_VERSION = DOIP_IPV = 'FD'

# Payload type definitions#
DOIP_GENERIC_NEGATIVE_ACKNOWLEDGE = DOIP_NARP = '0000'
DOIP_VEHICLE_ID_REQUEST = '0001'
DOIP_VEHICLE_ID_REQUEST_W_EID = '0002'
DOIP_VEHICLE_ID_REQUEST_W_VIN = '0003'
DOIP_VEHICLE_ANNOUNCEMENT_ID_RESPONSE = '0004'
# DOIP_ROUTING_ACTIVATION_REQUEST : <0005><sourceaddress><activation type><00000000>
DOIP_ROUTING_ACTIVATION_REQUEST = DOIP_RAR = '0005'
# Activation Type
DEFAULT_ACTIVATION = '00'
WWH_OBD_ACTIVATION = '01'
# 0x02-0xDF ISOSAE Reserved
CENTRAL_SECURITY_ACTIVATION = 'E0'
# 0xE1-0xFF OEM Specific
ACTIVATION_SPACE_RESERVED_BY_ISO = ASRBISO = '00000000'
# the code above is mandatory but has no use at the moment. ISOSAE Reserved
ACTIVATION_SPACE_RESERVED_BY_OEM = ASRBOEM = 'ffffffff'

DOIP_ROUTING_ACTIVATION_RESPONSE = '0006'
DOIP_ALIVE_CHECK_REQUEST = '0007'
DOIP_ALIVE_CHECK_RESPONSE = '0008'
# 0x009-0x4000: Reserved by ISO13400
DOIP_ENTITY_STATUS_REQUEST = '4001'
DOIP_ENTITY_STATUS_RESPONSE = '4002'
DOIP_DIAGNOSTIC_POWER_MODE_INFO_REQUEST = '4003'
DOIP_DIAGNOSTIC_POWER_MODE_INFO_RESPONSE = '4004'
# 0x4005-0x8000 Reserved by ISO13400
DOIP_DIAGNOSTIC_MESSAGE = DOIP_UDS = '8001'
DOIP_DIAGNOSTIC_POSITIVE_ACKNOWLEDGE = '8002'
DOIP_DIAGNOSTIC_NEGATIVE_ACKNOWLEDGE = '8003'
# 0x8004-0xEFFF Reserved by ISO13400
# 0xF000-0xFFFF Reserved for manufacturer-specific use


payloadTypeDescription = {
    int(DOIP_GENERIC_NEGATIVE_ACKNOWLEDGE): "Generic negative response",
    int(DOIP_VEHICLE_ID_REQUEST): "Vehicle ID request",
    int(DOIP_VEHICLE_ID_REQUEST_W_EID): "Vehicle ID request with EID",
    int(DOIP_VEHICLE_ID_REQUEST_W_VIN): "Vehicle ID request with VIN",
    int(DOIP_VEHICLE_ANNOUNCEMENT_ID_RESPONSE): "Vehicle announcement ID response",
    int(DOIP_ROUTING_ACTIVATION_REQUEST): "Routing activation request",
    int(DOIP_ROUTING_ACTIVATION_RESPONSE): "Routing activation response",
    int(DOIP_ALIVE_CHECK_REQUEST): "Alive check request",
    int(DOIP_ALIVE_CHECK_RESPONSE): "Alive check response",
    int(DOIP_ENTITY_STATUS_REQUEST): "Entity status request",
    int(DOIP_ENTITY_STATUS_RESPONSE): "Entity status response",
    int(DOIP_DIAGNOSTIC_POWER_MODE_INFO_REQUEST): "Diagnostic power mode info request",
    int(DOIP_DIAGNOSTIC_POWER_MODE_INFO_RESPONSE): "Power mode info response",
    int(DOIP_DIAGNOSTIC_MESSAGE): "Diagnostic message",
    int(DOIP_DIAGNOSTIC_POSITIVE_ACKNOWLEDGE): "Diagnostic positive acknowledge",
    int(DOIP_DIAGNOSTIC_NEGATIVE_ACKNOWLEDGE): "Diagnostic negative acknowledge",
}

# to be changed later as an option in terminal
defaultTargetIPAddr = '172.31.134.40'
#defaultTargetIPAddr = '192.168.0.60'
defaultTargetECUAddr = '0E80'

def PadHexwithLead0s(hexStr):
    if isinstance (hexStr, str): # Make sure input argument is string
        if len(hexStr) % 2 != 0: # If the length is not even
             hexStr = '0' + hexStr # Add a leading '0' to get even length
    return hexStr

class DoIP_Client:
    def __init__(self, address, port, ECUAddr):

        # to do: need to add underscores for private properties...
        # init tcp socket
        self._localIPAddr = address
        
        # Reason for the if statement is that self._TCP_Socket.bind() does not seem to work in Windows when address == '0'
        if "Window" in platform.platform(): # Checks if software is running in the Windows OS
        
            # Use an netowrk interface IP address
            #
            # WARNING: If there are multiple IP addresses, the first IP address found will be used
            # The first IP address may not be the desired IP adress.
            # So it is recommended to temporarily close all other network interfaces used by the software
            # self._localIPAddr = socket.gethostbyname(socket.getfqdn())
            self._localIPAddr = address
            #print(self._localIPAddr)
        #print(self._localIPAddr)
        
        self._localPort = port
        self._localECUAddr = ECUAddr
        self._targetIPAddr = None
        self._targetPort = None
        #self._targetECUAddr = None
        self._targetECUAddr = "0734"
        self._isTCPConnected = False
        self._isRoutingActivated = False
        self._isVerbose = False
        self._TxDoIPMsg = DoIPMsg()
        self._RxDoIPMsg = DoIPMsg()
        self._logHndl = open('flash.log', 'w+')
        self._diagFunctionTable = {}

        try:
            self._TCP_Socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # self._TCP_Socket.setsockopt(socket.IPPROTO_TCP, 12, 1)#supposedly, 12 is TCP_QUICKACK option id
            self._TCP_Socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)  # immediately send to wire wout delay
            self._TCP_Socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # allows different sockets to reuse ipaddress

            self._TCP_Socket.settimeout(5.0)
            # self._TCP_Socket.setblocking(1)
            self._TCP_Socket.bind((self._localIPAddr, self._localPort))
            print("Socket successfully created: Binded to %s:%d" % (
                self._TCP_Socket.getsockname()[0], self._TCP_Socket.getsockname()[1]))

        except socket.error as err:
            print("Socket creation failed with error: %s" % err)
            if '[Errno 10049]' in str(err):
                print("Consider changing your machine's TCP settings so that it has a satic IP of 172.26.200.15")
            self._TCP_Socket = None

    def __enter__(self):
        return self

    def ConnectToDoIPServer(self, address=defaultTargetIPAddr, port=13400, routingActivation=False, targetECUAddr=defaultTargetECUAddr):
        if self._isTCPConnected:
            print("Error :: Already connected to a server. Close the connection before starting a new one\n")
        else:
            if not self._TCP_Socket:
                print("Warning :: Socket was recently closed but no new socket was created.\nCreating new socket with last available IP address and Port")
                try:
                    self._TCP_Socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    # self._TCP_Socket.setsockopt(socket.IPPROTO_TCP, 12, 1)#supposedly, 12 is TCP_QUICKACK option id
                    self._TCP_Socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)  # immediately send to wire wout delay
                    self._TCP_Socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    self._TCP_Socket.settimeout(5.0)
                    # self._TCP_Socket.setblocking(1)
                    self._TCP_Socket.bind((self._localIPAddr, self._localPort))
                    print("Socket successfully created: Binded to %s:%d\n" % (
                        self._TCP_Socket.getsockname()[0], self._TCP_Socket.getsockname()[1]))
                except socket.error as err:
                    print("Socket creation failed with error %s" % (err))
                    self._TCP_Socket = None
                    return err
            if self._TCP_Socket != None:
                try:
                    print("Connecting to DoIP Server at %s:%d... " % (address, port))
                    self._targetIPAddr = address
                    self._targetPort = port
                    self._TCP_Socket.connect((address, port))
                    self._isTCPConnected = True
                    print("Connection to DoIP established\n")
                except socket.error as err:
                    print("Unable to connect to socket at %s:%d. Socket failed with error: %s" % (address, port, err))
                    self._targetIPAddr = None
                    self._targetPort = None
                    self._isTCPConnected = False
            else:
                return -1

        if routingActivation == False:
            return 0
        elif routingActivation == True and self._isTCPConnected:
            self._targetECUAddr = targetECUAddr
            if self.RequestRoutingActivation() == 0:
                return 0
            else:
                return -1
        elif routingActivation and not self._isTCPConnected:
            print("Error :: DoIP client is not connected to a server")
            return -1

    def DisconnectFromDoIPServer(self):
        if self._isTCPConnected:
            try:
                print("Disconnecting from DoIP server...")
                self._TCP_Socket.shutdown(socket.SHUT_RDWR)
                self._TCP_Socket.close()
                self._TCP_Socket = None
                self._isTCPConnected = 0
                print("Connection successfully shut down\n")
            except socket.error as err:
                print("Unable to disconnect from socket at %s:%d. Socket failed with error: %s." % (
                    self._targetIPAddr, self._targetPort, err))
                print("Warning :: Socket is currently in a metastable state.")
            finally:
                self._targetIPAddr = None
                self._targetPort = None
                self._isTCPConnected = 0
        else:
            print("Error :: DoIP client is not connected to a server")

    def RequestRoutingActivation(self, activationType=DEFAULT_ACTIVATION, localECUAddr=None, targetECUAddr=None):
        if self._isTCPConnected:
            try:
                if not localECUAddr:
                    localECUAddr = self._localECUAddr
                if not targetECUAddr:
                    targetECUAddr = self._targetECUAddr
                DoIPHeader = PROTOCOL_VERSION + INVERSE_PROTOCOL_VERSION + DOIP_ROUTING_ACTIVATION_REQUEST
                payload = localECUAddr + activationType + ASRBISO + ASRBOEM
                payloadLength = "%.8X" % (len(payload) / 2)  # divide by 2 because 2 nibbles per byte
                activationString = DoIPHeader + payloadLength + payload
                self._TxDoIPMsg.UpdateMsg(activationString, self._isVerbose)
                print("Requesting routing activation...")
                if self._isVerbose:
                    print("TCP SEND ::")
                    self._TxDoIPMsg.PrintMessage()
                self._TCP_Socket.send(activationString.decode("hex"))
                activationResponse = (binascii.hexlify(self._TCP_Socket.recv(2048))).upper()
                if self._isVerbose:
                    print("TCP RECV ::")
                DoIPResponse = DoIPMsg(activationResponse, self._isVerbose)
                if DoIPResponse.payload[0:2] == '10':
                    self._isRoutingActivated = True
                    self._targetECUAddr = DoIPResponse.targetAddress
                    print("Routing activated with ECU: %s\n" % (self._targetECUAddr))
                    return 0
                else:
                    self._isRoutingActivated = False
                    print("Unable to activate routing")
                    return -1
            except socket.error as err:
                print("Unable to activate routing with ECU:%.4X. Socket failed with error: %s" % (
                    int(targetECUAddr), err))
                self._isRoutingActivated = 0
                self._targetECUAddr = None
                return -1
        else:
            print("Unable to request routing activation. Currently not connected to a DoIP server")

    def _DoIPUDSSend(self, message, localECUAddr=None, targetECUAddr=None, logging=True):
        if self._isTCPConnected:
            try:
                if not localECUAddr:
                    localECUAddr = self._localECUAddr
                if not targetECUAddr:
                    targetECUAddr = self._targetECUAddr
                DoIPHeader = PROTOCOL_VERSION + INVERSE_PROTOCOL_VERSION + DOIP_DIAGNOSTIC_MESSAGE
                payload = self._localECUAddr + self._targetECUAddr + message  # no ASRBISO
                payloadLength = "%.8X" % (int(len(payload) / 2))
                UDSString = DoIPHeader + payloadLength + payload
                self._TxDoIPMsg.UpdateMsg(UDSString)
                if logging == True:
                    if self._TxDoIPMsg.isUDS:
                        self._logHndl.write('Client: ' + self._TxDoIPMsg.payload + '\n')
                    else:
                        self._logHndl.write('Client: ' + self._TxDoIPMsg.DecodePayloadType() + '\n')
                if self._isVerbose:
                    print("TCP SEND ::")
                    self._TxDoIPMsg.PrintMessage()
                self._TCP_Socket.send(bytes([int(UDSString[i:i+2], 16) for i in range(0, len(UDSString), 2)]))
                return 0
            except socket.error as err:
                print("Unable to send UDS Message to ECU:%d. Socket failed with error: %s" % (targetECUAddr, err))
                return -1
        else:
            print("Not currently connected to a server")
            return -3

    def _DoIPUDSRecv(self, rxBufLen=1024, logging=False):
        if self._isTCPConnected:
            try:
                if self._isVerbose:
                    print("TCP RECV ::")
                #self._RxDoIPMsg.UpdateMsg(binascii.hexlify(self._TCP_Socket.recv(rxBufLen)).upper())
                self._RxDoIPMsg.UpdateMsg(self._TCP_Socket.recv(rxBufLen).hex())
                if logging == True:
                    if self._RxDoIPMsg.isUDS:
                        self._logHndl.write('Server: ' + self._RxDoIPMsg.payload + '\n')
                    else:
                        self._logHndl.write('Server: ' + self._RxDoIPMsg.DecodePayloadType() + '\n')
                # check for positive ack, memory operation pending, or transfer operation pending
                if self._RxDoIPMsg.payload == PyUDS.MOPNDNG or \
                        self._RxDoIPMsg.payload == PyUDS.TOPNDNG or \
                        self._RxDoIPMsg.payload == DOIP_DIAGNOSTIC_POSITIVE_ACKNOWLEDGE:
                    return self._DoIPUDSRecv()
                elif self._RxDoIPMsg.payloadType == DOIP_GENERIC_NEGATIVE_ACKNOWLEDGE:
                    return -2
                else:
                    return 0
            except socket.error as err:
                print("Unable to receive UDS message. Socket failed with error: %s" % (err))
                return -1
        else:
            print("Not currently connected to a server")
            return -3

    def DoIPSendSingleCommand(self, diagService):
        self._DoIPUDSSend(diagService)
        while (self._DoIPUDSRecv() == 0):
            if self._RxDoIPMsg.payload[:2] == "78":
                pass
            else:
                return self._RxDoIPMsg.payload
    
    def DoIPReadDID(self, DID):
        self._DoIPUDSSend(PyUDS.RDBI + DID)
        return self._DoIPUDSRecv()

    def DoIPWriteDID(self, DID, msg):
        self._DoIPUDSSend(PyUDS.WDBI + DID + msg)
        return self._DoIPUDSRecv()

    def DoIPRoutineControl(self, subfunction, routine_id, op_data=""):
        #print("Sending routine control command, subfunction:" + str(subfunction) + " routine id:" + str(routine_id))
        self._DoIPUDSSend(PyUDS.RC + subfunction + routine_id + op_data)
        return self._DoIPUDSRecv()

    def DoIPEraseMemory(self, componentID):
        print("Erasing memory...")
        
        if type(componentID) == 'int':
            componentID = '%0.2X' % (0xFF & componentID)
            
        componentID = PadHexwithLead0s(componentID)
        print(PyUDS.RC + PyUDS.STR + PyUDS.RC_EM + str(componentID))
        self._DoIPUDSSend(PyUDS.RC + PyUDS.STR + PyUDS.RC_EM + str(componentID))  # #  TO DO: CHANGE VALUE TO VARAIBLE
        return self._DoIPUDSRecv()

    def DoIPCheckMemory(self, componentID, CRCLen='00', CRC='00'):
        print("Checking memory...")
        
        if type(componentID) == 'int':
            componentID = '%.2X' % (0xFF & componentID)
            
        componentID = PadHexwithLead0s(componentID)
        self._DoIPUDSSend(PyUDS.RC + PyUDS.STR + PyUDS.RC_CM + str(componentID) + CRCLen + CRC)
        return self._DoIPUDSRecv()

    def DoIPSwitchDiagnosticSession(self, sessionID=1):
        targetSession = ''
        if int(sessionID) == 1:
            print("Switching to Default Diagnostic Session...")
            self._DoIPUDSSend(PyUDS.DSC + PyUDS.DS)
        elif int(sessionID) == 2:
            print("Switching to Programming Diagnostic Session...")
            self._DoIPUDSSend(PyUDS.DSC + PyUDS.PRGS)
            time.sleep(3)
            self.DisconnectFromDoIPServer()
            time.sleep(3)
            self.ConnectToDoIPServer()
        elif int(sessionID) == 3:
            print("Switching to Extended diagnostic Session...")
            self._DoIPUDSSend(PyUDS.DSC + PyUDS.EXTDS)
        else:
            print("Invalid diagnostic session. Session ID: 1) Default session 2) Programming session 3) Extended session")
            return -1

        return self._DoIPUDSRecv()
 
    def DoIPSwitchDiagnosticSession_Test(self, sessionID):
        targetSession = ''
        if int(sessionID) == 1:
            print("Switching to Default Diagnostic Session...")
            self._DoIPUDSSend(PyUDS.DSC + PyUDS.DS)
        elif int(sessionID) == 2:
            print("Switching to Programming Diagnostic Session...")
            self._DoIPUDSSend(PyUDS.DSC + PyUDS.PRGS)
        elif int(sessionID) == 3:
            print("Switching to Extended diagnostic Session...")
            self._DoIPUDSSend(PyUDS.DSC + PyUDS.EXTDS)
        else:
            print("Invalid diagnostic session. Session ID: 1) Default session 2) Programming session 3) Extended session")
            return -1

        return self._DoIPUDSRecv()

    def DoIPRequestDownload(self, memAddr, memSize, dataFormatID=PyUDS.DFI_00, addrLenFormatID=PyUDS.ALFID):
        print("Requesting download data...")
        self._DoIPUDSSend(PyUDS.RD + dataFormatID + addrLenFormatID + memAddr + memSize)
        while (self._DoIPUDSRecv() == 0):
            if self._RxDoIPMsg.payload != None and self._RxDoIPMsg.payload[:2] == "74":
                print("Request download data success\n")
                dlLenFormatID = int(self._RxDoIPMsg.payload[2], 16)  # number of bytes
                break
        #return int(self._RxDoIPMsg.payload[4:(2 * dlLenFormatID + 4)], 16)
        return int(self._RxDoIPMsg.payload[4:9], 16)

    def DoIPTransferData(self, blockIndex, data):
        self._DoIPUDSSend(PyUDS.TD + blockIndex + data)
        while (self._DoIPUDSRecv()) == 0:
            if self._RxDoIPMsg.payload[:2] == "76":
                return 0

    def DoIPRequestTransferExit(self, op_data):
        print("Requesting transfer exit...")
        self._DoIPUDSSend(PyUDS.RTE + op_data)
        return self._DoIPUDSRecv()

    def DoIPSecurityAccess(self, subFun, key=""):
        if subFun == "01" or subFun == "05" or subFun == "61":
            self._DoIPUDSSend(PyUDS.SA + subFun)
        if subFun == "02" or subFun == "06" or subFun == "62":
            self._DoIPUDSSend(PyUDS.SA + subFun + key)
        while (self._DoIPUDSRecv()) == 0:
            if self._RxDoIPMsg.payload[:2] == "67":
                return 0

    def DoIPGenerateAccessKeyViaDll(self, dll, receivedSeed):
        strKey = ""
        seed = []
        seed.append(int(receivedSeed[4:6]  ,16))
        seed.append(int(receivedSeed[6:8]  ,16))
        seed.append(int(receivedSeed[8:10] ,16))
        seed.append(int(receivedSeed[10:12],16))
        mylib = CDLL(dll)
        seed = (c_byte * 4)(seed[0], seed[1], seed[2], seed[3]) # these bytes you should get from the ECU i.e.
        key = (c_byte * 4)() # this will contain the secret key after Dll call
        keylength = c_int(4) # this will contain the secret key length after Dll call
        mylib.GenerateKeyEx(
          pointer(seed),      # Seed from the ECU
          c_int(4),           # Example: Seed length = 4 bytes
          c_int(1),           # Example: Security Level 1
          None,               # Example: NULL = No variant string
          pointer(key),       # Key to send back to the ECU
          c_int(4),           # Example: Key Max length = 4 bytes
          pointer(keylength), # Example: Seed length = 4 bytes
        )
        
        for i in range(4):
            if key[i] < 0:
                strKey += format(256 + key[i], "x").zfill(2)
            else:
                strKey += format(key[i], "x").zfill(2)
        
        return strKey

    def DoIPEcuReset(self, subFun):
        self._DoIPUDSSend(PyUDS.ER + subFun)
        return self._DoIPUDSRecv()

    def SetVerbosity(self, verbose):
        self._isVerbose = verbose

    def Terminate(self):
        print("Closing DoIP Client ...")
        self._TCP_Socket.close()
        self._logHndl.close()
        print("Good bye")

    def __exit__(self, exc_type, exc_value, traceback):
        self.Terminate()

class DoIPMsg:
    def __init__(self, message=None, verbose=False):
        self.UpdateMsg(message, verbose)

    def UpdateMsg(self, message=None, verbose=True):
        if not message:
            self.messageString = None
            self.protcolVersion = self.inverseProtocolVersion = None
            self.payloadType = self.payloadLength = None
            self.sourceAddress = self.targetAddress = None
            self.payload = None
            self.isUDS = False
        else:
            self.messageString = message
            self.protcolVersion = message[0:2]
            self.inverseProtocolVersion = message[2:4]
            self.payloadType = message[4:8]
            self.payloadLength = message[8:16]
            self.sourceAddress = message[16:20]
            if self.payloadType == DOIP_ROUTING_ACTIVATION_REQUEST:
                self.targetAddress = None
            else:
                self.targetAddress = message[20:24]

            if self.payloadType == DOIP_DIAGNOSTIC_MESSAGE:
                self.isUDS = True
                self.payload = message[24:len(message)]
            else:
                self.payload = message[24:len(message) - len(ASRBISO)]
                self.isUDS = False
            if verbose:
                self.PrintMessage()

    def PrintMessage(self):
        print("Protocol Version         : " + str(self.protcolVersion))
        print("Inv. Protocol Version    : " + str(self.inverseProtocolVersion))
        print("Payload Type             : " + str(self.payloadType))
        #print("Payload Type Description : " + str(self.DecodePayloadType(self.payloadType)))
        print("Payload Length           : " + str(self.payloadLength))
        print("Source Address           : " + str(self.sourceAddress))
        print("Target Address           : " + str(self.targetAddress))
        print("Payload                  : " + str(self.payload))
        print("")

    def DecodePayloadType(self, payloadType=None):
        if payloadType == None:
            payloadType = self.payloadType
        return payloadTypeDescription.get(int(payloadType), "Invalid or unregistered diagnostic payload type")

'''def Test_Switch_Diagnostic_Session(sessionID, verbose=False):
    # Function to Switch Diagnostic Session Then Close Socket
    print("Switching to sessionID: " + str(sessionID))
    # start a DoIP client
    DoIPClient = DoIP_Client()
    DoIPClient.SetVerbosity(verbose)
    seed = [0 for i in range(4)]
    strKey = ""

    if DoIPClient._TCP_Socket:
        DoIPClient.ConnectToDoIPServer()

        #if DoIPClient._isTCPConnected and DoIPClient._isRoutingActivated:
        if DoIPClient._isTCPConnected:
            print("Switching diagnostic session")
            #try:
            if 1:
                DoIPClient.DoIPSwitchDiagnosticSession(sessionID)
                if sessionID == 3:
                    if DoIPClient.DoIPSecurityAccess("01") == 0:
                        dll = "C:/Users/Z0089052/Documents/05_script/SAIC_FRGen21_DoIP_Tool/DoIP/SeednKey_Extended.dll"
                        key = DoIPClient.DoIPGenerateAccessKeyViaDll(dll, DoIPClient._RxDoIPMsg.payload)
                        DoIPClient.DoIPSecurityAccess("02", key)
                if sessionID == 2:
                    time.sleep(3)
                    DoIPClient.DisconnectFromDoIPServer()
                    time.sleep(3)
                    DoIPClient.ConnectToDoIPServer()
                    DoIPClient.DoIPSwitchDiagnosticSession(2)
                    time.sleep(3)
                    if DoIPClient.DoIPSecurityAccess("05") == 0:
                        dll = "C:/Users/Z0089052/Documents/05_script/SAIC_FRGen21_DoIP_Tool/DoIP/seedkey_Programming.dll"
                        key = DoIPClient.DoIPGenerateAccessKeyViaDll(dll, DoIPClient._RxDoIPMsg.payload)
                        if DoIPClient.DoIPSecurityAccess("06", key) == 0:
                            while DoIPClient._DoIPUDSRecv() == 0:
                                if DoIPClient._RxDoIPMsg.payload == "6706":
                                    pass
                        DoIP_Flash_S19(DoIPClient)
            #except socket.error as err:
                #DoIPClient.DisconnectFromDoIPServer()
            time.sleep(5)
            DoIPClient.DisconnectFromDoIPServer()

        else:
            print("Error while connect to ECU and//or activate routing. Exiting erase memory sequence.")
    else:
        print("Error while creating DoIP client. Unable to initiate erase memory sequence.")'''

if __name__ == '__main__':
    Test_Switch_Diagnostic_Session(1)