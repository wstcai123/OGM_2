# -*- coding: utf-8 -*
# *************************************************************************************************
# 编码风格:
# 1. 类名用驼峰命名法，即类名中每个单词首字母都大写，且不使用下划线。
# 2. 实例名和模块名都采用小写格式，并在单词之间加上下划线。
# 3. 对于每个类，都应紧跟在类定义后包含一个文档字符串，简要地描述类的功能。
# 4. 每个模块也都应包含一个文档字符串，对其中的类可用于做什么进行描述。
# 5. 可使用空行来组织代码，但不要滥用。在类中，一个空行来分隔方法；而在模块中，两个空行来分隔类。
# 6. 需要同时导入标准库模块和自己编写的模块时，先导入标准库模块，空一行，再导入自己编写的模块。
# *************************************************************************************************

import socket as s
import socket
# import struct
import binascii, time, re, os, sys, logging, datetime, random
import paramiko # ssh telnet
from paramiko import AuthenticationException
from paramiko.client import SSHClient, AutoAddPolicy
from paramiko.ssh_exception import NoValidConnectionsError
socket.setdefaulttimeout(3) # 默认最大等待时间s

class SomeipProtocol():
    """模拟车载以太网SOMEIP协议收发的简单尝试"""

    def __init__(self, service_id, method_id):
        """初始化描述someip报文的属性"""
        self.service_id = service_id
        self.method_id = method_id
        self.host_ip = '192.168.1.100'        # Destination IP
        self.port = 50302                     # Destination Port
        self.max_payload_length = 10          # SOMEIP Payload Length， 该值可自行修改，设定任意长度
    
    def get_description(self):
        """返回整洁的属性描述信息"""
        attribute_description = '0x' + str(self.service_id) + ' ' + '0x' + str(self.method_id)
        print("\nService ID: " + '0x' + str(self.service_id))
        print("Method ID: " + '0x' + str(self.method_id))
        print("Destination Host IP: " + str(self.host_ip))
        print("Destination Port: " + str(self.port))
        print("Payload length(Dec): " + str(self.max_payload_length))
        return attribute_description

    def len_format(self, num, len):
        """对数据做格式化, 去掉16进制数前面的0x"""
        length_hex = hex(num)
        if length_hex.startswith('0x'):
            str_length = length_hex[2:]      # 去掉16进制数前面的0x
        total_length = str_length.zfill(len)
        return total_length

    def send_fire_forget_request(self):
        """模拟发送someip F&F请求消息, 预期接收端不回复响应, 但会触发回调函数, 有打印信息输出"""
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((self.host_ip, self.port))    # 建立TCP连接

        """
        定义payload前6个字节(不包括最前面的4字节长度)的值
        分别为十六进制'00','11','22','33','44','55'
        便于在终端输出打印log时观察到。
        """
        payload_data_array = ['00', '0b', '16', '21', '2c', '37']
        payload_data_array_others = ''
        for i in range(6, self.max_payload_length):
            str = someip.len_format(i%256, 2)      # 00--ff 范围递增
            payload_data_array_others += str

        payload_length_dec = int(len(payload_data_array_others)/2+6)
        payload_total_length = someip.len_format(payload_length_dec, 8)

        someip_payload = payload_total_length + \
                        payload_data_array[0] + \
                        payload_data_array[1] + \
                        payload_data_array[2] + \
                        payload_data_array[3] + \
                        payload_data_array[4] + \
                        payload_data_array[5] + \
                        payload_data_array_others

        someip_service_id = self.service_id          # 通过传参定义 Service ID
        someip_method_id = self.method_id            # 通过传参定义 Method ID

        someip_length_dec = payload_length_dec + 12  # 该值需要根据Payload长度做调整
        someip_length = someip.len_format(someip_length_dec, 8)

        someip_client_id = '0001'
        someip_session_id = '0001'
        someip_version = '01'
        someip_interface_version = '01'
        someip_message_type = '01'  # Request no response
        someip_return_code = '00'

        someip_header = someip_service_id + \
                        someip_method_id + \
                        someip_length + \
                        someip_client_id + \
                        someip_session_id + \
                        someip_version + \
                        someip_interface_version + \
                        someip_message_type + \
                        someip_return_code

        someip_header.strip()
        someip_header = someip_header.replace(" ", "")      #去除字符串开头或者结尾的空格
        seq = (someip_header, someip_payload)               # 字符串序列
        str = ""
        data_16 = str.join(seq)                             # 发送报文拼接
        data_hex = binascii.a2b_hex(data_16)                # 加上\x

        s.send(data_hex)					                #发送SOMEIP F&F请求
        print("SOMEIP F&F请求(Service ID: 0x" + self.service_id + ", Method ID: 0x" + self.method_id + ")报文已发送成功!")

        time.sleep(1)
        s.close()   # 断开TCP连接

if __name__ == '__main__':
    # 定义F&F消息类型列表
    fire_forget_list = [{'service_id': '0001', 'method_id': '0001'},
                        {'service_id': '0001', 'method_id': '0002'},
                        {'service_id': '0001', 'method_id': '0003'},
                        {'service_id': '0002', 'method_id': '0001'},
                        {'service_id': '0002', 'method_id': '0002'}]

    for arg in fire_forget_list:
        """创建一个表示特定someip终端的实例"""
        someip = SomeipProtocol(service_id=arg['service_id'], method_id=arg['method_id'])
        someip.get_description()
        someip.send_fire_forget_request()