from socket import *

# UDP
client=socket(AF_INET, SOCK_DGRAM)
client.connect(('172.31.131.40', 30490))
msg = "ffff81000000003000000276010102006000000000000010060000103575000101ffffff000000010000000c00090400ac1f832200118852"
client.send(bytes([int(msg[i:i+2], 16) for i in range(0, len(msg), 2)]))
client.close()