counter = 0
blockSize = 0
blockData = ""
extraData = ""
with open(file="SAIFRGen21R____D7_R05a14_CAL.s19", mode="r") as s19Handler:
    for line in s19Handler.readlines():
        if counter >= 1:
            lineData = line.strip()[12:-2]
            #print(lineData)
            lineSize = len(lineData)
            #print(lineSize)
            if blockSize + lineSize < 4093 * 2:
                blockData += lineData
                blockSize += lineSize
            else:
                extraSize = 4093 * 2 - blockSize
                blockData += lineData[:extraSize]
                #transfer data
                print(blockData)
                blockData = lineData[extraSize:]
                blockSize = len(blockData)
        counter += 1
    print(blockData)

block = "36015A5A00030192000001A1EFFF01A1FFFC01A1FFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"

print(len(block))