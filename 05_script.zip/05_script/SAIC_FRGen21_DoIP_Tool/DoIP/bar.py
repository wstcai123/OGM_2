import sys
from PyQt5.QtWidgets import QApplication,QWidget,QToolTip,QLabel,QLineEdit,\
    QPushButton,QFrame,QProgressBar
from PyQt5.QtCore import QBasicTimer
 
 
class example(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
 
    def initUI(self):
        self.resize(600,400)
        self.setWindowTitle('进度条')
 
        # new button : b
        self.b = QPushButton(self)
        self.b.setText('start')
        self.b.move(100,200)
        self.b.clicked.connect(self.do)
 
        # new 进度条 : bar
        self.bar = QProgressBar(self)
        self.bar.setGeometry(50,100,300,50)
        self.timer = QBasicTimer()
        self.step = 0
 
        self.show()
 
    def do(self):
 
        if self.timer.isActive(): # 激活
            self.timer.stop();    # 时钟停止
            self.b.setText('stop')
        else:
            self.timer.start(100,self);   # 时钟开始 100个信号 每个0.1s
            self.b.setText('start')
 
    def timerEvent(self,e): # 时钟
        if self.step>=100:
           self.timer.stop()
           self.b.setText('over');
        else:
           self.step+=1
           self.bar.setValue(self.step)
 
a = QApplication(sys.argv)
ex = example()
sys.exit(a.exec())