import sys
import csv
import dpkt
import zlib
import socket

class Parser():
    def __init__(self):
        #              Range,      Velocity,   Azimuth,    Elevation,  Rcs,        Snr         Power
        self.Factor = [0.006103609,0.000915541,0.002746624,0.002746624,0.470588235,0.235294118,0.470588235]    
        self.Offset = [0,          0,          -90,        -90,        -60,        0,          0]
        # Total bytes of all 3000 target list should be 84087
        self.TotalByte = []
        # Record the No. of current packet in whole wireshark log
        self.TotalCounter = 0
        # Record the byte offset of the next frame that should be received
        self.ByteOffset = 0
    
    def ParsePtl(self, InputLog):
        # Only need packet with below specific length
        ValidPacketLength = [1307,1472,1480]
        # Record last cycle counter to check whether packets lost
        LastCycleCounter = 0
        # This flag indicates that the first frame has been received
        FirstFrameFlag = False
        # First cycle counter will not be checked
        FirstCntCheck = True
        # 71 03 f0 27 is the flag for post ptl
        PostPtlFlag = True
        # 71 03 f0 27 is the flag for pre ptl
        PrePtlFlag = True
        # Output
        OutputPre  = csv.writer(open("OutputPre.csv",  'w', newline=''))
        OutputPost = csv.writer(open("OutputPost.csv", 'w', newline=''))
        OutputPre.writerow(["No.","CycleCounter","NoOfTargets","Range","Velocity","Azimuth","Elevation","Rcs","Snr","Power","Crc Check","CycleCounter Check"])
        OutputPost.writerow(["No.","CycleCounter","NoOfTargets","Range","Velocity","Azimuth","Elevation","Rcs","Snr","Power","Crc Check","CycleCounter Check"])

        ### Start Parse
        fhdl = open(InputLog, 'rb')
        # Judge pcap or pcapng
        try:
            pcap = dpkt.pcap.Reader(fhdl)
        except Exception as e:
            fhdl.seek(0, 0)
            pcap = dpkt.pcapng.Reader(fhdl)
        # Traverse every frame
        for timestamp, buffer in pcap:
            self.TotalCounter += 1
            ethernet = dpkt.ethernet.Ethernet(buffer)
            # Filter message we don't need
            if not isinstance(ethernet.data, dpkt.ip.IP):
                continue
            ip = ethernet.data
            if socket.inet_ntoa(ip.src) != "192.168.0.60":
                continue
            # If potocol is udp or tcp, we need to get its data for twice. If tcp, we need check PostPtlFlag and PrePtlFlag
            if isinstance(ip.data, dpkt.udp.UDP):
                udp = ip.data
                packet = udp.data
            elif isinstance(ip.data, dpkt.tcp.TCP):
                tcp = ip.data
                packet = tcp.data
                # F0 27 is the last routine of ROL Calibration
                if len(packet) == 17 and packet[12] == 0x71 and packet[13] == 0x03 and packet[14] == 0xf0 and packet[15] == 0x27 and packet[16] == 0x02:
                    PostPtlFlag = True
                # F0 19 is the first routine for entering EOL Mode
                if len(packet) == 17 and packet[12] == 0x71 and packet[13] == 0x01 and packet[14] == 0xf0 and packet[15] == 0x19:
                    PrePtlFlag = True
            else:
                packet = ip.data
            # Only parse udp packet with specific length, every 3000 target list is composed of 57 packets ( 8 groups )
            #if (len(packet) in ValidPacketLength) and PrePtlFlag == True and self.TotalCounter < 160:
            if len(packet) in ValidPacketLength:
                RecOffset = (ip.off & 0x1FFF) << 3
                MoreFragment = (ip.off & 0x2000) >> 13
                if MoreFragment == 1 and RecOffset == 0:
                    FirstFrameFlag = True
                if self.ByteOffset == RecOffset and FirstFrameFlag == True:
                    if self.ByteOffset == 0:
                        self.TotalByte += packet[4:]
                        self.ByteOffset += len(packet) + 8
                    else:
                        self.TotalByte += packet
                        self.ByteOffset += len(packet)
                    if len(self.TotalByte) < 84000:
                      print("totalByte  : " + str(len(self.TotalByte)))
                      print("byteOffset : " + str(self.ByteOffset))
                    else:
                      break
                if MoreFragment == 0:
                    self.ByteOffset = 0
                    # When compose whole 84087 bytes, calculate CRC and parse detection info
                    if len(self.TotalByte) == 84087:
                        ### PART I : Compare original CRC and calculated CRC
                        OriCrc = ""
                        for i in range(4):
                            OriCrc += format(self.TotalByte[67 - i],'x').zfill(2)
                        # Replace 4 CRC bytes with 0xFF
                        for i in range(4):
                            self.TotalByte[67 - i] = 0xFF
                        # If original CRC are all 0, we will not check
                        if OriCrc != "00000000":
                            CalCrc = format(zlib.crc32(bytes(self.TotalByte)),'x').zfill(8)
                            if CalCrc != OriCrc:
                                CrcCheckResult = "Original CRC is : " + OriCrc + "; "
                                CrcCheckResult += "Calculated CRC is : " + CalCrc
                            else:
                                CrcCheckResult = "OK"
                        else:
                            CrcCheckResult = "00000000"
                        ### PART II : Parse detection info
                        # Calculate cycle counter
                        tmpCycleCounter = ""
                        for i in range(8):
                            tmpCycleCounter += format(self.TotalByte[63 - i],'x').zfill(2)
                        CycleCounter = int(tmpCycleCounter,base=16)
                        if FirstCntCheck == True:
                            CntCheckResult = "OK"
                            FirstCntCheck = False
                        else:
                            if CycleCounter - LastCycleCounter == 1:
                                CntCheckResult = "OK"
                            else:
                                CntCheckResult = "Current cycle counter is : " + str(CycleCounter) + "; "
                                CntCheckResult += "Last cycle counter is : " + str(LastCycleCounter)
                        LastCycleCounter = CycleCounter
                        # Calculate number of targets
                        NumberOfTarg = int(format(self.TotalByte[69],'x').zfill(2) + format(self.TotalByte[68],'x').zfill(2),base=16)
                        # Output every target
                        if PostPtlFlag == True:
                            output = OutputPost
                        if PrePtlFlag == True:
                            output = OutputPre
                        idx = 0
                        while idx < NumberOfTarg:
                            CsvlogInfo = []
                            CsvlogInfo.append(str(self.TotalCounter))
                            CsvlogInfo.append(str(CycleCounter))
                            CsvlogInfo.append(str(NumberOfTarg))
                            # Range
                            Range = int(format(self.TotalByte[88 + idx * 28],'x').zfill(2) + format(self.TotalByte[87 + idx * 28],'x').zfill(2),base=16)
                            CsvlogInfo.append(str(Range * self.Factor[0] + self.Offset[0]))
                            # Veloc
                            Veloc = int(format(self.TotalByte[90 + idx * 28],'x').zfill(2) + format(self.TotalByte[89 + idx * 28],'x').zfill(2),base=16)
                            CsvlogInfo.append(str(Veloc * self.Factor[1] + self.Offset[1]))
                            # Azimu
                            Azimu = int(format(self.TotalByte[92 + idx * 28],'x').zfill(2) + format(self.TotalByte[91 + idx * 28],'x').zfill(2),base=16)
                            CsvlogInfo.append(str(Azimu * self.Factor[2] + self.Offset[2]))
                            # Eleva
                            Eleva = int(format(self.TotalByte[94 + idx * 28],'x').zfill(2) + format(self.TotalByte[93 + idx * 28],'x').zfill(2),base=16)
                            CsvlogInfo.append(str(Eleva * self.Factor[3] + self.Offset[3]))
                            # Rcs
                            Rcs = int(hex(self.TotalByte[108 + idx * 28]), base=16)
                            CsvlogInfo.append(str(Rcs * self.Factor[4] + self.Offset[4]))
                            # Snr
                            Snr = int(hex(self.TotalByte[109 + idx * 28]), base=16)
                            CsvlogInfo.append(str(Snr * self.Factor[5] + self.Offset[5]))
                            # Power
                            Power = int(hex(self.TotalByte[110 + idx * 28]), base=16)
                            CsvlogInfo.append(str(Power * self.Factor[6] + self.Offset[6]))
                            # Crc check result
                            CsvlogInfo.append(CrcCheckResult)
                            # Cycle counter check result
                            CsvlogInfo.append(CntCheckResult)
                            output.writerow(CsvlogInfo)
                            # Move to next target
                            idx += 1
                        # Reset TotalByte
                        self.TotalByte = []
                        FirstFrameFlag = False

if __name__=='__main__':
    myParser = Parser()
    myParser.ParsePtl("Diag_Test.pcapng")