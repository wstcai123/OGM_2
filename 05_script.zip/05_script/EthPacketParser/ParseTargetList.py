import os
import csv
import sys
import time
import dpkt
import getopt
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
 
class BasicTreeWidget(QMainWindow):
    def __init__(self,parent=None):
        super(BasicTreeWidget, self).__init__(parent)
        self.setWindowTitle('TargetLists Parsing Tree')
        self.resize(550,950)
        self.NumOfTargets = 0
        self.TargetsList = []
        self.GenNodeList = []
        self.RadNodeList = []
        self.GenChildKeyList = ['Software_ID_Major','Software_ID_Minor','Software_ID_Patch','Sensor_ID','Interface_ID_Major','Interface_ID_Minor','Interface_ID_Patch','TimestampMeasureBegin','TimestampMeasureEnd','Cycle_counter','CRC']
        self.RadChildKeyList = ['number_of_point_target','valid_indicator','Radar_Position','Maximum_Ambigugous_Speed','Maximum_Range','ZF_EOL_Calibration_Status','OEM_EOL_Calibration_Status','Azimuth_misalignment_angle_STD','Azimuth_misalignment_angle','Elevation_misalignment_angle','Elevation_misalignment_STD']
        self.TarChildKeyList = ['range','velocity','azimuth','elevation','std_range','std_velocity','std_azimuth','std_elevation','Reserved_TPL_Debug_Signal1','Reserved_TPL_Debug_Signal2','Reserved_TPL_Debug_Signal3','Reserved_TPL_Debug_Signal4','Probability','RCS','SNR','Power','Reserved_TPL_Debug_Signal5','Reserved_TPL_Debug_Signal6','Reserved_TPL_Debug_Signal7','Reserved_TPL_Debug_Signal8']
 
        self.tree=QTreeWidget()
        # Specify the number of columns
        self.tree.setColumnCount(2)
        # Specify the name of columns
        self.tree.setHeaderLabels(['Key','Value'])
 
        # Create Root Node
        root=QTreeWidgetItem(self.tree)
        root.setText(0,'Radar.TargetList')
        self.tree.setColumnWidth(0,300)
 
        # Create General Header Node
        self.GeneralHeader = QTreeWidgetItem(root)
        self.GeneralHeader.setText(0,'GeneralHeader')
 
        for key in self.GenChildKeyList:
            GenNode = QTreeWidgetItem(self.GeneralHeader)
            GenNode.setText(0,key)
            self.GenNodeList.append(GenNode)
 
        # Create Radar Header Node
        self.RadarHeader = QTreeWidgetItem(root)
        self.RadarHeader.setText(0,'RadarHeader')
 
        for key in self.RadChildKeyList:
            RadNode = QTreeWidgetItem(self.RadarHeader)
            RadNode.setText(0,key)
            self.RadNodeList.append(RadNode)
 
        # Create Target List Node
        self.TargetsNode = QTreeWidgetItem(root)
        self.TargetsNode.setText(0,'TargetsList')
 
        # All nodes are expanded by default
        self.tree.expandAll()
 
        # Set the tree widget cover the entire screen automatically
        self.setCentralWidget(self.tree)
 
    def UpdateTargetsInfo(self,GenHeaderInfo,RadHeaderInfo):
        for i in range(11):
            self.GenNodeList[i].setText(1,GenHeaderInfo[i])
            self.RadNodeList[i].setText(1,RadHeaderInfo[i])
 
    def DeleteAllTarget(self):
        self.NumOfTargets = 0
        if len(self.TargetsList) != 0:
            for item in self.TargetsList:
                self.TargetsNode.removeChild(item)
 
    def CreateNewTarget(self, TargetInfo):
        Target = QTreeWidgetItem(self.TargetsNode)
        Target.setText(0,str(self.NumOfTargets))
        self.ConstructTargetInfo(Target, TargetInfo)
        self.TargetsList.append(Target)
        self.NumOfTargets += 1
 
    def ConstructTargetInfo(self, Target, TargetInfo):
        for i in range(20):
            TarNode = QTreeWidgetItem(Target)
            TarNode.setText(0,self.TarChildKeyList[i])
            TarNode.setText(1,TargetInfo[i])
 
class Runthread(QThread):
    _signal = pyqtSignal(list,list)
 
    def __init__(self):
        super(Runthread, self).__init__()
        self.totalByte = []
        self.byteOffset = 0
        self.totalCounter = 0
        self.frameCounter = 0
        #              Range,      Velocity,   Azimuth,    Elevation,  Rcs,        Snr
        self.Factor = [0.006103609,0.000915541,0.002746624,0.002746624,0.470588235,0.235294118]    
        self.Offset = [0,          0,          -90,        -90,        -60,        0]
        self.showTreeWidget = True
        self.protocol = "Someip"
        #self.protocol = "Udp"
 
    def __del__(self):
        self.wait()
 
    def run(self):
        output = csv.writer(open("output.csv", 'w', newline=''))
        output.writerow(["No.","NumOfTargets","Range","velocity","azimuth","elevation","std_range","std_velocity","std_azimuth","std_elevation","Probability","RCS","SNR","Power"])
        fhdl = open("Targetlist_log_someip.pcapng", 'rb')
        #fhdl = open("RadarToOrin.pcap", 'rb')
        # Judge pcap or pcapng
        try:
            pcap = dpkt.pcap.Reader(fhdl)
        except Exception as e:
            fhdl.seek(0, 0)
            pcap = dpkt.pcapng.Reader(fhdl)
        # Traverse every frame
        for timestamp, buffer in pcap:
            self.totalCounter += 1
            ethernet = dpkt.ethernet.Ethernet(buffer)
            # Filter message we don't need
            if not isinstance(ethernet.data, dpkt.ip.IP):
                continue
            ip = ethernet.data
            if isinstance(ip.data, dpkt.udp.UDP):
                udp = ip.data
                packet = udp.data
            elif isinstance(ip.data, dpkt.tcp.TCP):
                tcp = ip.data
                packet = tcp.data
            else:
                packet = ip.data
 
            # Filter message we don't need
            isValidPacket = False
 
            if self.protocol == "Someip":
                # Only parse someip packet 0x3575 is Service ID, 0x8001 is Method ID
                if packet[0] == 0x35 and packet[1] == 0x75 and packet[2] == 0x80 and packet[3] == 0x01:
                    isValidPacket = True
                else:
                    isValidPacket = False
            else: #self.protocol == "Udp":
                if len(packet) == 1307 or len(packet) == 1472 or len(packet) == 1480:
                    isValidPacket = True
                else:
                    isValidPacket = False
 
            if isValidPacket == True:
                if self.protocol == "Someip":
                    MaxByteCounter = 96099
                    RecOffset = int(format(packet[16],'x').zfill(2) + format(packet[17],'x').zfill(2) + format(packet[18],'x').zfill(2) + format(packet[19]&0xF0,'x').zfill(2),base=16)
                    MoreFragment = packet[19] & 1
                    if self.byteOffset == RecOffset:
                        self.byteOffset += len(packet) - 20
                        self.totalByte += packet[20:]
                else: #self.protocol == "Udp":
                    MaxByteCounter = 84087
                    RecOffset = (ip.off & 0x1FFF) << 3
                    MoreFragment = (ip.off & 0x2000) >> 13
                    # 1st packet is different
                    if self.byteOffset == RecOffset:
                        if self.byteOffset == 0:
                            self.totalByte += packet[4:]
                            self.byteOffset += len(packet) + 8
                        else:
                            self.totalByte += packet
                            self.byteOffset += len(packet)
                    # Reset byteOffset to receive next group ipv4 packet
                    if MoreFragment == 0:
                            self.byteOffset = 0
 
                # Need more segments, move to next frame
                if len(self.totalByte) < MaxByteCounter:
                    self.frameCounter += 1
                # No more segments, start parse
                else:
                    GenHeaderInfo = ["" for i in range(11)]
                    RadHeaderInfo = ["" for i in range(11)]
                    TargetInfo = ["" for i in range(20)]
 
                    # Data index in totalByte
                    idx = 0
 
                    ### PART I - General Header
                    if self.protocol == "Someip":
                        idx += 8
                    # Software_ID_Major
                    GenHeaderInfo[0] = format(self.totalByte[idx],'x').zfill(2) + format(self.totalByte[idx+1],'x').zfill(2) + format(self.totalByte[idx+2],'x').zfill(2) + format(self.totalByte[idx+3],'x').zfill(2)
                    # Software_ID_Minor
                    GenHeaderInfo[1] = format(self.totalByte[idx+4],'x').zfill(2) + format(self.totalByte[idx+5],'x').zfill(2) + format(self.totalByte[idx+6],'x').zfill(2) + format(self.totalByte[idx+7],'x').zfill(2)
                    # Software_ID_Patch
                    GenHeaderInfo[2] = format(self.totalByte[idx+8],'x').zfill(2) + format(self.totalByte[idx+9],'x').zfill(2) + format(self.totalByte[idx+10],'x').zfill(2) + format(self.totalByte[idx+11],'x').zfill(2)
                    # Sensor_ID
                    for i in range(16):
                        GenHeaderInfo[3] += format(self.totalByte[idx+12 + i],'x').zfill(2)
                    # Interface_ID_Major
                    GenHeaderInfo[4] = format(self.totalByte[idx+28],'x').zfill(2) + format(self.totalByte[idx+29],'x').zfill(2) + format(self.totalByte[idx+30],'x').zfill(2) + format(self.totalByte[idx+31],'x').zfill(2)
                    # Interface_ID_Minor
                    GenHeaderInfo[5] = format(self.totalByte[idx+32],'x').zfill(2) + format(self.totalByte[idx+33],'x').zfill(2) + format(self.totalByte[idx+34],'x').zfill(2) + format(self.totalByte[idx+35],'x').zfill(2)
                    # Interface_ID_Patch
                    GenHeaderInfo[6] = format(self.totalByte[idx+36],'x').zfill(2) + format(self.totalByte[idx+37],'x').zfill(2) + format(self.totalByte[idx+38],'x').zfill(2) + format(self.totalByte[idx+39],'x').zfill(2)
                    # TimestampMeasureBegin
                    for i in range(8):
                        GenHeaderInfo[7] += format(self.totalByte[idx+40 + i],'x').zfill(2)
                    # TimestampMeasureEnd
                    for i in range(8):
                        GenHeaderInfo[8] += format(self.totalByte[idx+48 + i],'x').zfill(2)
                    # Cycle_counter
                    for i in range(8):
                        GenHeaderInfo[9] += format(self.totalByte[idx+56 + i],'x').zfill(2)
                    # CRC
                    GenHeaderInfo[10] = format(self.totalByte[idx+64],'x').zfill(2) + format(self.totalByte[idx+65],'x').zfill(2) + format(self.totalByte[idx+66],'x').zfill(2) + format(self.totalByte[idx+67],'x').zfill(2)
 
                    ### PART II - Radar Header
                    # number_of_point_target
                    if self.protocol == "Someip":
                        idx += 4
                        RadHeaderInfo[0] = format(self.totalByte[idx+68],'x').zfill(2) + format(self.totalByte[idx+69],'x').zfill(2)                     
                    else:
                        RadHeaderInfo[0] = format(self.totalByte[idx+69],'x').zfill(2) + format(self.totalByte[idx+68],'x').zfill(2)
                    # valid_indicator
                    RadHeaderInfo[1] = format(self.totalByte[idx+70],'x').zfill(2)
                    # Radar_Position
                    RadHeaderInfo[2] = format(self.totalByte[idx+71],'x').zfill(2)
                    # Maximum_Ambigugous_Speed
                    RadHeaderInfo[3] = format(self.totalByte[idx+72],'x').zfill(2) + format(self.totalByte[idx+73],'x').zfill(2) + format(self.totalByte[idx+74],'x').zfill(2) + format(self.totalByte[idx+75],'x').zfill(2)
                    # Maximum_Range
                    RadHeaderInfo[4] = format(self.totalByte[idx+76],'x').zfill(2)
                    # ZF_EOL_Calibration_Status
                    RadHeaderInfo[5] = format(self.totalByte[idx+77],'x').zfill(2)
                    # OEM_EOL_Calibration_Status
                    RadHeaderInfo[6] = format(self.totalByte[idx+78],'x').zfill(2)
                    # Azimuth_misalignment_angle_STD
                    RadHeaderInfo[7] = format(self.totalByte[idx+79],'x').zfill(2) + format(self.totalByte[idx+80],'x').zfill(2)
                    # Azimuth_misalignment_angle
                    RadHeaderInfo[8] = format(self.totalByte[idx+81],'x').zfill(2) + format(self.totalByte[idx+82],'x').zfill(2)
                    # Elevation_misalignment_angle
                    RadHeaderInfo[9] = format(self.totalByte[idx+83],'x').zfill(2) + format(self.totalByte[idx+84],'x').zfill(2)
                    # Elevation_misalignment_STD
                    RadHeaderInfo[10] = format(self.totalByte[idx+85],'x').zfill(2) + format(self.totalByte[idx+86],'x').zfill(2)
 
                    ### PART III - Target List
                    Tree.DeleteAllTarget()
                    # Parse number of targets
                    NumberOfTarg = int(RadHeaderInfo[0],base=16)
                    for i in range(NumberOfTarg):
                        if self.protocol == "Someip":
                            idx += 4
                        CsvlogInfo = []
                        CsvlogInfo.append(str(self.totalCounter))
                        CsvlogInfo.append(str(NumberOfTarg))
                        # Range
                        TargetInfo[0] = format(self.totalByte[idx+87+i*32],'x').zfill(2) + format(self.totalByte[idx+88+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[0],base=16) * self.Factor[0] + self.Offset[0]))
                        # velocity
                        TargetInfo[1] = format(self.totalByte[idx+89+i*32],'x').zfill(2) + format(self.totalByte[idx+90+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[1],base=16) * self.Factor[1] + self.Offset[1]))
                        # azimuth
                        TargetInfo[2] = format(self.totalByte[idx+91+i*32],'x').zfill(2) + format(self.totalByte[idx+92+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[2],base=16) * self.Factor[2] + self.Offset[2]))
                        # elevation
                        TargetInfo[3] = format(self.totalByte[idx+93+i*32],'x').zfill(2) + format(self.totalByte[idx+94+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[3],base=16) * self.Factor[3] + self.Offset[3]))
                        # std_range
                        TargetInfo[4] = format(self.totalByte[idx+95+i*32],'x').zfill(2) + format(self.totalByte[idx+96+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[4],base=16)))
                        # std_velocity
                        TargetInfo[5] = format(self.totalByte[idx+97+i*32],'x').zfill(2) + format(self.totalByte[idx+98+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[5],base=16)))
                        # std_azimuth
                        TargetInfo[6] = format(self.totalByte[idx+99+i*32],'x').zfill(2) + format(self.totalByte[idx+100+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[6],base=16)))
                        # std_elevation
                        TargetInfo[7] = format(self.totalByte[idx+101+i*32],'x').zfill(2) + format(self.totalByte[idx+102+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[7],base=16)))
                        # Reserved_TPL_Debug_Signal1
                        TargetInfo[8] = format(self.totalByte[idx+103+i*32],'x').zfill(2)
                        # Reserved_TPL_Debug_Signal2
                        TargetInfo[9] = format(self.totalByte[idx+104+i*32],'x').zfill(2)
                        # Reserved_TPL_Debug_Signal3
                        TargetInfo[10] = format(self.totalByte[idx+105+i*32],'x').zfill(2)
                        # Reserved_TPL_Debug_Signal4
                        TargetInfo[11] = format(self.totalByte[idx+106+i*32],'x').zfill(2)
                        # Probability
                        TargetInfo[12] = format(self.totalByte[idx+107+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[12],base=16)))
                        # RCS
                        TargetInfo[13] = format(self.totalByte[idx+108+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[13],base=16) * self.Factor[4] + self.Offset[4]))
                        # SNR
                        TargetInfo[14] = format(self.totalByte[idx+109+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[14],base=16) * self.Factor[5] + self.Offset[5]))
                        # Power
                        TargetInfo[15] = format(self.totalByte[idx+110+i*32],'x').zfill(2)
                        CsvlogInfo.append(str(int(TargetInfo[15],base=16)))
                        # Reserved_TPL_Debug_Signal5
                        TargetInfo[16] = format(self.totalByte[idx+111+i*32],'x').zfill(2)
                        # Reserved_TPL_Debug_Signal6
                        TargetInfo[17] = format(self.totalByte[idx+112+i*32],'x').zfill(2)
                        # Reserved_TPL_Debug_Signal7
                        TargetInfo[18] = format(self.totalByte[idx+113+i*32],'x').zfill(2)
                        # Reserved_TPL_Debug_Signal8
                        TargetInfo[19] = format(self.totalByte[idx+114+i*32],'x').zfill(2)
                        # Write data into log file
                        output.writerow(CsvlogInfo)
                        # Create a new target
                        if self.showTreeWidget == True:
                            Tree.CreateNewTarget(TargetInfo)
 
                    # Emit signal to update GenHeaderInfo and RadHeaderInfo
                    self.frameCounter = 0
                    self.byteOffset = 0
                    self.totalByte = []
                    if self.showTreeWidget == True:
                        self._signal.emit(GenHeaderInfo, RadHeaderInfo)
                        time.sleep(0.2)
 
if __name__=='__main__':
    '''try:
        opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
    except getopt.GetoptError:
        print 'test.py -i <inputfile> -o <outputfile>'
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print 'test.py -i <inputfile> -o <outputfile>'
            sys.exit()
        elif opt in ("-i", "--ifile"):
            inputfile = arg
        elif opt in ("-o", "--ofile"):
            outputfile = arg'''
    app = QApplication(sys.argv)
    Tree = BasicTreeWidget()
    Tree.show()
    thread = Runthread()
    thread._signal.connect(Tree.UpdateTargetsInfo)
    thread.start()
    sys.exit(app.exec_())